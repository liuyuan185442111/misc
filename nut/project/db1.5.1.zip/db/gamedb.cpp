#include <iostream>
#include "storage.h"
#include <signal.h>
using namespace std;
using namespace lcore;

void sigusr1_handler(int signum)
{
	puts("shutdown db by SIGUSR1");
	Storage::checkpoint();
	Storage::close();
	exit(0);
}

int main(int argc, char **argv)
{
	if(!Storage::open("game.conf")) return -1;
	pthread_t th;
	pthread_create(&th, NULL, &Storage::BackupThread, NULL);

	{
		struct sigaction act;
		act.sa_handler = sigusr1_handler;
		sigemptyset(&act.sa_mask);
		act.sa_flags = 0;
		if(sigaction(SIGUSR1, &act, NULL) != 0) return -2;
	}

	{
		Transaction txn;
		Table *user = Storage::get_table("user", txn);
		user->insert((OctetsStream() << "key"), (OctetsStream() << "value"), txn, 0);
	}
	Storage::checkpoint();

	for(;;) sleep(1);

	return 0;
}
