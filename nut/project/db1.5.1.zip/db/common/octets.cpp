#include "octets.h"
namespace lcore { Octets::Rep Octets::Rep::null = { 0, 0, 1 }; }
