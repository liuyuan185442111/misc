#ifndef _L_SPLIT_H
#define _L_SPLIT_H
#include <string>
#include <vector>
namespace lcore { void SplitString(std::vector<std::string> &strs, const char *str, const char *token); }
#endif
