//-1: error  0:file is not empty  1:file is empty
int check_file_empty(const char *db_file);
