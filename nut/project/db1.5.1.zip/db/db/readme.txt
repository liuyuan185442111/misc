﻿本目录下代码提供了一个单线程单表db, 仅依赖aligned_allocator.h一个非库头文件, 且aligned_allocator.h也不依赖非库头文件.
如要简单使用, 仅需了解和包含db.h即可.
