#ifndef _L_DATA_CODER_H
#define _L_DATA_CODER_H

#include "octets.h"
#ifdef _USE_SNAPPY_COMPRESS_
#include "snappy.h"
#endif
namespace WDB
{

enum {
	WDB_NOOVERWRITE = 1, WDB_OVERWRITE, WDB_NOTFOUND, WDB_KEYSIZEZERO, WDB_UNCOMPRESSERR
};
class DbException : public std::exception
{
	int reason;
public:
	DbException(int e) : reason(e) { }
	virtual ~DbException() throw() { }
	virtual const char *what() throw()
	{
		switch(reason)
		{
			case WDB_NOTFOUND:		return "NOTFOUND";
			case WDB_OVERWRITE:		return "OVERWRITE";
			case WDB_KEYSIZEZERO:	return "KEYSIZEZERO";
			case WDB_UNCOMPRESSERR:	return "UNCOMPRESSERR";
			default:				return "UNKNOWN";
		}
	}
};

struct DataCoder
{
	virtual ~DataCoder() { }
	virtual lcore::Octets Compress(const lcore::Octets &os) = 0;
	virtual lcore::Octets Uncompress(const lcore::Octets &os) = 0;
};

struct NullCoder : public DataCoder
{
	lcore::Octets Compress(const lcore::Octets &os) { return os; }
	lcore::Octets Uncompress(const lcore::Octets &os) { return os; }
};

#ifdef _USE_SNAPPY_COMPRESS_
struct SnappyCoder : public DataCoder
{
	lcore::Octets Compress(const lcore::Octets &os)
	{
		lcore::Octets val;
		val.reserve(snappy::MaxCompressedLength(os.size()));
		size_t len;
		snappy::RawCompress((const char *)os.begin(), os.size(), (char *)val.begin(), &len);
		val.setsize(len);
		return val;
	}
	lcore::Octets Uncompress(const lcore::Octets &os)
	{
		lcore::Octets val;
		size_t len;
		if(!snappy::GetUncompressedLength((const char *)os.begin(), os.size(), &len))
			throw DbException(WDB_UNCOMPRESSERR);
		val.reserve(len);
		val.setsize(len);
		if(!snappy::RawUncompress((const char *)os.begin(), os.size(), (char *)val.begin()))
			throw DbException(WDB_UNCOMPRESSERR);
		return val;
	}
};
#endif

#if defined(_USE_SNAPPY_COMPRESS_)
typedef SnappyCoder RealCoder;
#else
typedef NullCoder RealCoder;
#endif
}

#endif
