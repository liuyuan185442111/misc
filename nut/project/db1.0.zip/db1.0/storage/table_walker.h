#ifndef _L_TABLE_WALKER_H
#define _L_TABLE_WALKER_H

#include "db.h"
#include "data_coder.h"

namespace WDB
{

//不能在walk表的时候对该表进行插入删除操作!!!
//Cursor遍历的数据是有序的, Browser遍历的数据是按表文件从前到后walk的

struct IQuery {
	virtual ~IQuery() { }
	virtual bool Update(const lcore::Octets &key, const lcore::Octets &val) = 0;
};
struct IQueryKey
{
	virtual ~IQueryKey() { }
	virtual bool Update(const lcore::Octets &key) = 0;
};

class QueryData : public lcore::IQueryData
{
	IQuery *query;
	DataCoder *uncompressor;
public:
	QueryData(IQuery *q, DataCoder *u) : query(q), uncompressor(u) { }
	virtual bool update(const void *key, size_t key_len, const void *val, size_t val_len)
	{
		lcore::Octets k(key, key_len);
		lcore::Octets v;
		try {
			v = uncompressor->Uncompress(lcore::Octets(val, val_len));
		}
		catch(lcore::Marshal::Exception e) {
			fprintf(stderr, "QueryData::update exception %s\n", e.what());
		}
		return query->Update(k, v);
	}
};
class QueryDataRaw : public lcore::IQueryData
{
	IQuery *query;
public:
	QueryDataRaw(IQuery *q) : query(q) { }
	virtual bool update(const void *key, size_t key_len, const void *val, size_t val_len)
	{
		lcore::Octets k(key, key_len);
		lcore::Octets v(val, val_len);
		return query->Update(k, v);
	}
};

class Cursor
{
	lcore::DB *db;
	DataCoder *uncompressor;
public:
	Cursor(lcore::DB *_db, DataCoder *_u = NULL) : db(_db), uncompressor(_u) { }

	void walk(IQuery &query)
	{
		if(!uncompressor)
		{
			fprintf(stderr, "Cursor::walk uncompressor is NULL\n");
			return;
		}
		try
		{
			QueryData q(&query, uncompressor);
			db->walk(&q);
		}
		catch(lcore::__db_core::PageFile::Exception e)
		{
			fprintf(stderr, "Cursor::walk DISK ERROR! PROGRAM ABORT!\n");
			abort();
		}
	}
	void walk(lcore::Octets &begin, IQuery &query)
	{
		if(!uncompressor)
		{
			fprintf(stderr, "Cursor::walk uncompressor is NULL\n");
			return;
		}
		try
		{
			QueryData q(&query, uncompressor);
			db->walk(begin.begin(), begin.size(), &q);
		}
		catch(lcore::__db_core::PageFile::Exception e)
		{
			fprintf(stderr, "Cursor::walk DISK ERROR! PROGRAM ABORT!\n");
			abort();
		}
	}
	void walk_raw(IQuery &query)
	{
		try
		{
			QueryDataRaw q(&query);
			db->walk(&q);
		}
		catch(lcore::__db_core::PageFile::Exception e)
		{
			fprintf(stderr, "Cursor::walk_raw DISK ERROR! PROGRAM ABORT!\n");
			abort();
		}
	}
	void walk_raw(lcore::Octets &begin, IQuery &query)
	{
		try
		{
			QueryDataRaw q(&query);
			db->walk(begin.begin(), begin.size(), &q);
		}
		catch(lcore::__db_core::PageFile::Exception e)
		{
			fprintf(stderr, "Cursor::walk_raw DISK ERROR! PROGRAM ABORT!\n");
			abort();
		}
	}
};

class Browser
{
	const char *path;
	DataCoder *uncompressor;
public:
	Browser(const char *_path, DataCoder *_u = NULL) : path(_path), uncompressor(_u) { }
	void browse(IQuery &query)
	{
		if(!uncompressor)
		{
			fprintf(stderr, "uncompressor is NULL\n");
			return;
		}
		try
		{
			QueryData q(&query, uncompressor);
			lcore::PageBrowser(path).action(&q);
		}
		catch(lcore::__db_core::PageFile::Exception e)
		{
			fprintf(stderr, "Browser::browse DISK ERROR! PROGRAM ABORT!\n");
			abort();
		}
	}
	void browse_raw(IQuery &query)
	{
		try
		{
			QueryDataRaw q(&query);
			lcore::PageBrowser(path).action(&q);
		}
		catch(lcore::__db_core::PageFile::Exception e)
		{
			fprintf(stderr, "Browser::browse_raw DISK ERROR! PROGRAM ABORT!\n");
			abort();
		}
	}
};

class KeyBrowser
{
	const char *path;
	class BrowserQuery : public lcore::IQueryKey
	{
		WDB::IQueryKey *query;
	public:
		BrowserQuery(WDB::IQueryKey *q) : query(q) { }
		virtual bool update(const void *key, size_t key_len)
		{
			lcore::Octets k(key, key_len);
			return query->Update(k);
		}
	};
public:
	KeyBrowser(const char *_path) : path(_path) { }
	void browse(IQueryKey &query)
	{
		try
		{
			BrowserQuery q(&query);
			lcore::IndexBrowser(path).action(&q);
		}
		catch(lcore::__db_core::PageFile::Exception e)
		{
			fprintf(stderr, "Browser::browse DISK ERROR! PROGRAM ABORT!\n");
			abort();
		}
	}
};

}

#endif
