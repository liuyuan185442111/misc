#ifndef _L_TABLEWRAPPER_H
#define _L_TABLEWRAPPER_H

#include "db.h"

namespace WDB
{
class TableWrapper
{
	typedef lcore::_DBStandalone<false> DB;
	DB *db;
	std::string db_path;
	DataCoder *compressor;
	TableWrapper(const TableWrapper &);
	TableWrapper& operator =(const TableWrapper &);
public:
	~TableWrapper()
	{
		delete db;
		delete compressor;
	}
	TableWrapper(const char *dbfile, DataCoder *c)
		: db_path(dbfile), compressor(c) { }
	bool open(size_t cache_high = 8192, size_t cache_low = 4096)
	{
		db = new DB(db_path.c_str(), cache_high, cache_low);
		return db->init();
	}
	bool find(const lcore::Octets &key, lcore::Octets &val)
	{
		if(key.size() == 0) return false;
		size_t val_len;
		if(void *value = db->find(key.begin(), key.size(), &val_len))
		{
			compressor->Uncompress(lcore::Octets(value, val_len)).swap(val);
			free(value);
			return true;
		}
		return false;
	}
	bool insert(const lcore::Octets &key, const lcore::Octets &val)
	{
		if(key.size() == 0) return false;
		lcore::Octets com_val = compressor->Compress(val);
		db->put(key.begin(), key.size(), com_val.begin(), com_val.size(), true);
		return true;
	}
	void del(const lcore::Octets &key) { db->del(key.begin(), key.size()); }
	bool checkpoint() { return db->checkpoint(); }
	size_t count() { return db->record_count(); }
};
}
#endif
