#ifndef _L_STORAGE_H
#define _L_STORAGE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <pthread.h>
#include <set>
#include <map>
#include <string>
#include "db.h"
#include "db_tool.h"
#include "conf.h"
#include "split.h"
#include "mutex.h"
#include "marshal.h"
#include "data_coder.h"
#include "table_walker.h"

#define WDB_HOMEDIR_DEFAULT "./dbhome"
#define WDB_DATADIR_DEFAULT "dbdata"
#define WDB_LOGDIR_DEFAULT  "dblogs"

/** 问题
表级锁粒度太大, 对多线程不友好
日志系统功能不足, 应该在事务完成时写日志, 现在事务在较高层面实现, 不能完成本应有的功能
*/
namespace WDB {

class Storage;
typedef std::vector<Storage *> StorageVec;

//线程私有数据, 无需加锁
/** 由于一个线程只有一个事务管理, 用一个事务负责一个代码段内所有的table,
 *  所以在一个代码段内只能先获取所有的table, 再产生一个事务, 再进行各个表的插入删除等操作,
 *  错误示范:
GetStorage("table1");
GetStorage("table3");
Transaction txn1;
table1.insert(txn1);//锁上了table1和table3
GetStorage("table2");
Transaction txn2;//和txn1作用一致, 之后的操作使用txn1或txn2都行
table2.insert(txn2);//锁不上table2
...
Transaction销毁的时候解锁各表
 */
class __ThreadContext
{
	static pthread_key_t key;
	StorageVec storage_vec;
	bool locked;
	bool cancel;
	size_t refcnt;
public:
	__ThreadContext() : locked(false), refcnt(0) { }
	Storage *AddStorage(Storage *storage)
	{
		storage_vec.push_back(storage);
		return storage;
	}
	void lock_tables();
	void unlock_tables();
	void ref()     { ++refcnt; }
	void release() { if(--refcnt == 0) { unlock_tables(); storage_vec.clear(); } }
	void set_cancel() { cancel = true; }

	static void destroy_context(void *p) { delete (__ThreadContext *)p; }
	static void init_key() { pthread_key_create(&key, &__ThreadContext::destroy_context); }
	static __ThreadContext *GetInstance()
	{
		__ThreadContext *spec = (__ThreadContext *)pthread_getspecific(key);
		if(!spec) pthread_setspecific(key, spec = new __ThreadContext());
		return spec;
	}
};
class Transaction
{
	friend class Storage;
	void* operator new(size_t);
	void operator delete(void*);
	Transaction(const Transaction &);
	void operator=(const Transaction &);
	void lock() { __ThreadContext::GetInstance()->lock_tables(); }
public:
	~Transaction() { __ThreadContext::GetInstance()->release(); }
	Transaction() { __ThreadContext::GetInstance()->ref(); }
	void commit() { }
	void abort() { __ThreadContext::GetInstance()->set_cancel(); }
};

class Storage
{
	friend class __ThreadContext;
	struct CompareOctets
	{
		bool operator()(const lcore::Octets &o1, const lcore::Octets &o2) const
		{
			size_t s1 = o1.size();
			size_t s2 = o2.size();
			if(int r = memcmp(o1.begin(), o2.begin(), std::min(s1, s2)))
				return r < 0;
			return s1 < s2;
		}
	};
	typedef std::map<const lcore::Octets, std::pair<void *, size_t>, CompareOctets > Prepared;
	typedef std::set<lcore::Octets, CompareOctets> NewKey;
	Prepared  prepared; //保存overwrite/del操作的旧value
	NewKey    new_key; //保存新插入的key
	lcore::DB *db;
	DataCoder *compressor;
	lcore::Thread::Mutex locker;

	void _commit(bool cancel);
public:
	~Storage()
	{
		delete compressor;
	}
	Storage(lcore::DB *_db, DataCoder *c)
		: db(_db), compressor(c), locker("") { }

	void snapshot_create()
	{
		db->snapshot_create();
		locker.UNLock();
	}
	void snapshot_release()
	{
		lcore::Thread::Mutex::Scoped l(locker);
		db->snapshot_release();
	}
	void Lock() { locker.Lock(); }

	size_t count() const { return db->record_count(); }

	//val如非空则会被清空
	bool find(const lcore::Octets &key, lcore::Octets &val, Transaction &txn);
	lcore::Octets find(const lcore::Octets &key, Transaction &txn);

	void insert(const lcore::Octets &key, const lcore::Octets &val, Transaction &txn, int flags = 0);
	void del(const lcore::Octets &key, Transaction& txn);

	//不应在从Storage获得的Cursor的walk系列函数中调用StorageEnv::checkpoint(), 原因见PageCache::walk()中的注释
	//如果一定要调用StorageEnv::checkpoint(), 请使用TableWrapper来walk表
	Cursor cursor() { return Cursor(db, compressor); }
}; //class Storage

inline void __ThreadContext::lock_tables()
{
	if(locked) return;
	std::sort(storage_vec.begin(), storage_vec.end());
	std::unique(storage_vec.begin(), storage_vec.end());
	std::for_each(storage_vec.begin(), storage_vec.end(), std::mem_fun(&Storage::Lock));
	locked = true;
	cancel = false;
}
inline void __ThreadContext::unlock_tables()
{
	if(!locked) return;
	std::for_each(storage_vec.begin(), storage_vec.end(), std::bind2nd(std::mem_fun(&Storage::_commit),cancel));
	locked = false;
}

//单例的, 一个进程一份
class StorageEnv
{
	static std::map<std::string, Storage *> storage_map;
	static StorageVec storage_vec;
	static std::string conf_section;
	static std::string datadir;
	static std::string logdir;
	static lcore::DBEnv *env;
	static lcore::Thread::Mutex checkpoint_locker;
public:
	static Storage *GetStorage(const char *dbfile)
	{
		std::map<std::string, Storage *>::iterator it = storage_map.find(dbfile);
		return it != storage_map.end() ? __ThreadContext::GetInstance()->AddStorage((*it).second) : NULL;
	}

	static bool Open(const std::string &section = "storage")
	{
		std::string homedir = lcore::Conf::find(section, "homedir");
		datadir = lcore::Conf::find(section, "datadir");
		logdir = lcore::Conf::find(section, "logdir");
		if(homedir.empty()) homedir = WDB_HOMEDIR_DEFAULT;
		if(datadir.empty()) datadir = WDB_DATADIR_DEFAULT;
		if(logdir.empty()) logdir = WDB_LOGDIR_DEFAULT;
		if(*homedir.rbegin() == '/') homedir.erase(homedir.end() - 1);
		if(*datadir.rbegin() == '/') datadir.erase(datadir.end() - 1);
		if(*logdir.rbegin() == '/') logdir.erase(logdir.end() - 1);
		datadir = homedir + "/" + datadir;
		logdir = homedir + "/" + logdir;
		conf_section = section;

		__ThreadContext::init_key();
		env = new lcore::DBEnv();

		env->set_data_dir(datadir.c_str());
		env->set_log_dir(logdir.c_str());

		size_t cache_high_default = atoi(lcore::Conf::find(section, "cache_high_default").c_str());
		size_t cache_low_default = atoi(lcore::Conf::find(section, "cache_low_default").c_str());
		std::vector<std::string> tables;
		lcore::SplitString(tables, lcore::Conf::find(section, "tables").c_str(), ", ");
		std::sort(tables.begin(), tables.end());
		std::unique(tables.begin(), tables.end());
		for(size_t k=0; k<tables.size(); ++k)
		{
			size_t cache_high = cache_high_default;
			size_t cache_low = cache_low_default;
			std::string str_high = lcore::Conf::find(section, tables[k] + "_cache_high");
			std::string str_low  = lcore::Conf::find(section, tables[k] + "_cache_low");
			if(!str_high.empty()) cache_high = atoi(str_high.c_str());
			if(!str_low.empty())  cache_low  = atoi(str_low.c_str());
			if(0 == cache_high) cache_high = cache_high_default;
			if(0 == cache_low)  cache_low  = cache_low_default;
			if(cache_low > 0 && cache_high > cache_low)
				env->set_table(tables[k].c_str(), cache_high, cache_low);
			else
				env->set_table(tables[k].c_str());
		}

		if(env->init())
		{
			std::vector<const char *> names;
			std::vector<lcore::DB *> dbs;
			size_t size = env->all_dbs(names, dbs);
			for(size_t k=0; k<size; ++k)
			{
				std::string table_compressor = lcore::Conf::find(section, std::string(names[k]) + "_compressor");
				DataCoder *compressor;
				if(table_compressor.empty()) compressor = new NullCoder;
				else compressor = new SnappyCoder;
				Storage *storage = new Storage(dbs[k], compressor);
				printf(">>>>>>>>>>>Init StorageEnv: Storage %s is %p\n", names[k], storage);
				storage_map.insert(std::make_pair(names[k], storage));
				storage_vec.push_back(storage);
			}
			return true;
		}
		return false;
	}

	static void Close()
	{
		lcore::Thread::Mutex::Scoped l(checkpoint_locker);
		if(NULL == env) return; // env has closed
		delete env;
		env = NULL;
		for(StorageVec::iterator it = storage_vec.begin(), ie = storage_vec.end(); it != ie; ++it)
			delete *it;
		storage_map.clear();
		storage_vec.clear();
	}

	static bool checkpoint()
	{
		try
		{
			lcore::Thread::Mutex::Scoped l(checkpoint_locker);
			if(NULL == env) return false; // env has closed
			std::for_each(storage_vec.begin(), storage_vec.end(), std::mem_fun(&Storage::Lock));
			std::for_each(storage_vec.begin(), storage_vec.end(), std::mem_fun(&Storage::snapshot_create));
			bool r = env->checkpoint_prepare() && env->checkpoint_commit();
			std::for_each(storage_vec.begin(), storage_vec.end(), std::mem_fun(&Storage::snapshot_release));
			return r;
		}
		catch(lcore::__db_core::PageFile::Exception e)
		{
			fprintf(stderr, "StorageEnv::checkpoint DISK ERROR! PROGRAM ABORT!\n");
			abort();
		}
		return false;
	}

	static void removeoldlogs()
	{
		if(env)
		{
			std::vector<time_t> r;
			env->get_old_logs(r);
			char *name = (char *)malloc(logdir.length() + 12);
			for(std::vector<time_t>::iterator it = r.begin(), ie = r.end(); it != ie; ++it)
			{
				sprintf(name, "%s/log.%08x", logdir.c_str(), (unsigned int)(*it));
				unlink(name);
			}
			free(name);
		}
	}

	static void backup(const char *__destdir, bool increment = false)
	{
		if(!__destdir || strlen(__destdir) == 0)
		{
			fprintf(stderr, "StorageEnv::backup DESTDIR ERROR!\n");
			return;
		}
		time_t t = time(NULL);
		struct tm tm;
		localtime_r(&t, &tm);
		char buffer[32];
		sprintf(buffer, "%.4d%.2d%.2d-%.2d%.2d%.2d",
				tm.tm_year+1900, tm.tm_mon+1, tm.tm_mday,
				tm.tm_hour, tm.tm_min, tm.tm_sec);

		std::string destdir = __destdir;
		int len = destdir.length();
		if(destdir[len-1] != '/') destdir += "/";
		mkdir(destdir.c_str(), 0755);
		destdir += buffer;
		mkdir(destdir.c_str(), 0755);

		std::string scmd = "/bin/cp -r ";
		if(!increment)
		{
			scmd += datadir + " " + destdir + "/";
			scmd += ";/bin/cp -r ";
		}
		scmd += logdir + " " + destdir + "/";
		system(scmd.c_str());
		if(!increment)
		{
			//全备份完成之后 touch backupfinished 文件来标识
			scmd = "/bin/touch " + destdir + "/backupfinished";
			system(scmd.c_str());
		}
	}

	static void *BackupThread(void *pParam)
	{
		pthread_detach(pthread_self());

		sigset_t sigs;
		sigfillset(&sigs);
		pthread_sigmask(SIG_BLOCK, &sigs, NULL);

		time_t last_checked = time(NULL);

		while(true)
		{
			lcore::Conf::load();

			long cp_interval = atol(lcore::Conf::find(conf_section, "checkpoint_interval").c_str());
			int elapsed = time(NULL) - last_checked;
			if(elapsed < cp_interval)
				sleep(cp_interval - elapsed);
			last_checked = time(NULL);

			puts("checkpoint begin");
			if(!StorageEnv::checkpoint())
			{
				fprintf(stderr, "StorageEnv::BackupThread failed!\n");
			}
			puts("checkpoint end");

			if(0 == unlink(lcore::Conf::find(conf_section, "quit_file").c_str()))
			{
				puts("quit.");
				if(0 != kill(0, SIGKILL)) exit(0);
				break;
			}

			std::string backupdir = lcore::Conf::find(conf_section, "backupdir");
			if(backupdir.empty()) continue;
			int backtime = atoi(lcore::Conf::find(conf_section, "backtime").c_str());
			if(backtime < 10) continue;
			static unsigned int times = 0;
			if(++times%backtime == 0)
			{
				printf("backup all begin (times=%u).\n", times );
				StorageEnv::removeoldlogs();
				StorageEnv::backup(backupdir.c_str());
			}
			else
			{
				printf("backup increment begin (times=%u).\n", times);
				StorageEnv::backup(backupdir.c_str(), true);
			}
			printf("backup end (times=%u).\n", times);
		}

		return NULL;
	}
}; //class StorageEnv

} //namespace WDB
#endif
