#include "storage.h"

namespace WDB {
pthread_key_t __ThreadContext::key;
std::map<std::string, Storage *> StorageEnv::storage_map;
StorageVec StorageEnv::storage_vec;
std::string StorageEnv::conf_section;
std::string StorageEnv::datadir;
std::string StorageEnv::logdir;
lcore::DBEnv *StorageEnv::env = NULL;
lcore::Thread::Mutex StorageEnv::checkpoint_locker;

bool Storage::find(const lcore::Octets &key, lcore::Octets &val, Transaction &txn)
{
	if(key.size() == 0) throw DbException(WDB_KEYSIZEZERO);
	try
	{
		txn.lock();
		size_t val_len;
		if(void *value = db->find(key.begin(), key.size(), &val_len))
		{
			compressor->Uncompress(lcore::Octets(value, val_len)).swap(val);
			free(value);
			return true;
		}
		return false;
	}
	catch(DbException e)
	{
		txn.abort();
		throw e;
	}
	catch(lcore::__db_core::PageFile::Exception e)
	{
		fprintf(stderr, "Storage::find DISK ERROR! PROGRAM ABORT!\n");
		abort();
	}
	return false;
}

lcore::Octets Storage::find(const lcore::Octets &key, Transaction &txn)
{
	if(key.size() == 0) throw DbException(WDB_KEYSIZEZERO);
	try
	{
		txn.lock();
		size_t val_len;
		if(void *value = db->find(key.begin(), key.size(), &val_len))
		{
			lcore::Octets val = compressor->Uncompress(lcore::Octets(value, val_len));
			free(value);
			return val;
		}
		throw DbException(WDB_NOTFOUND);
	}
	catch(DbException e)
	{
		txn.abort();
		throw e;
	}
	catch(lcore::__db_core::PageFile::Exception e)
	{
		fprintf(stderr, "Storage::find DISK ERROR! PROGRAM ABORT!\n");
		abort();
	}
	return lcore::Octets();
}

//所有操作立即执行, 不过把操作记录在了prepared and new_key, 在需要时回退
void Storage::insert(const lcore::Octets &key, const lcore::Octets &val, Transaction &txn, int flags)
{
	if(key.size() == 0) throw DbException(WDB_KEYSIZEZERO);
	try
	{
		txn.lock();
		lcore::Octets com_val = compressor->Compress(val);
		if(flags & WDB_NOOVERWRITE)
		{
			//可以当做是新插入, 如果不是新插入直接抛异常
			if(!db->put(key.begin(), key.size(), com_val.begin(), com_val.size(), false))
				throw DbException(WDB_OVERWRITE);
			new_key.insert(key);
		}
		else if(prepared.find(key) == prepared.end() && new_key.find(key) == new_key.end())
		{
			size_t val_len = com_val.size();
			if(void *origin_val = db->put(key.begin(), key.size(), com_val.begin(), &val_len))
				//overwrite, 保存被替换的数据
				prepared.insert(std::make_pair(key, std::make_pair(origin_val, val_len)));
			else
				//new key
				new_key.insert(key);
		}
		else
		{
			//一个事务内多次插入同一个key
			db->put(key.begin(), key.size(), com_val.begin(), com_val.size());
		}
	}
	catch(DbException e)
	{
		txn.abort();
		throw e;
	}
	catch(lcore::__db_core::PageFile::Exception e)
	{
		fprintf(stderr, "Storage::insert DISK ERROR! PROGRAM ABORT!\n");
		abort();
	}
}

void Storage::del(const lcore::Octets &key, Transaction& txn)
{
	if(key.size() == 0) throw DbException(WDB_KEYSIZEZERO);
	try
	{
		txn.lock();
		if(prepared.find(key) == prepared.end())
		{
			NewKey::iterator it = new_key.find(key);
			if(it != new_key.end())
			{
				//新插入还未提交
				new_key.erase(it);
				db->del(key.begin(), key.size());
			}
			else
			{
				//新删除
				size_t val_len;
				if(void *origin_val = db->del(key.begin(), key.size(), &val_len))
					//保存被删除的数据
					prepared.insert(std::make_pair(key, std::make_pair(origin_val, val_len)));
			}
		}
		else
		{
			//已被覆盖或被删除但未提交
			db->del(key.begin(), key.size());
		}
	}
	catch(DbException e)
	{
		txn.abort();
		throw e;
	}
	catch(lcore::__db_core::PageFile::Exception e)
	{
		fprintf(stderr, "Storage::del DISK ERROR! PROGRAM ABORT!\n");
		abort();
	}
}

void Storage::_commit(bool cancel)
{
	try
	{
		if(cancel)
		{
			for(Prepared::const_iterator it = prepared.begin(), ie = prepared.end(); it != ie; ++it)
			{
				db->put(it->first.begin(), it->first.size(), it->second.first, it->second.second);
				free(it->second.first);
			}
			for(NewKey::const_iterator it = new_key.begin(), ie = new_key.end(); it != ie; ++it)
				db->del(it->begin(), it->size());
		}
		else
		{
			for(Prepared::const_iterator it = prepared.begin(), ie = prepared.end(); it != ie; ++it)
				free(it->second.first);
		}
		prepared.clear();
		new_key.clear();
		locker.UNLock();
	}
	catch(lcore::__db_core::PageFile::Exception e)
	{
		fprintf(stderr, "Storage::_commit DISK ERROR! PROGRAM ABORT!\n");
		abort();
	}
}

}
