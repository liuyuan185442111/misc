#include "db_core.h"

namespace lcore {
namespace __db_core {

PageMemory::PageMemoryType PageMemory::mem(PAGESIZE);
Thread::SpinLock PageMemory::locker("PageMemory");
PagePool::PagePoolType PagePool::pool;
Thread::SpinLock PagePool::locker("PagePool");

void* PageCache::extract_data(data_hdr *hdr, size_t &size, void *data_buf)
{
	size_t copy_len = *(size32_t *)(hdr + 1);
	byte_t *data = (byte_t *)(copy_len <= size ? data_buf : malloc(copy_len));
	size = copy_len;
	byte_t *p = data;
	while(true)
	{
		memcpy(p, hdr + 1, hdr->size);
		p += hdr->size;
		if(!hdr->next_page_index)
			break;
		hdr = Rnext_page_head(hdr);
	}
	return data;
}

void PageCache::extract_key_copyer(data_hdr *hdr, byte_t *dest, size_t copy_len)
{
	size_t min = hdr->size - sizeof(size32_t) - sizeof(size32_t);
	if(copy_len <= min)
		memcpy(dest, (size32_t *)(hdr + 1) + 2, copy_len);
	else
	{
		memcpy(dest, (size32_t *)(hdr + 1) + 2, min);
		dest     += min;
		copy_len -= min;
		while(copy_len)
		{
			hdr       = Rnext_page_head(hdr);
			min       = copy_len < hdr->size ? copy_len : hdr->size;
			memcpy(dest, hdr + 1, min);
			dest     += min;
			copy_len -= min;
		}
	}
}
void* PageCache::extract_key(data_hdr *hdr, size_t &key_len)
{
	key_len = *((size32_t *)(hdr + 1) + 1);
	byte_t *key = (byte_t *)malloc(key_len);
	extract_key_copyer(hdr, key, key_len);
	return key;
}
void* PageCache::extract_key(data_hdr *hdr, size_t &key_len, void *key_buf)
{
	size_t copy_len = *((size32_t *)(hdr + 1) + 1);
	byte_t *key = (byte_t *)(copy_len <= key_len ? key_buf : malloc(copy_len));
	key_len = copy_len;
	extract_key_copyer(hdr, key, key_len);
	return key;
}

void* PageCache::extract_key(index_hdr *hdr, size_t &key_len)
{
	if(hdr->key_len)
	{
		key_len = hdr->key_len;
		void *key = malloc(key_len);
		memcpy(key, hdr->key, key_len);
		return key;
	}
	return extract_key(Rindex_hdr2data_hdr(hdr), key_len);
}
void* PageCache::extract_key(index_hdr *hdr, size_t &key_len, void *key_buf)
{
	if(hdr->key_len)
	{
		void *key = hdr->key_len <= key_len ? key_buf : malloc(hdr->key_len);
		key_len = hdr->key_len;
		memcpy(key, hdr->key, key_len);
		return key;
	}
	return extract_key(Rindex_hdr2data_hdr(hdr), key_len, key_buf);
}

void PageCache::extract_val_copyer(data_hdr *hdr, byte_t *dest, size_t pass_len)
{
	for( ; pass_len > hdr->size; hdr = Rnext_page_head(hdr))
		pass_len -= hdr->size;
	memcpy(dest, (byte_t *)(hdr + 1) + pass_len, hdr->size - pass_len);
	dest += hdr->size - pass_len;
	for( ; hdr->next_page_index; dest += hdr->size)
	{
		hdr = Rnext_page_head(hdr);
		memcpy(dest, hdr + 1, hdr->size);
	}
}
void* PageCache::extract_val(data_hdr *hdr, size_t &val_len)
{
	size_t size    = *(size32_t *)(hdr + 1);
	size_t key_len = *((size32_t *)(hdr + 1) + 1);
	byte_t *val    = (byte_t *)malloc(val_len = size - key_len - sizeof(size32_t) - sizeof(size32_t));
	extract_val_copyer(hdr, val, key_len + sizeof(size32_t) + sizeof(size32_t));
	return val;
}
void* PageCache::extract_val(data_hdr *hdr, size_t &val_len, void *val_buf)
{
	size_t size     = *(size32_t *)(hdr + 1);
	size_t key_len  = *((size32_t *)(hdr + 1) + 1);
	size_t copy_len = size - key_len - sizeof(size32_t) - sizeof(size32_t);
	byte_t *val     = (byte_t *)(val_buf && copy_len <= val_len ? val_buf :  malloc(copy_len));
	val_len         = copy_len;
	extract_val_copyer(hdr, val, key_len + sizeof(size32_t) + sizeof(size32_t));
	return val;
}

void PageCache::free_data(data_hdr *hdr)
{
	PageCache *cache = this;
	do
	{
		hdr->size = 0;
		data_hdr *next, *cur = (data_hdr *)((ptrdiff_t)hdr & ~PAGEMASK);
		if(hdr != cur)
		{
			for(next = cur->next_head(); next != hdr; next = next->next_head())
				cur = next;
			if(cur->size == 0)
			{
				cache->clr_fragment((frag_hdr *)cur);
				cur->next = next->next;
			}
			else
				cur = next;
		}
		if((next = cur->next_head()) && next->size == 0)
		{
			cache->clr_fragment((frag_hdr *)next);
			cur->next = next->next;
		}
		hdr = hdr->next_page_index ? Wnext_page_head(hdr) : NULL;
		cache->set_fragment((frag_hdr *)cur);
	} while(hdr);
}

int PageCache::compare_key(index_hdr *hdr, const void *key, size_t key_len)
{
	if(size_t i_key_len = hdr->key_len)
	{
		if(int comp = memcmp(key, hdr->key, std::min(key_len, i_key_len)))
			return comp;
		return key_len - i_key_len;
	}
	if(key_len <= sizeof(hdr->key))
	{
		if(int comp = memcmp(key, hdr->key, key_len))
			return comp;
		return -1;
	}
	if(int comp = memcmp(key, hdr->key, sizeof(hdr->key)))
		return comp;

	data_hdr *ddr    = Rindex_hdr2data_hdr(hdr);
	size_t i_key_len = *((size32_t *)(ddr + 1) + 1);
	size_t cmp_len   = std::min(key_len, i_key_len);
	size_t min       = ddr->size - sizeof(size32_t) - sizeof(size32_t);
	byte_t *i_key    = (byte_t *)(ddr + 1) + sizeof(size32_t) + sizeof(size32_t);
	if(cmp_len <= min)
	{
		if(int comp = memcmp(key, i_key, cmp_len))
			return comp;
		return key_len - i_key_len;
	}
	if(int comp = memcmp(key, i_key, min))
		return comp;
	while(cmp_len -= min)
	{
		key = (byte_t *)key + min;
		ddr = Rnext_page_head(ddr);
		min = cmp_len < ddr->size ? cmp_len : ddr->size;
		if(int comp = memcmp(key, ddr + 1, min))
			return comp;
	}
	return key_len - i_key_len;
}

bool PageCache::put(const void *key, size_t key_len, const void *val, size_t val_len, bool replace)
{
	if(index_hdr *found = put_new_node(key, key_len, val, val_len))
	{
		if(!replace)
		{
			performance()->insert_reject();
			return false;
		}
		put_replace(found, key, key_len, val, val_len, false);
	}
	return true; 
}
void* PageCache::del(const void *key, size_t key_len, size_t& val_len)
{
	if(index_hdr *hdr = find(key, key_len))
	{
		performance()->remove_found();
		data_hdr *origin_hdr = Windex_hdr2data_hdr(hdr);
		void     *origin_val = extract_val(origin_hdr, val_len);
		free_data(origin_hdr);
		remove(hdr);
		return origin_val;
	}
	performance()->remove_not_found();
	return NULL;
}
bool PageCache::del(const void *key, size_t key_len)
{
	if(index_hdr *hdr = find(key, key_len))
	{
		performance()->remove_found();
		free_data(Windex_hdr2data_hdr(hdr));
		remove(hdr);
		return true;
	}
	performance()->remove_not_found();
	return false;
}

void PageCache::walk(index_hdr *hdr, IQueryKey *query)
{
	page_index_t lastPageIndex = 0;
	byte_t key_buf[WALKBUFFER];
	for(bool r = true; r && hdr; hdr = next_index_header(hdr))
	{
		page_index_t curPageIndex = Header2PageIndex(hdr);
		if(curPageIndex != lastPageIndex)
		{
			lastPageIndex = curPageIndex;
			hash.cleanup();
		}

		size_t key_len = sizeof(key_buf);
		void*  key     = extract_key(hdr, key_len, key_buf);
		r = query->update(key, key_len);
		if(key != key_buf) ::free(key);
	}
}
void PageCache::walk(index_hdr *hdr, IQueryData *query)
{
	page_index_t lastPageIndex = 0;
	byte_t data_buf[WALKBUFFER];
	for(bool r = true; r && hdr; hdr = next_index_header(hdr))
	{
		page_index_t curPageIndex = Header2PageIndex(hdr);
		if(curPageIndex != lastPageIndex)
		{
			lastPageIndex = curPageIndex;
			hash.cleanup();
		}

		//不要在query->update中调用hash.cleanup(), 比如checkpoint-->clr_snapshot-->cleanup这个路径
		//如果data_len太大读入Page会非常多, 可能会导致当前hdr所在的Page被清理掉
		size_t data_len = sizeof(data_buf);
		void*  data     = extract_data(hdr, data_len, data_buf);
		size_t key_len  = *((size32_t *)data + 1);
		size_t val_len  = *(size32_t *)data - key_len - sizeof(size32_t) - sizeof(size32_t);
		void*  key      = (byte_t *)data + sizeof(size32_t) + sizeof(size32_t);
		void*  val      = (byte_t *)key + key_len;
		r = query->update(key, key_len, val, val_len);
		if(data != data_buf) ::free(data);
	}
}
index_hdr* PageCache::find_key(const void *key, size_t key_len, int& pos)
{
	performance()->find_key();
	Page *page = root_index_page();
	if(size_t size = page->index_size())
		while(true)
		{
			index_hdr *hdr = page->index_begin();
			do
			{
				int half = size >> 1;
				pos = compare_key(hdr + half, key, key_len);
				if(pos > 0)
				{
					size -= half + 1;
					hdr  += half + 1;
				}
				else if(pos < 0)
					size  = half;
				else
					return hdr + half;
			} while(size);
			if(page_index_t page_index = hdr->l_child())
			{
				page = Rload(page_index);
				size = page->index_size();
			}
			else
				return hdr;
		}
	return NULL;
}
void PageCache::clr_fragment(frag_hdr *hdr)
{
	if(hdr->prev_page_index)
	{
		frag_hdr *frag_prev = Wprev_page_head(hdr);
		if(hdr->next_page_index)
		{
			frag_hdr *frag_next = Wnext_page_head(hdr);
			frag_prev->set_next(Header2PageIndex(frag_next), header_offset(frag_next));
			frag_next->set_prev(Header2PageIndex(frag_prev), header_offset(frag_prev));
		}
		else
			frag_prev->set_next(0, 0);
	}
	else
	{
		int i = ((data_hdr *)hdr)->capacity() / FRAG_STEP;
		if(hdr->next_page_index)
		{
			frag_hdr *frag_next = Wnext_page_head(hdr);
			magic.set_frag_page_position(i, Header2PageIndex(frag_next), header_offset(frag_next));
			frag_next->set_prev(0, 0);
		}
		else
			magic.set_frag_page_position(i, 0, 0);
	}
}
void PageCache::set_fragment(frag_hdr *hdr)
{
	page_pos_t capacity = ((data_hdr *)hdr)->capacity();
	if(capacity == PAGEMAXSPARE)
	{
		free_page(Header2Page(hdr));
		return;
	}
	int i = capacity / FRAG_STEP;
	page_index_t next_page_index = magic.get_frag_page_index(i);
	page_pos_t   next_page_pos   = magic.get_frag_page_pos(i);
	page_index_t curr_page_index = Header2PageIndex(hdr);
	page_pos_t   curr_page_pos   = header_offset(hdr);
	if(next_page_index)
		((frag_hdr*)Wload_hdr(next_page_index, next_page_pos))->set_prev(curr_page_index, curr_page_pos);
	hdr->set_next(next_page_index, next_page_pos);
	hdr->set_prev(0, 0);
	magic.set_frag_page_position(i, curr_page_index, curr_page_pos);
}
data_hdr* PageCache::__alloc_data_head(size_t size)
{
	struct {
		data_hdr* operator()(PageCache *_cache, data_hdr *_hdr, size_t _hdr_size)
		{
			if(_hdr_size < PAGEMAXSPARE)
			{
				_hdr->size = _hdr_size;
				_cache->adjust_data_head(_hdr);
			}
			else
				_hdr->size = PAGEMAXSPARE;
			return _hdr;
		}
	} adjuster;
	if(size < PAGEMAXSPARE)
	{
		for(int i = (size + FRAG_STEP - 1) / FRAG_STEP, e = PAGEUSED / FRAG_STEP; i < e; i++)
		{
			if(page_index_t next_page_index = magic.get_frag_page_index(i))
			{
				frag_hdr *hdr = (frag_hdr *)Wload_hdr(next_page_index, magic.get_frag_page_pos(i));
				magic.set_frag_page_position(i, next_page_index = hdr->next_page_index, hdr->next_page_pos);
				if(next_page_index)
					((frag_hdr *)Wload_hdr(next_page_index, hdr->next_page_pos))->set_prev(0, 0);
				return adjuster(this, (data_hdr *)hdr, size);
			}
		}
	}
	data_hdr *hdr = alloc_page(false)->layout_ptr()->data;
	hdr->next     = PAGEUSED;
	return adjuster(this, hdr, size);
}
void PageCache::create_node(index_hdr& index, const void *key, size_t key_len, const void *val, size_t val_len)
{
	if(key_len > sizeof(index.key))
	{
		memcpy(index.key, key, sizeof(index.key));
		index.key_len = 0;
	}
	else
	{
		memcpy(index.key, key, key_len);
		index.key_len = key_len;
	}
	size_t    size = key_len + val_len + sizeof(size32_t) + sizeof(size32_t);
	data_hdr  *hdr = alloc_data_head(index, size);
	byte_t      *p = (byte_t *)(hdr + 1);
	*(size32_t *)p = size;    p += sizeof(size32_t);
	*(size32_t *)p = key_len; p += sizeof(size32_t);
	if(hdr->size < size)
	{
		size -= sizeof(size32_t) + sizeof(size32_t);
		size_t capacity = hdr->size - sizeof(size32_t) - sizeof(size32_t);
		while(capacity < key_len)
		{
			memcpy(p, key, capacity);
			key      = (byte_t *)key + capacity;
			key_len -= capacity;
			size    -= capacity;
			hdr      = alloc_data_head(hdr, size);
			capacity = hdr->size;
			p        = (byte_t *)(hdr + 1);
		}
		memcpy(p, key, key_len);
		p        += key_len;
		capacity -= key_len;
		while(capacity < val_len)
		{
			memcpy(p, val, capacity);
			val      = (byte_t *)val + capacity;
			val_len -= capacity;
			hdr      = alloc_data_head(hdr, val_len);
			capacity = hdr->size;
			p        = (byte_t *)(hdr + 1);
		}
	}
	else
	{
		memcpy(p, key, key_len); p += key_len;
	}
	memcpy(p, val, val_len);
	hdr->set_next(0, 0);
}
//插入一定插在叶子节点
index_hdr* PageCache::put_new_node(const void *key, size_t key_len, const void *val, size_t val_len)
{
	int pos;
	if(index_hdr *found = find_key(key, key_len, pos))
	{
		if(pos == 0) return found;
		index_hdr index;
		create_node(index, key, key_len, val, val_len);
		insert_leaf(found, &index);
	}
	else
		create_node(*insert_init_node(), key, key_len, val, val_len);
	performance()->insert();
	return NULL;
}
void* PageCache::put_replace(index_hdr* found, const void *key, size_t key_len, const void *val, size_t& save_val_len, bool need_origin)
{
	performance()->insert_replace();
	data_hdr *hdr    = Windex_hdr2data_hdr(found);
	size_t val_len   = save_val_len;
	void* origin_val = need_origin ? extract_val(hdr, save_val_len) : NULL;
	size_t pass_len  = key_len + sizeof(size32_t) + sizeof(size32_t);
	size_t size      = pass_len + val_len;
	size_t capacity  = hdr->capacity();
	if(capacity < size && capacity < PAGEMAXSPARE)
	{
		Header2Page(found)->set_dirty();
		free_data(hdr);
		create_node(*found, key, key_len, val, val_len);
		return origin_val;
	}
	*(size32_t *)(hdr + 1) = size;
	for( ; pass_len > hdr->size; hdr = Rnext_page_head(hdr)) pass_len -= hdr->size;
	Header2Page(hdr)->set_dirty();
	byte_t *p     = (byte_t *)(hdr + 1) + pass_len;
	data_hdr *ndr = NULL;
	capacity      = hdr->capacity() - pass_len;
	if(val_len <= capacity)
	{
		memcpy(p, val, val_len);
		hdr->size = pass_len + val_len;
		if(hdr->next_page_index) ndr = Wnext_page_head(hdr);
		adjust_data_head(hdr);
	}
	else
	{
		memcpy(p, val, capacity);
		hdr->size = pass_len + capacity;
		val       = (byte_t *)val + capacity;
		val_len  -= capacity;
		while(hdr->next_page_index && (capacity = (ndr = Wnext_page_head(hdr))->size) < val_len && capacity == PAGEMAXSPARE)
		{
			hdr      = ndr;
			memcpy(hdr + 1, val, capacity);
			val      = (byte_t *)val + capacity;
			val_len -= capacity;
		}
		if(hdr->next_page_index == 0) ndr = NULL;
		if(ndr && (capacity = ndr->capacity()) >= val_len)
		{
			hdr       = ndr;
			ndr       = hdr->next_page_index ? Wnext_page_head(hdr) : NULL;
			memcpy(hdr + 1, val, val_len);
			hdr->size = val_len;
			adjust_data_head(hdr);
		}
		else while(val_len)
		{
			hdr       = alloc_data_head(hdr, val_len);
			capacity  = hdr->size;
			memcpy(hdr + 1, val, capacity);
			val       = (byte_t *)val + capacity;
			val_len  -= capacity;
		}
	}
	if(ndr) free_data(ndr);
	hdr->set_next(0, 0);
	return origin_val;
}
void PageCache::insert_leaf(index_hdr *pos, index_hdr *val)
{
	Page *page = Header2Page(pos);
	page->set_dirty();
	//左边到头了 or (pos在中间位置的右边 and 右边没到头)  此时往右移的话移动的元素较少
	if(page->index_l_pos() == 0 || (page->index_m_pos() < page->index_offset(pos) && page->index_r_pos() < INDEXCOUNT))
	{
		performance()->insert_leaf_adjust_right();
		for(index_hdr *tail = page->index_tail(); tail > pos; tail--)
			copy_key(tail, tail - 1);
		page->index_r_pos() ++;
	}
	else
	{
		performance()->insert_leaf_adjust_left();
		for(index_hdr *bgn = page->index_begin(); bgn < pos; bgn++)
			copy_key(bgn - 1, bgn);
		pos--;
		page->index_l_pos() --;
	}
	copy_key(pos, val);
	if(page->index_size() == INDEXCOUNT)
		split(page);
}
void PageCache::remove_leaf(index_hdr *pos)
{
	Page *page = Header2Page(pos);
	page->set_dirty();
	if(page->index_m_pos() < page->index_offset(pos))
	{
		for(index_hdr *tail = page->index_tail() - 1; pos < tail; pos++)
			copy_key(pos, pos + 1);
		page->index_r_pos() --;
	}
	else
	{
		for(index_hdr *bgn = page->index_begin(); pos > bgn; pos--)
			copy_key(pos, pos - 1);
		page->index_l_pos() ++;
	}
	if(page->index_size() < INDEXMINC && page->parent_index())
	{
		Page *parent = Wload(page->parent_index());
		index_hdr *parent_hdr = parent->index_pos(page->parent_pos());
		if(parent->index_r_pos() == page->parent_pos())//page have no right sibling
			l_shrink_leaf(page, parent_hdr - 1);//try steal one key from left sibling
		else
			r_shrink_leaf(page, parent_hdr);//try steal one key from right sibling
	}
}
index_hdr* PageCache::next_index_header(index_hdr *cur)
{
	//右子树的最小值
	if(cur->r_child())
		return left_most(Rload(cur->r_child()));
	//处于叶子节点, 右边的元素
	Page *page = Header2Page(cur);
	if(++cur < page->index_tail())
		return cur;
	//叶子节点最右边
	index_hdr *end = page->index_end();
	while(end->parent_index)
	{
		Page *parent = Rload(end->parent_index);
if(parent->get_type() != INDEX_PAGE) abort();
		if(end->parent_pos < parent->index_r_pos())
			return parent->index_pos(end->parent_pos);
		end = parent->index_end();
	}
	return NULL;
}
void PageCache::merge_sibling(Page *left, index_hdr *parent_hdr, Page *right)
{
	performance()->merge_sibling();
	index_hdr *sibling_bgn  = right->index_begin();
	page_pos_t sibling_size = right->index_size();
	//left所有元素左移
	if(INDEXCOUNT < left->index_r_pos() + sibling_size + 1)
	{
		performance()->merge_sibling_adjust();
		index_hdr *cur = left->index_pos(0);
		index_hdr *bgn = left->index_begin();
		if(bgn->l_child())
		{
			page_pos_t page_pos = 0;
			for(index_hdr *tail = left->index_tail(); bgn < tail; cur++, bgn++)
			{
				copy_key_and_left(cur, bgn);
				Wload(cur->l_child())->parent_pos() = page_pos++;
			}
			Wload(cur->l_child() = bgn->l_child())->parent_pos() = page_pos;
		}
		else
			for(index_hdr *tail = left->index_tail(); bgn < tail; copy_key(cur++, bgn++));
		left->index_r_pos() = left->index_size();
		left->index_l_pos() = 0;
	}
	Page *parent = Header2Page(parent_hdr);
	index_hdr *tail = left->index_tail();
	copy_key(tail, parent_hdr);
	memcpy(tail + 1, sibling_bgn, sibling_size * sizeof(index_hdr) + sizeof(page_index_t));
	left->index_r_pos() += sibling_size + 1;
	free_page(right);
	if((++tail)->l_child())
	{
		page_index_t page_index = left->index();
		page_pos_t   page_pos   = left->index_offset(tail);
		for(index_hdr *new_tail = left->index_tail() + 1; tail < new_tail; tail++)
			Wload(tail->l_child())->set_parent(page_index, page_pos++);
	}

	if(parent->index_m_pos() < parent->index_offset(parent_hdr))
	{
		for(index_hdr *parent_tail = parent->index_tail() - 1; parent_hdr < parent_tail; parent_hdr++)
		{
			copy_key_and_right(parent_hdr, parent_hdr + 1);
			Wload(parent_hdr->r_child())->parent_pos() --;
		}
		parent->index_r_pos() --;
	}
	else
	{
		for(index_hdr *parent_bgn = parent->index_begin(); parent_hdr > parent_bgn; parent_hdr--)
		{
			copy_key_and_right(parent_hdr, parent_hdr - 1);
			Wload(parent_hdr->l_child())->parent_pos() ++;
		}
		Wload(parent_hdr->r_child() = parent_hdr->l_child())->parent_pos() ++;
		parent->index_l_pos() ++;
	}

	if(parent->index_size() < INDEXMINC)
	{
		if(page_index_t ancestry_index = parent->parent_index())
		{
			performance()->merge_sibling_nest();
			Page *ancestry = Wload(ancestry_index);
			if(ancestry->index_r_pos() == parent->parent_pos())
				l_shrink_internal(parent, ancestry->index_pos(parent->parent_pos()) - 1);
			else
				r_shrink_internal(parent, ancestry->index_pos(parent->parent_pos()));
		}
		else if(parent->index_size() == 0)
		{
			left->set_parent(0, 0);
			magic.set_root_index_idx(left->index());
			free_page(parent);
		}
	}
}
void PageCache::insert_internal(Page *page, index_hdr *pos, index_hdr *mid, Page *l_child, Page *r_child)
{
	if(page->index_l_pos() == 0 || (page->index_m_pos() < page->index_offset(pos) && page->index_r_pos() < INDEXCOUNT))
	{
		performance()->insert_internal_adjust_right();
		for(index_hdr *tail = page->index_tail(); tail > pos; tail--)
		{
			Wload(tail->l_child())->parent_pos() ++;
			copy_key_and_right(tail, tail - 1);
		}
		page->index_r_pos() ++;
	}
	else
	{
		performance()->insert_internal_adjust_left();
		for(index_hdr *bgn = page->index_begin(); bgn < pos; bgn++)
		{
			Wload(bgn->l_child())->parent_pos() --;
			copy_key_and_left(bgn - 1, bgn);
		}
		pos--;
		page->index_l_pos() --;
	}
	copy_key(pos, mid);
	pos->l_child() = l_child->index();
	pos->r_child() = r_child->index();
	l_child->set_parent(page->index(), page->index_offset(pos));
	r_child->set_parent(page->index(), page->index_offset(pos) + 1);
	if(page->index_size() == INDEXCOUNT)
		split(page);
}

} // namespace __db_core
} // namespace lcore
