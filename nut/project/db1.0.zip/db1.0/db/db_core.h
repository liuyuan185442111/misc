#ifndef _L_DB_CORE_H
#define _L_DB_CORE_H

#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <vector>
#include <algorithm>
#include <functional>
#include "mutex.h"
#include "aligned_allocator.h"
#include "performance.h"

namespace lcore {
namespace __db_core {

struct IQueryKey {
	virtual ~IQueryKey() { }
	virtual bool update(const void *key, size_t key_len) = 0;
};

struct IQueryData {
	virtual ~IQueryData() { }
	virtual bool update(const void *key, size_t key_len, const void *val, size_t val_len) = 0;
};

typedef unsigned int   page_index_t;
typedef unsigned short page_pos_t;
typedef unsigned char  byte_t;
typedef unsigned int   size32_t;
typedef unsigned int   time32_t;

const int PAGESIZE = 4096;
const int PAGESLOTSIZE = 1024;
const int PAGEPOOLSLOTSIZE = 4096;
const int WALKBUFFER = 16384;
const int FRAG_STEP = 8;
const ptrdiff_t PAGEMASK = ((ptrdiff_t)(PAGESIZE-1)); //0x0FFF
const int PAGEUSED = PAGESIZE - 8;

inline time32_t time32_now() { return time(NULL) - 0; }
inline page_pos_t header_offset(void *p) { return (ptrdiff_t)p & PAGEMASK; }

/**
有4种Page: magic page, index page, data page, free page
magic page存放于文件头部
index page由多个index_hdr组成, index page被组织成b树, index_hdr中存储了key的部分值, 完整的key+value则存放于data page中
data page由至少1个data块和0或多个frag块组成, data块由三部分data_hdr、used_data、unused_data组成,
	frag块由两部分frag_hdr和frag_data组成, data块和frag块按物理顺序链成链表
key+value由至少1个data块组成, 它们被组织成链表
data_hdr和frag_hdr拥有两个相同的成员next和size, 且它们分别在data_hdr和frag_hdr中的相对位置也相同
需要data块时先从frag list查找有无合适frag块, 如有则将其转化为data块, 其容量可能大于实际需要的空间,
	size指示实际使用的空间, next可以指示容量; 如无合适的frag块, 则新分配一个页面, 取所需部分,
	如有剩余尝试查看其后是不是frag块, 如是则进行合并, 最后放入frag list中
一个占用整个页面的data块被释放时直接放到free page list中; 而一个小data块被释放时转化为frag块, size置为0,
	然后检测其前后是不是也是frag块, 如果也是则会合并它们, 因此需要从页面头部的data块/frag块依次找过来,
	合并之后形成的frag如果占用一个完整页面, 则将该页面放到free page list中, 否则放到frag list中
*/
#pragma pack(1)

struct data_hdr
{
	page_pos_t   next; //next header pos
	page_pos_t   size; //size of data, not 0

	page_index_t next_page_index;
	page_pos_t   next_page_pos;
	page_pos_t   first_slice; //bool

	data_hdr*    next_head() { return next != PAGEUSED ? (data_hdr *)(((ptrdiff_t)this & ~PAGEMASK) + next) : NULL; }
	size_t       capacity() { return next - header_offset(this) - sizeof(data_hdr); }
	void         set_next(page_index_t idx, page_pos_t pos) { next_page_index = idx; next_page_pos = pos; }
};

const size_t PAGEMAXSPARE = PAGEUSED - sizeof(data_hdr);

struct frag_hdr
{
	page_pos_t		next; //next header pos
	page_pos_t		size; //must be 0

	page_index_t	next_page_index;
	page_index_t	prev_page_index;
	page_pos_t		next_page_pos;
	page_pos_t		prev_page_pos;

	void	set_next(page_index_t idx, page_pos_t pos) { next_page_index = idx; next_page_pos = pos; }
	void	set_prev(page_index_t idx, page_pos_t pos) { prev_page_index = idx; prev_page_pos = pos; }
};

struct index_hdr
{
	page_index_t	child_index;
	union
	{
		struct
		{
			page_index_t	page_index; //page index of val data_hdr
			page_pos_t		page_pos;
			byte_t			key[5]; //start bytes of key
			byte_t			key_len;
		};

		struct
		{
			page_index_t	parent_index;
			page_pos_t		parent_pos;
			page_pos_t		l_pos;
			page_pos_t		r_pos;
		};
	};

	page_index_t& l_child() { return child_index; }
	page_index_t& r_child() { return (this+1)->child_index; }
	void set_data_position(page_index_t idx, page_pos_t pos) { page_index = idx; page_pos = pos; }
};

//每个节点最多包含的元素数目
const page_pos_t INDEXCOUNT = (PAGEUSED / sizeof(index_hdr)) - 1;
//每个非根节点最少包含的元素数目
const page_pos_t INDEXMINC = (INDEXCOUNT - 1) / 2;
const page_pos_t SHRINK_SHIFT = INDEXCOUNT / 4;

enum LoggerCommitResult { LCR_NULL, LCR_PREPARED, LCR_COMMIT, LCR_ABORT };
struct logger_hdr
{
	page_index_t	logger_first_idx;
	page_index_t	logger_last_idx;
	time32_t		logger_check_timestamp;
	page_index_t	check_result;
};

/** 为什么有8字节没有用
1. 最后的8字节用来放指向Page的指针, 从而使得各header能找得到Page
2. set_snapshot的时候前4字节用来放Page的序号, 后4字节用来放Page的类型,
   前者使得Logger的prepare阶段可以同时保存脏页面和脏页面的序号,
   后者使得PageBrowser可以轻松的判断出页面的类型
*/
union PageLayout
{
	char used[PAGEUSED];
	union
	{
		struct
		{
			page_index_t	free_page_list;
			page_index_t	root_index_idx;
			page_index_t	max_page_idx;
			time32_t		logger_last_check;
			page_index_t	logger_first_idx; //for PageLogger, should be 0 in file
			page_index_t	logger_magic_idx; //for PageLogger, should be 0 in file
			page_index_t	logger_serial; //for PageLogger
			time32_t		logger_id; //for GlobalLogger, would reset by PageLogger
			Performance		performance;
			//frag list headers, grouped by size
			//index:size 0:[0,8) 1:[8,16) 2:[16,24) ...
			//index 0 and index 1 are not used, see adjust_data_head
			page_index_t	frag_page_index[PAGEUSED/FRAG_STEP];
			page_pos_t		frag_page_pos[PAGEUSED/FRAG_STEP];
		};

		index_hdr	index[INDEXCOUNT + 1];
		data_hdr	data[1];

		struct
		{
			page_index_t	logger_page_first;
			page_index_t	logger_page_last;
			page_index_t	logger_rec_max;
			page_index_t	logger_rec_cur;
			time32_t		logger_chain;
			logger_hdr		logger_head[1];
		};
	};
};

#pragma pack()

class PageFile
{
	int	fd;
	char *name;
	size_t count_read, count_write, count_sync;
public:
	struct Exception { };
	~PageFile() { close(fd); free(name); }
#ifdef O_BINARY
	PageFile(const char *path, int flags = O_CREAT|O_RDWR|O_BINARY, mode_t mode = 0600)
#else
	PageFile(const char *path, int flags = O_CREAT|O_RDWR, mode_t mode = 0600)
#endif
	{
		if((fd = open(path, flags, mode)) == -1)
		{
			fprintf(stderr, "open %s failed: %s\n", path, strerror(errno));
			errno = 0;
			throw Exception();
		}
		count_read = count_write = count_sync = 0;
		const char *p = strrchr(path, '/');
		name = strdup(p ? p + 1 : path);
	}
	const char *identity() const { return name; }
	void read(page_index_t idx, void *data)
	{
		count_read++;
		if(pread(fd, data, PAGESIZE, (off_t)idx * PAGESIZE) != PAGESIZE)
		{
			if(errno)
			{
				fprintf(stderr, "read page %d of %s failed: %s\n", idx, name, strerror(errno));
				errno = 0;
			}
			throw Exception();
		}
	}
	void write(page_index_t idx, const void *data)
	{
		count_write++;
		if(pwrite(fd, data, PAGESIZE, (off_t)idx * PAGESIZE) != PAGESIZE)
		{
			fprintf(stderr, "write page %d of %s failed: %s\n", idx, name, strerror(errno));
			errno = 0;
			throw Exception();
		}
	}
	void truncate(page_index_t idx)
	{
		if(ftruncate(fd, (off_t)idx * PAGESIZE) == -1)
		{
			fprintf(stderr, "truncate %s of %d pages failed: %s\n", name, idx, strerror(errno));
			errno = 0;
			throw Exception();
		}
	}
	void sync()
	{
		count_sync++;
		if(fsync(fd) == -1)
		{
			fprintf(stderr, "sync %s failed: %s\n", name, strerror(errno));
			errno = 0;
			throw Exception();
		}
	}
	size_t read_counter()  const { return count_read;  }
	size_t write_counter() const { return count_write; }
	size_t sync_counter()  const { return count_sync;  }
};

class PageMemory {
	typedef AlignedMemoryBlock<PAGESIZE, PAGESLOTSIZE> PageMemoryType;
	static PageMemoryType mem;
	static Thread::SpinLock locker;
public:
	static void *alloc() { Thread::SpinLock::Scoped l(locker); return mem.alloc(); }
	static void free(void *p) { Thread::SpinLock::Scoped l(locker); mem.free(p); }
};

enum { FREE_PAGE,INDEX_PAGE,DATA_PAGE };
class Page
{
	const page_index_t idx;
	page_index_t type;
	size_t		lru;
	Page		*next_hash_equal;
	PageLayout	*layout;
	PageLayout	*snapshot;
	bool dirty;

	struct lruless { bool operator()(Page * p1, Page * p2) const { return p1->lru < p2->lru; } };
public:
	static void sort_lru(Page **it, Page **ie) { std::sort(it, ie, lruless()); }

	Page(page_index_t index) : idx(index), type(0), lru(0), next_hash_equal(NULL),
		layout((PageLayout *)PageMemory::alloc()), snapshot(NULL), dirty(false) { *(Page **)(layout + 1) = this; }
	~Page() { PageMemory::free(layout); }

	page_index_t index() const { return idx; }
	void set_type(page_index_t page_type) { type = page_type; }
	page_index_t get_type() const { return type; }
	
	void set_lru(size_t l) { lru = l; }
	Page *get_next_hash_equal() const { return next_hash_equal; }
	void set_next_hash_equal(Page *page) { next_hash_equal = page; }

	PageLayout *layout_ptr() { return layout; }
	const PageLayout *layout_ptr() const { return layout; }

	//snapshot
	const PageLayout* snapshot_ptr() const { return snapshot; }
	bool set_snapshot()
	{
		if(dirty)
		{
			PageLayout *tmp = (PageLayout *)PageMemory::alloc();
			memcpy(tmp, layout, PAGESIZE);
			*(page_index_t *)(tmp + 1) = idx;
			*((page_index_t *)(tmp + 1) + 1) = type;
			snapshot = tmp;
			dirty = false;
			return true;
		}
		return false;
	}
	bool clr_snapshot() { PageMemory::free(snapshot); snapshot = NULL; return dirty; }
	Page* set_dirty() { dirty = true; return this; }
	bool is_clean() const { return !dirty; }

	//magic page
	void init_magic() { memset(layout, 0, sizeof(PageLayout)); }
	page_index_t get_root_index_idx() const { return layout->root_index_idx; }
	void set_root_index_idx(page_index_t idx) { set_dirty(); layout->root_index_idx = idx; }
	page_index_t get_free_page_list() const { return layout->free_page_list; }
	void set_free_page_list(page_index_t idx) { set_dirty(); layout->free_page_list = idx; }
	page_index_t get_frag_page_index(int i) const { return layout->frag_page_index[i]; }
	page_pos_t   get_frag_page_pos  (int i) const { return layout->frag_page_pos[i];   }
	void set_frag_page_position(int i, page_index_t page_index, page_pos_t page_pos)
	{
		set_dirty(); layout->frag_page_index[i] = page_index; layout->frag_page_pos[i] = page_pos;
	}
	page_index_t extend_page() { set_dirty(); return ++layout->max_page_idx; }

	//index page
	index_hdr*    index_end()    { return layout->index + INDEXCOUNT; }
	index_hdr*    index_begin()  { return layout->index + index_end()->l_pos; }
	index_hdr*    index_tail()   { return layout->index + index_end()->r_pos; }
	index_hdr*    index_pos(page_pos_t page_pos) { return layout->index + page_pos; }
	page_pos_t&   index_l_pos()  { return index_end()->l_pos; }
	page_pos_t&   index_r_pos()  { return index_end()->r_pos; }
	page_pos_t    index_m_pos()  { index_hdr *end = index_end(); return (end->r_pos + end->l_pos) >> 1; }
	page_pos_t    index_size()   { index_hdr *end = index_end(); return end->r_pos - end->l_pos; }
	static page_pos_t index_offset(index_hdr *hdr) { return header_offset(hdr) / sizeof(index_hdr); }
	page_index_t& parent_index() { return index_end()->parent_index; }
	page_pos_t&   parent_pos()   { return index_end()->parent_pos; }
	void set_parent(page_index_t parent_index, page_pos_t parent_pos)
	{
		index_hdr *end = index_end();
		end->parent_index = parent_index;
		end->parent_pos = parent_pos;
	}

	static void* operator new(size_t size);
	static void operator delete(void *p);
};

class PagePool {
	typedef AlignedMemoryBlock<sizeof(Page), PAGEPOOLSLOTSIZE> PagePoolType;
	static PagePoolType pool;
	static lcore::Thread::SpinLock locker;
public:
	static void *alloc() { Thread::SpinLock::Scoped l(locker); return pool.alloc(); }
	static void free(void *p) { Thread::SpinLock::Scoped l(locker); return pool.free(p); }
};
inline void* Page::operator new(size_t size) { return PagePool::alloc(); }
inline void Page::operator delete(void *p) { return PagePool::free(p); }

class PageHash
{
	size_t	lru; //next lru sequence number
	size_t	count; //current element count
	size_t	bucket_mask; //bucket_size - 1
	size_t	snapshot_size, snapshot_capacity;
	size_t	cache_high, cache_low;
	Page**	bucket;
	Page**	snapshot;
	PageFile *page_file;

	Page* load_page(page_index_t idx)
	{
		Page *page = new Page(idx);
		try
		{
			page_file->read(idx, page->layout_ptr());
			//idx == *(page_index_t *)(page->layout_ptr() + 1)
			page->set_type(*((page_index_t *)(page->layout_ptr() + 1) + 1));
			*(Page **)(page->layout_ptr() + 1) = page;
		}
		catch(PageFile::Exception e)
		{
			delete page;
			return NULL;
		}
		return insert(page);
	}

	void erase_page(Page *page)
	{
		Page **it = bucket + (page->index() & bucket_mask);
		if(page == *it)
			*it = page->get_next_hash_equal();
		else for(Page *next_next, *next = *it; next; next = next_next)
			if((next_next = next->get_next_hash_equal()) == page)
			{
				next->set_next_hash_equal(page->get_next_hash_equal());
				break;
			}
		count--;
		delete page;
	}

	Page* lru_adjust(Page *page)
	{
		page->set_lru(lru);
		if(++lru == 0)
		{
			Page **tmp = (Page **)malloc(count * sizeof(Page *)), **it = tmp, **ii = tmp;
			for(Page** it = bucket, **ie = bucket + bucket_mask + 1; it != ie; ++it)
				for(Page *page = *it ; page ; page = page->get_next_hash_equal())
					*ii++ = page;
			Page::sort_lru(it, ii);
			for(lru = 0; it != ii; ++it)
				(*it)->set_lru(lru++);
			free(tmp);
		}
		return page;
	}

public:
	void cleanup()
	{
		if(count <= cache_high)
			return;
		Page **tmp = (Page **)malloc(count * sizeof(Page *)), **it = tmp, **ii = tmp;
		for(Page** it = bucket, **ie = bucket + bucket_mask + 1; it != ie; ++it)
			for(Page *page = *it ; page ; page = page->get_next_hash_equal())
				*ii++ = page;
		Page::sort_lru(it, ii);
		for(lru = 0; count > cache_low && it != ii; ++it)
			if((*it)->is_clean()) erase_page(*it);
			else (*it)->set_lru(lru++);
		for(; it != ii; ++it)
			(*it)->set_lru(lru++);
		free(tmp);
	}

	~PageHash()
	{
		clear();
		free(bucket);
		free(snapshot);
	}

	PageHash() : lru(0), count(0), bucket_mask(15), snapshot_size(0), snapshot_capacity(0), bucket(NULL), snapshot(NULL) { }

	void init(PageFile *file, size_t high, size_t low)
	{
		page_file = file;
		cache_high = high;
		cache_low = low;
		size_t bucket_size = bucket_mask + 1;
		while(bucket_size < cache_high) bucket_size <<= 1;
		bucket_mask = bucket_size - 1;
		bucket = (Page **)malloc(bucket_size * sizeof(Page *));
		memset(bucket, 0, bucket_size * sizeof(Page *));
	}

	size_t size() const { return count; }

	Page** snapshot_reference(size_t& size) { size = snapshot_size; return snapshot; }

	size_t snapshot_create(Page *magic)
	{
		if(snapshot_capacity < count + 1)
		{
			free(snapshot);
			snapshot = (Page **)malloc((snapshot_capacity = count + 1) * sizeof(Page *));
		}
		snapshot_size = 0;
		for(Page **it = bucket, **ie = bucket + bucket_mask + 1; it != ie; ++it)
			for(Page *page = *it ; page ; page = page->get_next_hash_equal())
				if(page->set_snapshot())
					snapshot[snapshot_size++] = page;
		if(snapshot_size)
		{
			magic->set_dirty()->set_snapshot();
			snapshot[snapshot_size++] = magic;
		}
		else if(magic->set_snapshot())
			snapshot[snapshot_size++] = magic;
		return snapshot_size;
	}

	void snapshot_release()
	{
		for(Page **it = snapshot, **ie = snapshot + snapshot_size; it != ie; ++it)
			(*it)->clr_snapshot();
		cleanup();
	}

	Page* insert(Page *page)
	{
		struct {
			void operator()(Page *_page, Page** _bucket, size_t _mask)
			{
				Page** it = _bucket + (_page->index() & _mask);
				_page->set_next_hash_equal(*it);
				*it = _page;
			}
		} inserter;
		inserter(page, bucket, bucket_mask);
		if(count++ == bucket_mask)
		{
			size_t tmp_mask = ((bucket_mask + 1) << 1) - 1;
			Page** tmp = (Page **)malloc((tmp_mask + 1) * sizeof(Page *));
			memset(tmp, 0, (tmp_mask + 1) * sizeof(Page *));
			for(Page **it = bucket, **ie = bucket + bucket_mask + 1; it != ie; ++it)
			{
				for(Page *next, *page = *it ; page ; page = next)
				{
					next = page->get_next_hash_equal();
					inserter(page, tmp, tmp_mask);
				}
			}
			free(bucket);
			bucket      = tmp;
			bucket_mask = tmp_mask;
		}
		return lru_adjust(page);
	}

	Page* find(page_index_t page_index)
	{
		for(Page *page = bucket[page_index & bucket_mask]; page; page = page->get_next_hash_equal())
			if(page->index() == page_index)
				return lru_adjust(page);
		return load_page(page_index);
	}

	void clear()
	{
		for(Page **it = bucket, **ie = bucket + bucket_mask + 1; it != ie; ++it)
		{
			if(Page *page = *it)
			{
				*it = NULL;
				Page *next;
				do {
					next = page->get_next_hash_equal();
					delete page;
				} while((page = next));
			}
		}
		count = 0;
	}
};

////////////////////////////////////////////////////////////////////////////////

class PageCache
{
	PageFile  *page_file;
	Page       magic;
	PageHash   hash;
public:
	PageCache(PageFile *file, size_t cache_high, size_t cache_low) : page_file(file), magic(0)
	{
		hash.init(file, cache_high, cache_low);
		try { page_file->read(0, magic.layout_ptr()); *(Page **)(magic.layout_ptr() + 1) = &magic; }
		catch(PageFile::Exception e) { magic.init_magic(); magic.set_root_index_idx(alloc_page()->index()); }
		Performance *perf = performance();
		perf->set_cache_high(cache_high);
		perf->set_cache_low(cache_low);
		perf->reset_peak();
		perf->set_page_read(0);
		perf->set_page_write(0);
		perf->set_page_sync(0);
	}
	PageLayout* magic_layout_ptr() { return magic.layout_ptr(); }
	Performance* performance() { return &magic.layout_ptr()->performance; }

	//key_len cannot be 0, val_len can be 0
	bool put(const void *key, size_t key_len, const void *val, size_t val_len, bool replace);
	//need free return pointer
	void* put(const void *key, size_t key_len, const void *val, size_t& val_len)
	{
		if(index_hdr *found = put_new_node(key, key_len, val, val_len))
			return put_replace(found, key, key_len, val, val_len, true);
		return NULL; 
	}

	//need free return pointer
	void* find(const void *key, size_t key_len, size_t &val_len)
	{
		index_hdr *hdr = find(key, key_len);
		return hdr ? extract_val(hdr, val_len) : NULL;
	}
	//need free return pointer if it not equals val_buf
	void* find(const void *key, size_t key_len, size_t &val_len, void *val_buf)
	{
		index_hdr *hdr = find(key, key_len);
		return hdr ? extract_val(hdr, val_len, val_buf) : NULL;
	}

	//need free return pointer
	void* del(const void *key, size_t key_len, size_t& val_len);
	bool del(const void *key, size_t key_len);

	bool exist(const void *key, size_t key_len) { return find(key, key_len); }
	size_t record_count() { return performance()->record_count(); }

	//need free return pointer
	void* first_key(size_t &key_len)
	{
		index_hdr *hdr = left_most(root_index_page());
		return hdr ? extract_key(hdr, key_len) : NULL;
	}
	//need free return pointer
	void* next_key(const void *key, size_t &key_len)
	{
		if(index_hdr *hdr = greater_key(key, key_len))
			return extract_key(hdr, key_len);
		return NULL;
	}

	template<typename T>
	void walk(T *query) { walk(left_most(root_index_page()), query); }
	template<typename T>
	void walk(const void *key, size_t key_len, T *query) { walk(great_equal_key(key, key_len), query); }

	Page** snapshot_reference(size_t &snapshot_size) { return hash.snapshot_reference(snapshot_size); }
	void snapshot_create() { performance()->set_dirty_peak(hash.snapshot_create(&magic)); }
	void snapshot_release()
	{
		Performance *perf = performance();
		perf->set_page_read (page_file->read_counter());
		perf->set_page_write(page_file->write_counter());
		perf->set_page_sync (page_file->sync_counter());
		perf->set_cache_peak(hash.size());
		hash.snapshot_release();
	}

	//----------Internal Functions
public:
	static inline Page* Header2Page(void *p) { return *(Page **)((PageLayout *)((ptrdiff_t)p & ~PAGEMASK) + 1); }
	static inline page_index_t Header2PageIndex(void *p) { return Header2Page(p)->index(); }
	//不复制child_index, 叶子节点不会上升变成非叶子的child_index始终是0
	static inline void copy_key(index_hdr *dst, index_hdr *src)
	{
		memcpy((page_index_t *)dst+1, (page_index_t *)src+1, sizeof(index_hdr)-sizeof(page_index_t));
	}
	static inline void copy_key_and_left(index_hdr *dst, index_hdr *src)
	{
		memcpy(dst, src, sizeof(index_hdr));
	}
	static inline void copy_key_and_right(index_hdr *dst, index_hdr *src)
	{
		memcpy((page_index_t *)dst+1, (page_index_t *)src+1, sizeof(index_hdr));
	}

	//----------page
	Page *Rload(page_index_t idx) { return hash.find(idx); }
	Page *Wload(page_index_t idx) { return hash.find(idx)->set_dirty(); }
	void *Rload_hdr(page_index_t idx, page_pos_t pos) { return (byte_t *)(Rload(idx)->layout_ptr()) + pos; }
	void *Wload_hdr(page_index_t idx, page_pos_t pos) { return (byte_t *)(Wload(idx)->layout_ptr()) + pos; }

	data_hdr* Rnext_page_head(data_hdr *hdr) { return (data_hdr *)Rload_hdr(hdr->next_page_index, hdr->next_page_pos); }
	data_hdr* Wnext_page_head(data_hdr *hdr) { return (data_hdr *)Wload_hdr(hdr->next_page_index, hdr->next_page_pos); }
	frag_hdr* Wnext_page_head(frag_hdr *hdr) { return (frag_hdr *)Wload_hdr(hdr->next_page_index, hdr->next_page_pos); }
	frag_hdr* Wprev_page_head(frag_hdr *hdr) { return (frag_hdr *)Wload_hdr(hdr->prev_page_index, hdr->prev_page_pos); }
	data_hdr* Rindex_hdr2data_hdr(index_hdr *hdr) { return (data_hdr *)Rload_hdr(hdr->page_index, hdr->page_pos); }
	data_hdr* Windex_hdr2data_hdr(index_hdr *hdr) { return (data_hdr *)Wload_hdr(hdr->page_index, hdr->page_pos); }

	Page *alloc_page(bool index_page = true)
	{
		performance()->page_alloc();
		Page *page;
		if(page_index_t idx = magic.get_free_page_list())
		{
			page = hash.find(idx);
			magic.set_free_page_list(page->get_free_page_list());
		}
		else
			page = hash.insert(new Page(magic.extend_page()));
		memset(page->layout_ptr(), 0, sizeof(PageLayout));
		page->set_type(index_page ? INDEX_PAGE : DATA_PAGE);
		return page->set_dirty();
	}
	void free_page(Page *page)
	{
		performance()->page_free();
		page->set_type(FREE_PAGE);
		page->set_free_page_list(magic.get_free_page_list());
		magic.set_free_page_list(page->index());
	}
	Page *alloc_root_index_page()
	{
		Page *page = alloc_page();
		magic.set_root_index_idx(page->index());
		return page;
	}
	Page *root_index_page() { return Rload(magic.get_root_index_idx()); }

	//----------fragment
	void set_fragment(frag_hdr *hdr);
	void clr_fragment(frag_hdr *hdr);

	//if hdr->capacity() is too large, adjust it
	//all data_dhr and frag_hdr are aligned by 16 bytes
	void adjust_data_head(data_hdr *hdr)
	{
		//a frag at least needs 16 bytes capacity, because data_hdr.size is at least 9(sizeof(size32_t)+sizeof(size32_t)+1)
		if(hdr->capacity() >= ((sizeof(data_hdr) + hdr->size + 15) & ~15) + sizeof(data_hdr) + 16)
		{
			data_hdr *ndr = (data_hdr *)((ptrdiff_t)((byte_t *)(hdr + 1) + hdr->size + 15) & ~(ptrdiff_t)15);
			data_hdr *next = hdr->next_head();
			if(next && next->size == 0)
			{
				clr_fragment((frag_hdr *)next);
				ndr->next = next->next;
			}
			else
				ndr->next = hdr->next;
			ndr->size = 0;
			set_fragment((frag_hdr *)ndr);
			hdr->next = header_offset(ndr);
		}
	}

	//----------data_hdr
	data_hdr* __alloc_data_head(size_t size);
	data_hdr* alloc_data_head(index_hdr &idx, size_t size)
	{
		data_hdr *hdr = __alloc_data_head(size);
		hdr->first_slice = 1;
		idx.set_data_position(Header2PageIndex(hdr), header_offset(hdr));
		return hdr;
	}
	data_hdr* alloc_data_head(data_hdr *pdr, size_t size)
	{
		data_hdr *hdr = __alloc_data_head(size);
		hdr->first_slice = 0;
		pdr->set_next(Header2PageIndex(hdr), header_offset(hdr));
		return hdr;
	}
	void free_data(data_hdr *hdr);
	void create_node(index_hdr& index, const void *key, size_t key_len, const void *val, size_t val_len);

	//----------extract
	void extract_key_copyer(data_hdr *hdr, byte_t *dest, size_t copy_len);
	void extract_val_copyer(data_hdr *hdr, byte_t *dest, size_t pass_len);
	void* extract_data(data_hdr *hdr, size_t &size, void *data_buf);
	void* extract_key (data_hdr *hdr, size_t &key_len);
	void* extract_key (data_hdr *hdr, size_t &key_len, void *key_buf);
	void* extract_val (data_hdr *hdr, size_t &val_len, void *val_buf);
	void* extract_val (data_hdr *hdr, size_t &val_len);

	void* extract_data(index_hdr *hdr, size_t &size, void *data_buf) { return extract_data(Rindex_hdr2data_hdr(hdr), size, data_buf); }
	void* extract_key(index_hdr *hdr, size_t &key_len);
	void* extract_key(index_hdr *hdr, size_t &key_len, void *key_buf);
	void* extract_val(index_hdr *hdr, size_t &val_len) { return extract_val(Rindex_hdr2data_hdr(hdr), val_len); }
	void* extract_val(index_hdr *hdr, size_t &val_len, void *val_buf) { return extract_val(Rindex_hdr2data_hdr(hdr), val_len, val_buf); }

	//----------find
	//>0:key is greater  <0:key is less  0:equal
	int compare_key(index_hdr *hdr, const void *key, size_t key_len);
	/*
	@return   &pos  result
	NULL      N/A   NOT FOUND: empty
	NOT NULL  0     FOUND:   equals key
	NOT NULL  >0    GREATER: the greater after key or the index_tail()
	NOT NULL  <0    GREATER: the greater after key, key is less than all keys in table
	*/
	//in the last 2 situations, the return value must be at leaf node
	index_hdr* find_key(const void *key, size_t key_len, int& pos);
	index_hdr* find(const void *key, size_t key_len)
	{
		int pos;
		index_hdr *hdr = find_key(key, key_len, pos);
		return (hdr && !pos) ? hdr : NULL;
	}
	index_hdr* left_most(Page *page)
	{
		index_hdr *bgn = page->index_begin();
		while(bgn->l_child())
			bgn = Rload(bgn->l_child())->index_begin();
		return bgn < Header2Page(bgn)->index_tail() ? bgn : NULL;
	}
	index_hdr* next_index_header(index_hdr *cur);
	index_hdr* greater_key(const void *key, size_t key_len)
	{
		int pos = 0;
		if(index_hdr *hdr = find_key(key, key_len, pos))
		{
			if(pos == 0) // equals found.
				return next_index_header(hdr); // return NULL if the key is last. see next_index_header.
			if(hdr != Header2Page(hdr)->index_tail()) // greater found. maybe tail. see great_equal_key.
				return hdr;
		}
		return NULL;
	}
	index_hdr* great_equal_key(const void *key, size_t key_len)
	{
		int pos;
		index_hdr* hdr = find_key(key, key_len, pos); 
		return (hdr && hdr == Header2Page(hdr)->index_tail()) ? NULL : hdr;
	}

	void walk(index_hdr *hdr, IQueryKey *query);
	void walk(index_hdr *hdr, IQueryData *query);

	//----------put
	index_hdr* insert_init_node()
	{
		Page *root_page = root_index_page();
		root_page->set_dirty();
		root_page->index_l_pos() = INDEXMINC;
		root_page->index_r_pos() = INDEXMINC + 1;
		index_hdr *bgn = root_page->index_begin();
		bgn->l_child() = bgn->r_child() = 0;
		return bgn;
	}
	index_hdr* put_new_node(const void *key, size_t key_len, const void *val, size_t val_len);
	void* put_replace(index_hdr* found, const void *key, size_t key_len, const void *val, size_t& save_val_len, bool need_origin);
	void insert_leaf(index_hdr *pos, index_hdr *val);

	//----------split
	//page中的元素数目达到了INDEXCOUNT
	//分裂成两个子节点, 并拿出中间的元素来做为父元素
	void split(Page *page)
	{
		performance()->split();
		page_pos_t left_count = (INDEXCOUNT >> 1);
		page_pos_t right_count = INDEXCOUNT - left_count - 1;
		index_hdr *mid = page->index_pos(left_count);
		page->index_r_pos() = left_count;

		Page *parent = page->parent_index() ? Wload(page->parent_index()) : alloc_root_index_page();
		Page *sibling = alloc_page();
		sibling->index_l_pos() = SHRINK_SHIFT;
		sibling->index_r_pos() = SHRINK_SHIFT + right_count;
		index_hdr *sibling_bgn = sibling->index_pos(SHRINK_SHIFT);
		memcpy(sibling_bgn, mid + 1, right_count * sizeof(index_hdr) + sizeof(page_index_t));
		if(sibling_bgn->l_child())
		{
			page_index_t sibling_index = sibling->index();
			for(page_pos_t i = 0; i <= right_count; i++)
				Wload((sibling_bgn + i)->l_child())->set_parent(sibling_index, SHRINK_SHIFT + i);
		}
		insert_internal(parent, parent->index_pos(page->parent_pos()), mid, page, sibling);
	}

	//put mid in front of pos
	void insert_internal(Page *page, index_hdr *pos, index_hdr *mid, Page *l_child, Page *r_child);

	//----------remove
	void remove(index_hdr *pos)
	{
		if(pos->l_child()) remove_internal(pos);
		else remove_leaf(pos);
	}
	void remove_internal(index_hdr *pos)
	{
		Header2Page(pos)->set_dirty();
		performance()->remove_internal();
		//right_most of left child
		index_hdr *right_most;
		for(right_most = Rload(pos->l_child())->index_tail() - 1; right_most->r_child(); right_most = Rload(right_most->r_child())->index_tail() - 1);
		copy_key(pos, right_most);
		remove_leaf(right_most);
	}
	void remove_leaf(index_hdr *pos);

	//----------merge
	void merge_sibling(Page *left, index_hdr *parent_hdr, Page *right);

	void r_shrink_internal(Page *page, index_hdr *parent_hdr)
	{
		performance()->r_shrink_internal();
		Page *sibling = Wload(parent_hdr->r_child());

		if(sibling->index_size() > INDEXMINC)
		{
			index_hdr *sibling_bgn = sibling->index_begin();
			index_hdr *tail        = page->index_tail();
			if(page->index_r_pos() == INDEXCOUNT)
			{
				performance()->r_shrink_internal_adjust();
				index_hdr *cur = page->index_pos(SHRINK_SHIFT);
				index_hdr *bgn = page->index_begin();
				for( ;bgn < tail; bgn++, cur++)
				{
					copy_key_and_left(cur, bgn);
					Wload(cur->l_child())->parent_pos() = page->index_offset(cur);
				}
				Wload(cur->l_child() = bgn->l_child())->parent_pos() = page->index_offset(cur);
				page->index_l_pos() = SHRINK_SHIFT;
				page->index_r_pos() = SHRINK_SHIFT + INDEXMINC - 1;
				tail = page->index_tail();
			}
			copy_key(tail, parent_hdr);
			copy_key(parent_hdr, sibling_bgn);
			Wload(tail->r_child() = sibling_bgn->l_child())->set_parent(page->index(), page->index_offset(tail) + 1); 
			page->index_r_pos() ++;
			sibling->index_l_pos() ++;
		}
		else
			merge_sibling(page, parent_hdr, sibling);
	}

	//将右孩子(sibling)的数据拿一个给左孩子(page)
	//此时左孩子有INDEXMINC-1个元素
	void r_shrink_leaf(Page *page, index_hdr *parent_hdr)
	{
		performance()->r_shrink_leaf();
		Page *sibling = Wload(parent_hdr->r_child());

		if(sibling->index_size() > INDEXMINC)
		{
			if(page->index_r_pos() == INDEXCOUNT)
			{
				performance()->r_shrink_leaf_adjust();
				for(index_hdr *cur = page->index_pos(SHRINK_SHIFT), *bgn = page->index_begin(), *tail = page->index_tail(); bgn < tail; copy_key(cur++, bgn++));
				page->index_l_pos() = SHRINK_SHIFT;
				page->index_r_pos() = SHRINK_SHIFT + INDEXMINC - 1;
			}
			copy_key(page->index_tail(), parent_hdr);
			copy_key(parent_hdr, sibling->index_begin());
			page->index_r_pos() ++;
			sibling->index_l_pos() ++;
		}
		else
			merge_sibling(page, parent_hdr, sibling);
	}

	void l_shrink_internal(Page *page, index_hdr *parent_hdr)
	{
		performance()->l_shrink_internal();
		Page *sibling = Wload(parent_hdr->l_child());

		if(sibling->index_size() > INDEXMINC)
		{
			if(page->index_l_pos() == 0)
			{
				performance()->l_shrink_internal_adjust();
				index_hdr *tail = page->index_tail();
				index_hdr *cur  = tail + SHRINK_SHIFT;
				for(index_hdr *bgn = page->index_begin(); tail > bgn;)
				{
					copy_key_and_right(--cur, --tail);
					Wload(cur->r_child())->parent_pos() += SHRINK_SHIFT;
				}
				Wload(cur->l_child() = tail->l_child())->parent_pos() += SHRINK_SHIFT;
				page->index_l_pos() = SHRINK_SHIFT - 1;
				page->index_r_pos() = SHRINK_SHIFT + INDEXMINC - 1;
			}
			else
				page->index_l_pos() --;
			sibling->index_r_pos() --;
			index_hdr *sibling_tail = sibling->index_tail();
			index_hdr *bgn          = page->index_begin();
			copy_key(bgn, parent_hdr);
			copy_key(parent_hdr, sibling_tail);
			Wload(bgn->l_child() = sibling_tail->r_child())->set_parent(page->index(), page->index_offset(bgn));
		}
		else
			merge_sibling(sibling, parent_hdr, page);
	}

	//将左孩子(sibling)的元素拿一个给右孩子(page)
	//此时右孩子有INDEXMINC-1个元素
	void l_shrink_leaf(Page *page, index_hdr *parent_hdr)
	{
		performance()->l_shrink_leaf();
		Page *sibling = Wload(parent_hdr->l_child());

		if(sibling->index_size() > INDEXMINC)
		{
			if(page->index_l_pos() == 0)
			{
				performance()->l_shrink_leaf_adjust();
				for(index_hdr *tail = page->index_tail(), *bgn = page->index_begin(), *cur = tail + SHRINK_SHIFT; tail > bgn; copy_key(--cur, --tail));
				page->index_l_pos() = SHRINK_SHIFT - 1;
				page->index_r_pos() = SHRINK_SHIFT + INDEXMINC - 1;
			}
			else
				page->index_l_pos() --;
			copy_key(page->index_begin(), parent_hdr);
			sibling->index_r_pos() --;
			copy_key(parent_hdr, sibling->index_tail());
		}
		else
			//兄弟也没有余粮了
			merge_sibling(sibling, parent_hdr, page);
	}
};

////////////////////////////////////////////////////////////////////////////////

class Logger
{
public:
	enum State { CLEAN, PREPARED, REDO, CORRUPT };
	virtual ~Logger() { }
	virtual void  init(PageFile *file, PageCache *cache) = 0;
	virtual State integrity_verify() { return CLEAN; }
	virtual State truncate() { return CLEAN; }
	virtual State redo(time32_t timestamp) { return CLEAN; }
	virtual State prepare() { return PREPARED; }
	virtual State commit(time32_t timestamp) = 0;
	virtual State abort() { return CLEAN; }

	static void save_page(PageFile *page_file, const Page *page, page_index_t page_index)
	{
		page_file->write(page_index, page->snapshot_ptr());
	}

	static void save_page(Page **it, Page **ie, PageFile *page_file)
	{
		for( ; it != ie; ++it)
			save_page(page_file, *it, (*it)->index());
	}

	static page_index_t save_page(Page **it, Page **ie, PageFile *log_file, page_index_t page_index)
	{
		for( ; it != ie; ++it)
			save_page(log_file, *it, page_index++);
		return page_index;
	}

	static void restore_page(PageFile *log_file, page_index_t it, page_index_t ie, PageFile *page_file)
	{
		PageLayout *layout = (PageLayout *)PageMemory::alloc();
		for( ; it != ie; ++it)
		{
			log_file->read(it, layout);
			page_file->write(*(page_index_t *)(layout + 1), layout);
		}
		PageMemory::free(layout);
	}
};

class NullLogger : public Logger
{
	PageFile  *page_file;
	PageCache *page_cache;
public:
	void init(PageFile *file, PageCache *cache)
	{
		page_file  = file;
		page_cache = cache;
	}
	State commit(time32_t timestamp)
	{
		PageLayout *new_magic = page_cache->magic_layout_ptr();
		new_magic->logger_last_check = timestamp;
		new_magic->logger_first_idx  = 0;
		new_magic->logger_magic_idx  = 0;
		new_magic->logger_id         = 0;
		new_magic->logger_serial     = 0;
		size_t snapshot_size;
		Page** snapshot = page_cache->snapshot_reference(snapshot_size);
		try
		{
			save_page(snapshot, snapshot + snapshot_size, page_file);
			page_file->sync();
			return CLEAN;
		}
		catch(PageFile::Exception e) { }
		return CORRUPT;
	}
};

class PageLogger : public Logger
{
	PageFile *page_file;
	PageCache *page_cache;
	PageLayout *org_magic;
public:
	~PageLogger() { PageMemory::free(org_magic); }
	PageLogger() : org_magic((PageLayout *)PageMemory::alloc()) { memset(org_magic, 0, PAGESIZE); }

	void init(PageFile *file, PageCache *cache)
	{
		page_file  = file;
		page_cache = cache;
	}

	State integrity_verify()
	{
		State state = CLEAN;
		PageLayout *cur_magic = page_cache->magic_layout_ptr();
		if(page_index_t logger_magic_idx = cur_magic->logger_magic_idx)
		{
			try
			{
				page_file->read(logger_magic_idx, org_magic);
				state = (org_magic->logger_serial != cur_magic->logger_serial) ? CORRUPT : REDO;
			}
			catch(PageFile::Exception e)
			{
				state = CORRUPT;
			}
		}
		memcpy(org_magic, cur_magic, sizeof(PageLayout));
		return state;
	}

	State truncate() { return abort(); }
	State redo(time32_t timestamp) { return commit(timestamp); }

	State prepare()
	{
		size_t snapshot_size;
		Page** snapshot             = page_cache->snapshot_reference(snapshot_size);
		PageLayout *new_magic       = page_cache->magic_layout_ptr();
		page_index_t page_index     = std::max(new_magic->max_page_idx, org_magic->max_page_idx) + 1;
		org_magic->logger_id        = new_magic->logger_id     = 0;
		org_magic->logger_serial    = new_magic->logger_serial = rand();
		org_magic->logger_first_idx = page_index;
		try
		{
			org_magic->logger_magic_idx = save_page(snapshot, snapshot + snapshot_size, page_file, page_index) - 1;
			if(org_magic->logger_first_idx <= org_magic->logger_magic_idx)
			{
				page_file->write(0, org_magic);
				page_file->sync();
			}
			return PREPARED;
		}
		catch(PageFile::Exception e) { }
		return CORRUPT;
	}
	State commit(time32_t timestamp)
	{
		try
		{
			page_index_t logger_first_idx = org_magic->logger_first_idx;
			page_index_t logger_magic_idx = org_magic->logger_magic_idx;
			if(logger_first_idx <= logger_magic_idx)
			{
				restore_page(page_file, logger_first_idx, logger_magic_idx, page_file);
				page_file->read(logger_magic_idx, org_magic);
				org_magic->logger_last_check = timestamp;
				page_file->write(0, org_magic);
				page_file->truncate(logger_first_idx);
				page_file->sync();
			}
			return CLEAN;
		}
		catch(PageFile::Exception e) { }
		return CORRUPT;
	}

	State abort()
	{
		try
		{
			page_index_t logger_first_idx = org_magic->logger_first_idx;
			org_magic->logger_first_idx = 0;
			org_magic->logger_magic_idx = 0;
			page_file->write(0, org_magic);
			page_file->truncate(logger_first_idx);
			page_file->sync();
			return CLEAN;
		}
		catch(PageFile::Exception e) { }
		return CORRUPT;
	}
};

class GlobalLogger : public Logger
{
	class LogInfo
	{
		PageFile	*page_file;
		PageCache	*page_cache;
		void		*key_page;
		page_index_t	key_page_index;
	public:
		~LogInfo() { PageMemory::free(key_page); }
		LogInfo(PageFile *file, PageCache *cache) : page_file(file), page_cache(cache), key_page(PageMemory::alloc()) { }
		size_t init(PageFile *log_file, page_index_t page_index)
		{
			memset(key_page, 0, PAGESIZE);
			size32_t *lp = (size32_t *)key_page;
			size_t len = strlen(identity()) + 1;
			*lp = (len + sizeof(size32_t) + 3) & ~3;
			memcpy(lp + 1, identity(), len);
			log_file->write(key_page_index = page_index, key_page);
			return *lp;
		}
		void load(page_index_t page_index, void *page)
		{
			memcpy(key_page, page, PAGESIZE);
			key_page_index = page_index;
		}

		logger_hdr* logger_item(page_index_t i) { return (logger_hdr *)((byte_t *)key_page + *(size32_t *)key_page) + i; }
		time32_t& logger_id() { return page_cache->magic_layout_ptr()->logger_id; }
		time32_t& logger_last_check() { return page_cache->magic_layout_ptr()->logger_last_check; }

		page_index_t prepare(PageFile *log_file, page_index_t page_index, page_index_t rec_index)
		{
			size_t snapshot_size;
			Page** snapshot = page_cache->snapshot_reference(snapshot_size);
			logger_item(rec_index)->logger_first_idx = page_index;
			logger_item(rec_index)->logger_last_idx  = page_index = save_page(snapshot, snapshot + snapshot_size, log_file, page_index);
			log_file->write(key_page_index, key_page);
			return page_index;
		}
		void commit(PageFile *log_file, time32_t _logger_id, time32_t timestamp, page_index_t rec_index)
		{
			PageLayout *layout = (PageLayout *)PageMemory::alloc();
			page_index_t it = logger_item(rec_index)->logger_first_idx;
			page_index_t ie = logger_item(rec_index)->logger_last_idx - 1;
			try { page_file->read(0, layout); } catch(PageFile::Exception e) { } //new talbe's first commit would throw exception
			layout->logger_id = logger_id() = _logger_id; //set the magic page in file and the one in memory
			if(it <= ie)
			{
				page_file->write(0, layout);
				page_file->sync();
				restore_page(log_file, it, ie, page_file);
				log_file->read(ie, layout);
				layout->logger_id = _logger_id;
			}
			layout->logger_last_check = logger_last_check() = timestamp;
			page_file->write(0, layout);
			page_file->sync();
			PageMemory::free(layout);
		}

		const char *identity() const { return page_file->identity(); }
		const char *fake_identity() const { return (const char *)key_page + sizeof(size32_t); }
	};
	static bool compare_loginfo(const LogInfo *lhs, const LogInfo *rhs) { return strcmp(lhs->identity(), rhs->identity()) < 0; }
	typedef std::vector<LogInfo *> LogInfoVec;

	const char *logdir;
	size_t rotate_pages; //maximum amount of pages of a log file
	PageFile *log_file;
	time32_t time_stamp; //of last operation
	PageLayout *key_page; //1st page of log file
	bool need_rotate; //need a new log file
	LogInfoVec loginfo_vec;

	page_index_t& logger_page_first() { return key_page->logger_page_first; }
	page_index_t& logger_page_last()  { return key_page->logger_page_last;  }
	page_index_t& logger_rec_max()    { return key_page->logger_rec_max;    }
	page_index_t& logger_rec_cur()    { return key_page->logger_rec_cur;    }
	time32_t&     logger_chain()      { return key_page->logger_chain;      }
	logger_hdr*   logger_item(page_index_t i) { return key_page->logger_head + i; }

	void open_log_file(time32_t new_time_stamp, int flag = O_CREAT|O_RDWR)
	{
		delete log_file;
		char *name = (char *)malloc(strlen(logdir) + 32);
		sprintf(name, "%slog.%08x", logdir, new_time_stamp);
		log_file = new PageFile(name, flag);
		free(name);
	}
	
	//initialize new log file
	void init_log_file(time32_t new_time_stamp)
	{
		if(time_stamp >= new_time_stamp)
			new_time_stamp = time_stamp + 1;
		if(log_file)
		{
			logger_chain() = new_time_stamp;
			log_file->write(0, key_page);
		}
		open_log_file(new_time_stamp);
		memset(key_page, 0, PAGESIZE);
		logger_page_first() = logger_page_last() = loginfo_vec.size() + 1;
		time_stamp = new_time_stamp;
		size_t used_max = (byte_t *)key_page->logger_head - (byte_t *)key_page;
		page_index_t page_index = 1;
		for(LogInfoVec::iterator it = loginfo_vec.begin(), ie = loginfo_vec.end(); it != ie; ++it)
			used_max = std::max(used_max, (*it)->init(log_file, page_index++));
		key_page->logger_rec_max = (PAGESIZE - used_max) / sizeof(logger_hdr);
		log_file->write(0, key_page);
		log_file->sync();
	}

	//load existing log file
	bool load_log_file(time32_t new_time_stamp)
	{
		bool r = true;
		open_log_file(time_stamp = new_time_stamp);
		log_file->read(0, key_page);
		if(!need_rotate && logger_page_first()-1 < loginfo_vec.size()) need_rotate = true; //new table
		char *page = (char *)PageMemory::alloc();
		for(page_index_t page_index = 1; page_index < logger_page_first(); page_index++)
		{
			log_file->read(page_index, page);
			LogInfoVec::iterator it = loginfo_vec.begin(), ie = loginfo_vec.end();
			for( ; it != ie; ++it)
			{
				if(strcmp((*it)->identity(), page + sizeof(size32_t)) == 0)
				{
					(*it)->load(page_index, page);
					break;
				}
			}
			if(it == ie) r = false; //db file miss
		}
		PageMemory::free(page);
		return r;
	}

	State restore(time32_t timestamp, page_index_t rec_index)
	{
		try
		{
			time32_t logger_id = get_logger_id();
			for(LogInfoVec::iterator it = loginfo_vec.begin(), ie = loginfo_vec.end(); it != ie; ++it)
				(*it)->commit(log_file, logger_id, timestamp, rec_index);
			return CLEAN;
		}
		catch(PageFile::Exception e) { }
		return CORRUPT;
	}

	page_index_t logger_check_rotate()
	{
		if(need_rotate || logger_rec_cur() >= logger_rec_max() || logger_page_last() > rotate_pages)
			init_log_file(time32_now());
		return logger_page_last();
	}
public:
	~GlobalLogger()
	{
		for(LogInfoVec::iterator it = loginfo_vec.begin(), ie = loginfo_vec.end(); it != ie; ++it)
			delete *it;
		free((void *)logdir);
		delete log_file;
		PageMemory::free(key_page);
	}

	GlobalLogger(const char *log_dir, size_t rotate = 4096) : logdir(strdup(log_dir)), rotate_pages(rotate), 
	       log_file(NULL), time_stamp(time32_now()), key_page((PageLayout *)PageMemory::alloc()), need_rotate(false)
	{
	}

	void init(PageFile *file, PageCache *cache) { loginfo_vec.push_back(new LogInfo(file, cache)); }

	State integrity_verify()
	{
		try
		{
			std::sort(loginfo_vec.begin(), loginfo_vec.end(), compare_loginfo);
			time32_t max_logger_id = 0;
			for(LogInfoVec::iterator it = loginfo_vec.begin(), ie = loginfo_vec.end(); it != ie; ++it)
				max_logger_id = std::max(max_logger_id, (*it)->logger_id());
			if(max_logger_id == 0)
			{
				init_log_file(time32_now());
				return CLEAN;
			}
			for(LogInfoVec::iterator it = loginfo_vec.begin(), ie = loginfo_vec.end(); it != ie; ++it)
			{
				time32_t cur_logger_id = (*it)->logger_id();
				if(cur_logger_id == 0) // new table, or logged by PageLogger
					need_rotate = true;
				else if(cur_logger_id < max_logger_id) // after logrotate, prepare succeed, but commit fail
					(*it)->logger_id() = max_logger_id;
			}
			if(!load_log_file(max_logger_id))
				return CORRUPT; // some dbfile miss

			page_index_t rec_index = logger_rec_cur();
			switch(logger_item(rec_index)->check_result)
			{
				case LCR_NULL:
					if(logger_item(rec_index)->logger_first_idx)
					{
						logger_item(rec_index)->check_result = LCR_ABORT;
						logger_rec_cur() ++;
						log_file->write(0, key_page);
						log_file->sync();
					}
					break;
				case LCR_PREPARED:
					return REDO;
					break;
				default:
					break;
			}
			return CLEAN;
		}
		catch(PageFile::Exception e) { }
		return CORRUPT;
	}

	State truncate() { return CORRUPT; }

	State prepare()
	{
		try
		{
			page_index_t page_index = logger_check_rotate();
			page_index_t rec_index  = logger_rec_cur();
			logger_item(rec_index)->logger_first_idx = page_index;
			log_file->write(0, key_page);
			log_file->sync();
			for(LogInfoVec::iterator it = loginfo_vec.begin(), ie = loginfo_vec.end(); it != ie; ++it)
				page_index = (*it)->prepare(log_file, page_index, rec_index);
			logger_item(rec_index)->logger_last_idx = logger_page_last() = page_index;
			logger_item(rec_index)->check_result    = LCR_PREPARED;
			log_file->write(0, key_page);
			log_file->sync();
			return PREPARED;
		}
		catch(PageFile::Exception e) { }
		return CORRUPT;
	}

	State redo(time32_t timestamp)
	{
		try
		{
			time_stamp = (timestamp <= time_stamp) ? (time_stamp + 1) : timestamp;
			page_index_t rec_index = logger_rec_cur();
			time32_t logger_id = get_logger_id();
			for(LogInfoVec::iterator it = loginfo_vec.begin(), ie = loginfo_vec.end(); it != ie; ++it)
				if((*it)->logger_id())
					(*it)->commit(log_file, logger_id, time_stamp, rec_index);
			logger_item(rec_index)->check_result = LCR_COMMIT;
			logger_item(rec_index)->logger_check_timestamp = time_stamp;
			logger_rec_cur() ++;
			log_file->write(0, key_page);
			log_file->sync();
			return CLEAN;
		}
		catch(PageFile::Exception e) { }
		return CORRUPT;
	}

	State commit(time32_t timestamp)
	{
		try
		{
			time_stamp = (timestamp <= time_stamp) ? (time_stamp + 1) : timestamp;
			page_index_t rec_index = logger_rec_cur();
			time32_t logger_id = get_logger_id();
			for(LogInfoVec::iterator it = loginfo_vec.begin(), ie = loginfo_vec.end(); it != ie; ++it)
				(*it)->commit(log_file, logger_id, time_stamp, rec_index);
			logger_item(rec_index)->check_result = LCR_COMMIT;
			logger_item(rec_index)->logger_check_timestamp = time_stamp;
			logger_rec_cur() ++;
			log_file->write(0, key_page);
			log_file->sync();
			return CLEAN;
		}
		catch(PageFile::Exception e) { }
		return CORRUPT;
	}

	State abort()
	{
		try
		{
			logger_item(logger_rec_cur()++)->check_result = LCR_ABORT;
			log_file->write(0, key_page);
			log_file->sync();
			return CLEAN;
		}
		catch(PageFile::Exception e) { }
		return CORRUPT;
	}

	time32_t get_logger_id() const
	{
		time32_t ts;
		sscanf(log_file->identity(), "log.%x", &ts);
		return ts;
	}

	/** todo
	std::vector<time32_t> check_version()
	{
		std::vector<time32_t> r;
		LogInfoVec::iterator ii = loginfo_vec.begin();
		time32_t logger_last_check = (*ii)->logger_last_check();
		time32_t logger_id         = (*ii)->logger_id();
		logger_hdr *it = logger_item(0);
		logger_hdr *ie = logger_item(logger_rec_cur());
		while(it != ie && (*it).logger_check_timestamp <= logger_last_check) ++it;
		do
			if((*it).check_result == LCR_COMMIT)
				r.push_back((*it).logger_check_timestamp);
		while(logger_chain() && load_log_file(logger_chain()) && (it = logger_item(0), ie = logger_item(logger_rec_cur()), 1));
		load_log_file(logger_id);
		return r;
	}
	std::vector<time32_t> restore(time32_t timestamp)
	{
		std::vector<time32_t> r;
		LogInfoVec::iterator ii = loginfo_vec.begin();
		time32_t logger_last_check = (*ii)->logger_last_check();
		time32_t logger_id         = (*ii)->logger_id();
		time32_t t = 0;
		bool c = true;
		logger_hdr *it = logger_item(0);
		logger_hdr *ib = it;
		logger_hdr *ie = logger_item(logger_rec_cur());
		while(it != ie && (*it).logger_check_timestamp <= logger_last_check) ++it;
		do
			for( ; c && it != ie; ++it)
				if((c = ( (*it).logger_check_timestamp < timestamp)) && (*it).check_result == LCR_COMMIT &&
						(c = (restore(t = (*it).logger_check_timestamp, it - ib) == Logger::CLEAN)))
					r.push_back(t);
		while(c && logger_chain() && load_log_file(logger_chain()) && (it = ib = logger_item(0), ie = logger_item(logger_rec_cur()), 1));
		load_log_file(logger_id);
		return r;
	}
	*/
};

} //namespace __db_core
} //namespace lcore
#endif
