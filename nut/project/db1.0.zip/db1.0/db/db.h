#ifndef _L_DB_H
#define _L_DB_H

#include "db_core.h"

namespace lcore {

using __db_core::PageFile;
using __db_core::PageCache;
using __db_core::Logger;
using __db_core::NullLogger;
using __db_core::PageLogger;
using __db_core::GlobalLogger;
using __db_core::Performance;
using __db_core::IQueryKey;
using __db_core::IQueryData;
using __db_core::time32_now;

class DB
{
protected:
	PageCache *page_cache;
	DB() : page_cache(NULL) { }
public:
	bool put(const void* key, size_t key_len, const void* val, size_t val_len, bool replace = true)
	{
		return page_cache->put(key, key_len, val, val_len, replace);
	}
	//return old val(need free it) or NULL
	void* put(const void *key, size_t key_len, const void* val, size_t *val_len)
	{
		return page_cache->put(key, key_len, val, *val_len);
	}
	//need free return pointer
	void* find(const void* key, size_t key_len, size_t *val_len)
	{
		return page_cache->find(key, key_len, *val_len);
	}
	//also put value in val_buf if val_buf is sufficient
	//need free return pointer if it not equals val_buf
	void* find(const void* key, size_t key_len, size_t *val_len, void *val_buf)
	{
		return page_cache->find(key, key_len, *val_len, val_buf);
	}
	//need free return pointer
	void* first_key(size_t *key_len) { return page_cache->first_key(*key_len); }
	//need free return pointer
	void* next_key(const void* key, size_t *key_len) { return page_cache->next_key(key, *key_len); }
	bool  del(const void* key, size_t key_len) { return page_cache->del(key, key_len); }
	//need free return pointer
	void* del(const void* key, size_t key_len, size_t *val_len) { return page_cache->del(key, key_len, *val_len); }
	bool exist(const void* key, size_t key_len) { return page_cache->exist(key, key_len); }
	void walk(IQueryKey  *query) { page_cache->walk(query); }
	void walk(IQueryData *query) { page_cache->walk(query); }
	void walk(const void *key, size_t key_len, IQueryKey  *query) { page_cache->walk(key, key_len, query); }
	void walk(const void *key, size_t key_len, IQueryData *query) { page_cache->walk(key, key_len, query); }
	size_t record_count() const { return page_cache->record_count(); }
	void snapshot_create()  { page_cache->snapshot_create(); }
	void snapshot_release() { page_cache->snapshot_release(); }
	void performance_dump() { page_cache->performance()->dump(); }
};

template <bool UsePageLogger = true>
class _DBStandalone : public DB
{
	size_t cache_high, cache_low;
	PageFile *page_file;
	Logger   *logger;

	_DBStandalone(const _DBStandalone &);
	_DBStandalone& operator =(const _DBStandalone &);
public:
	~_DBStandalone()
	{
		delete page_cache;
		delete page_file;
		delete logger;
	}
	_DBStandalone(const char *dbfile, size_t high = 1024, size_t low = 768) : cache_high(high), cache_low(low), page_file(new PageFile(dbfile))
	{
		page_cache = new PageCache(page_file, cache_high, cache_low);
		UsePageLogger ? logger = new PageLogger() : logger = new NullLogger();
		logger->init(page_file, page_cache);
	}
	bool init()
	{
		Logger::State state = logger->integrity_verify();
		if(state != Logger::CLEAN)
		{
			if(state == Logger::CORRUPT)
				state = logger->truncate();
			else if(state == Logger::REDO)
				state = logger->redo(time32_now());
			delete page_cache;
			if(state == Logger::CLEAN)
				page_cache = new PageCache(page_file, cache_high, cache_low);
			else
				page_cache = NULL;
		}
		return state == Logger::CLEAN;
	}

	bool checkpoint_prepare() { return logger->prepare() == Logger::PREPARED; }
	bool checkpoint_commit()  { return logger->commit(time32_now()) == Logger::CLEAN; }
	bool checkpoint()
	{
		snapshot_create();
		bool r = checkpoint_prepare() && checkpoint_commit();
		snapshot_release();
		return r;
	}
};
typedef _DBStandalone<true> DBStandalone;

class DBEnv
{
	class Table : public DB
	{
		size_t cache_high, cache_low;
		PageFile *page_file;
	public:
		const char *table_name;
		~Table()
		{
			delete page_cache;
			delete page_file;
			free((void *)table_name);
		}
		void close()
		{
			delete page_cache;
			delete page_file;
		}
		Table(const char *name, size_t high, size_t low)
			: cache_high(high), cache_low(low), page_file(NULL), table_name(strdup(name)) { }
		void open(const char *path, Logger *logger)
		{
			char *buffer = (char *)malloc(strlen(path) + strlen(table_name) + 1);
			strcpy(buffer, path);
			strcat(buffer, table_name);
			page_file  = new PageFile(buffer);
			page_cache = new PageCache(page_file, cache_high, cache_low);
			logger->init(page_file, page_cache);
			free(buffer);
		}
		void snapshot_create()  { page_cache->snapshot_create();  }
		void snapshot_release() { page_cache->snapshot_release(); }
	};
	typedef std::vector<Table*> TableVec;
	TableVec table_vec;
	char *datadir, *logdir;
	size_t maxlogpages;
	Logger *logger;

	void load()
	{
		logger = new GlobalLogger(logdir, maxlogpages);
		for(TableVec::iterator it = table_vec.begin(), ie = table_vec.end(); it != ie; ++it)
			(*it)->open(datadir, logger);
	}
	void unload()
	{
		std::for_each(table_vec.begin(), table_vec.end(), std::mem_fun(&Table::close));
		delete logger;
	}

	static char *fix_dup_dir(const char *dir)
	{
		size_t len = strlen(dir);
		if(dir[len-1] == '/') return strdup(dir);
		char *p = (char *)malloc(len + 2);
		memcpy(p, dir, len);
		p[len] = '/';
		p[len+1] = '\0';
		return p;
	}
	static void create_dir(const char *dir)
	{
		char *r = strdup(dir);
		char *q = strdup(dir);
		q[*q == '/' ? 1 : 0] = '\0';
		for(char *p = strtok(r, "/"); p; p = strtok(NULL, "/"))
		{
			strcat(q, p);
			strcat(q, "/");
			mkdir(q, 0755);
		}
		free(q);
		free(r);
	}

	//static bool equal_name(Table *table, const char *name) { return strcmp(table->table_name, name) == 0;}
	static TableVec::iterator find_table(TableVec &table_vec, const char *name)
	{
		//return std::find_if(table_vec.begin(), table_vec.end(), std::bind2nd(std::ptr_fun(equal_name),name));
		for(TableVec::iterator it = table_vec.begin(), ite = table_vec.end(); it != ite; ++it)
			if(strcmp((*it)->table_name, name) == 0) return it;
		return table_vec.end();
	}

	DBEnv(const DBEnv &);
	DBEnv& operator =(const DBEnv &);
public:
	~DBEnv()
	{
		free(datadir);
		free(logdir);
		for(TableVec::iterator it = table_vec.begin(), ie = table_vec.end(); it != ie; ++it)
			delete *it;
		delete logger;
	}
	DBEnv(const char *data_dir = NULL, const char *log_dir = NULL, size_t pages = 4096) : maxlogpages(pages), logger(NULL)
	{
		datadir = data_dir ? fix_dup_dir(data_dir) : NULL;
		logdir  = log_dir  ? fix_dup_dir(log_dir ) : NULL;
	}
	void set_data_dir(const char *dir) { if(!datadir) datadir = fix_dup_dir(dir); }
	void set_log_dir (const char *dir) { if(!logdir)  logdir  = fix_dup_dir(dir); }
	bool set_table(const char *name, size_t cache_high = 1024, size_t cache_low = 768)
	{
		if(find_table(table_vec, name) != table_vec.end()) return false;
		table_vec.push_back(new Table(name, cache_high, cache_low));
		return true;
	}

	bool init()
	{
		create_dir(datadir);
		create_dir(logdir);
		errno = 0;
		load();
		Logger::State state = logger->integrity_verify();
		if(state != Logger::CLEAN)
		{
			if(state == Logger::CORRUPT)
				state = logger->truncate();
			else if(state == Logger::REDO)
				state = logger->redo(time32_now());
			if(state == Logger::CLEAN)
			{
				unload();
				load();
			}
		}
		return state == Logger::CLEAN;
	}

	DB *db(const char *name)
	{
		TableVec::iterator it = find_table(table_vec, name);
		if(it != table_vec.end()) return *it;
		return NULL;
	}
	size_t all_dbs(std::vector<const char *> &names, std::vector<DB*> &dbs)
	{
		names.clear();
		dbs.clear();
		names.reserve(table_vec.size());
		dbs.reserve(table_vec.size());
		for(TableVec::iterator it = table_vec.begin(), ie = table_vec.end(); it != ie; ++it)
		{
			names.push_back((*it)->table_name);
			dbs.push_back(*it);
		}
		return names.size();
	}

	bool checkpoint_prepare() { return logger->prepare() == Logger::PREPARED; }
	bool checkpoint_commit()  { return logger->commit(time32_now()) == Logger::CLEAN; }
	bool checkpoint()
	{
		std::for_each(table_vec.begin(), table_vec.end(), std::mem_fun(&Table::snapshot_create));
		bool r = checkpoint_prepare() && checkpoint_commit();
		std::for_each(table_vec.begin(), table_vec.end(), std::mem_fun(&Table::snapshot_release));
		return r;
	}

	void get_old_logs(std::vector<time_t> &r)
	{
		GlobalLogger *glogger = dynamic_cast<GlobalLogger *>(logger);
		if(!glogger) return;
		r.clear();
		__db_core::time32_t time_stamp = glogger->get_logger_id();
		if(DIR *dir = opendir(logdir))
		{
			while(dirent *d = readdir(dir))
			{
				if(d->d_name[0] == 'l')
				{
					__db_core::time32_t ts = 0;
					sscanf(d->d_name, "log.%x", &ts);
					if(ts && ts < time_stamp) r.push_back(ts);
				}
			}
			closedir(dir);
		}
	}
}; //class DBEnv
} //namespace lcore

#endif
