#include <map>
#include <string>
#include <vector>
#include <iostream>
#include <assert.h>
#include "storage.h"
#include "table_walker.h"
#include "table_wrapper.h"
#include <sys/mman.h>
using namespace std;

void test_dbenv()
{
	cout << "test DBEnv\n";
	lcore::DBEnv env(lcore::Conf::find("storage","datadir").c_str(), lcore::Conf::find("storage","logdir").c_str());
	vector<string> tables;
	lcore::SplitString(tables, lcore::Conf::find("storage","tables").c_str(), ", ");
	for(vector<string>::iterator it=tables.begin(), ie=tables.end(); it!=ie; ++it)
		cout << "table " << *it << ' ' << (env.set_table(it->c_str()) ? "OK:" : "Exist:");
	cout << endl;
	assert(env.init());
	cout << "init succeed\n";

	lcore::DB *db = env.db("user");
	assert(db);
	cout << "get db user succeed\n";

	for(int i=1000; i<1024; ++i)
	{
		char buf[12] = {0};
		sprintf(buf, "%d", i);
		db->put(buf, strlen(buf), buf, strlen(buf));
	}
	env.checkpoint();
	cout << endl;
}
void test_standalone()
{
	cout << "test DBStandalone\n";
	lcore::DBStandalone db((lcore::Conf::find("storage","datadir")+"/user").c_str());
	assert(db.init());
	cout << "init succeed\n";

	cout << "the keys are:" << endl;
	size_t key_len;
	void *key = db.first_key(&key_len);
	if(key)
	{
		cout << string((char*)key, key_len) << endl;
		void *key2;
		while((key2 = db.next_key(key, &key_len)))
		{
			free(key);
			key = key2;
			cout << string((char*)key, key_len) << endl;
		}
		free(key);
	}
}

void test_wdb_backup()
{
	if(!WDB::StorageEnv::Open())
	{
		cerr << "Initialize storage environment failed." << endl;
		exit(1);
	}
	pthread_t th;
	pthread_create(&th, NULL, &WDB::StorageEnv::BackupThread, NULL);
	try
	{
		WDB::Storage *puser = WDB::StorageEnv::GetStorage("user");
		assert(puser);
		WDB::Transaction txn;
		string str("0123456789");
		lcore::Octets key(str.c_str(), str.length()), val;
		if(puser->find(key, val, txn))
			cout << "find " << string((const char*)val.begin(),val.size()) << endl;
		else
			cout << "not find" << endl;
		puser->insert(key, lcore::Octets("xuanya"), txn);
	}
	catch(WDB::DbException e)
	{
		puts(e.what());
	}
	sleep(600);
	WDB::StorageEnv::Close();
}

void test_wdb_insert()
{
	if(!WDB::StorageEnv::Open())
	{
		cerr << "Initialize storage environment failed." << endl;
		exit(1);
	}
	{
		WDB::Storage *pbase = WDB::StorageEnv::GetStorage("base");
		assert(pbase);
		WDB::Transaction txn;
		for(int i=111; i<122; ++i)
		{
			lcore::OctetsStream os;
			os << i;
			try{ pbase->insert(os, lcore::Octets("1"), txn, WDB::WDB_NOOVERWRITE); }
			catch(WDB::DbException e) { puts(e.what()); }
		}
	}
	WDB::StorageEnv::checkpoint();
	WDB::StorageEnv::Close();
	cout << endl;
}
class base_query : public WDB::IQuery
{
public:
	virtual bool Update(const lcore::Octets &key, const lcore::Octets &val)
	{
		lcore::OctetsStream os_key(key);
		try {
			int i;
			os_key >> i; 
			cout << i << endl;
		}
		catch(...)
		{
			cout << "Exception\n";
			return false;
		}
		return true;
	}
};
void test_wdb_cursor()
{
	if(!WDB::StorageEnv::Open())
	{
		cerr << "Initialize storage environment failed." << endl;
		exit(1);
	}

	{
		WDB::Storage *pbase = WDB::StorageEnv::GetStorage("base");
		WDB::Transaction txn;
		assert(pbase);
		base_query query;
		try
		{
			WDB::Cursor cursor = pbase->cursor();
			cursor.walk(query);
		}
		catch(WDB::DbException e)
		{
			puts(e.what());
		}
	}
	WDB::StorageEnv::Close();
}

class base_browser : public WDB::IQuery
{
public:
	int count;
	bool print;
	virtual bool Update(const lcore::Octets &key, const lcore::Octets &val)
	{
		lcore::OctetsStream os_key(key);
		try {
			int i;
			os_key >> i; 
			if(print) cout << i << '\n';
			++count;
		}
		catch(...)
		{
			cout << "Exception\n";
		}
		return true;
	}
};
void test_tab_browse(string path, bool print=false)
{
	WDB::Browser browser(path.c_str());
	base_browser bb;
	bb.count = 0;
	bb.print = print;
	browser.browse_raw(bb);
	cout << "there are " << bb.count << " records in " << path << endl;
}

char val_buf[0x10000];
void test_wdb_through()
{
	if(!WDB::StorageEnv::Open())
	{
		cerr << "Initialize storage environment failed." << endl;
		return;
	}

	size_t insert_n = 0;
	size_t del_n = 0;

	vector<int> keys;
	srand(time(NULL));
	for(int i=0; i<10000; ++i)
	{
		int num = rand();
		if(num & 3)//3/4
		{
			try
			{
				WDB::Storage *ptest = WDB::StorageEnv::GetStorage("test");
				WDB::Transaction txn;
				lcore::OctetsStream os;
				os << num;
				ptest->insert(os, lcore::Octets(val_buf, (num & 0xFFFF)), txn, WDB::WDB_NOOVERWRITE);
			}
			catch(WDB::DbException e)
			{
				//puts(e.what());
				continue;
			}
			++insert_n;
			keys.push_back(num);
		}
		else if(!keys.empty())
		{
			try
			{
				WDB::Storage *ptest = WDB::StorageEnv::GetStorage("test");
				WDB::Transaction txn;
				lcore::OctetsStream os;
				os << keys[num % keys.size()];
				ptest->del(os, txn);
				++del_n;
				keys.erase(keys.begin() + num % keys.size());
			}
			catch(WDB::DbException e)
			{
				puts(e.what());
			}
		}
		if(i % 1000 == 0)
			WDB::StorageEnv::checkpoint();
	}
	puts("test insert and del end");
	cout << "insert:" << insert_n << ",del:" << del_n << ",keys:" << keys.size() << endl;
	assert(insert_n-del_n == keys.size());

	WDB::StorageEnv::checkpoint();

	random_shuffle(keys.begin(), keys.end());
	try
	{
		WDB::Storage *ptest = WDB::StorageEnv::GetStorage("test");
		WDB::Transaction txn;
		for(vector<int>::iterator it = keys.begin(), ie = keys.end(); it != ie; ++it)
		{
			lcore::OctetsStream os_val;
			if(!ptest->find((lcore::OctetsStream() << *it), os_val, txn))
			{
				cout << "not find " << *it << endl;
				abort();
			}
			assert(os_val.size() == (*it & 0xFFFF));
			if(memcmp(os_val.begin(), val_buf, os_val.size()) != 0)
			{
				cout << "value err " << *it << endl;
				abort();
			}
		}
	}
	catch(WDB::DbException e)
	{
		puts(e.what());
	}
	puts("test find end");

	WDB::StorageEnv::Close();
}

class test_query : public WDB::IQuery
{
	vector<int> &v;
public:
	test_query(vector<int> &keys):v(keys){}
	virtual bool Update(const lcore::Octets &key, const lcore::Octets &val)
	{
		lcore::OctetsStream os_key(key);
		try {
			int i;
			os_key >> i; 
			v.push_back(i);
		}
		catch(...)
		{
			cout << "Exception\n";
			return false;
		}
		return true;
	}
};
void test_wdb_del()
{
	if(!WDB::StorageEnv::Open())
	{
		cerr << "Initialize storage environment failed." << endl;
		return;
	}
	puts("start to collect keys");
	vector<int> keys;
	{
		test_query query(keys);
		WDB::Storage *pbase = WDB::StorageEnv::GetStorage("test");
		WDB::Transaction txn;
		try
		{
			WDB::Cursor cursor = pbase->cursor();
			cursor.walk(query);
		}
		catch(WDB::DbException e)
		{
			puts(e.what());
		}
	}
	cout << "there are " << keys.size() << " keys\n";
	int counter = 0;
	for(vector<int>::iterator it = keys.begin(), ie = keys.end(); it != ie; ++it)
	{
		try
		{
			WDB::Storage *ptest = WDB::StorageEnv::GetStorage("test");
			WDB::Transaction txn;
			ptest->del((lcore::OctetsStream() << *it), txn);
		}
		catch(...){}
		if(++counter == 2000)
		{
			counter = 0;
			WDB::StorageEnv::checkpoint();
		}
	}
	cout << "del ok\n";
	WDB::StorageEnv::checkpoint();
	WDB::StorageEnv::Close();
}
void test_empty_file(const char *filename)
{
	struct stat statbuf;
	int fd = open(filename, O_RDONLY);
	assert(fd>=0);
	assert(fstat(fd, &statbuf) == 0);
	void *file = mmap(0, statbuf.st_size, PROT_READ, MAP_SHARED, fd, 0);
	if(file == MAP_FAILED) abort();

	using lcore::page_index_t;
	using lcore::PAGESIZE;
	using lcore::PAGEUSED;
	char *ptr = (char *)file;
	page_index_t root_index_idx = *(page_index_t *)(ptr + sizeof(page_index_t));
	page_index_t max_page_idx = *(page_index_t *)(ptr + 2*sizeof(page_index_t));
	cout <<"test file " << filename << endl;
	cout << "root:" << root_index_idx << ",max:" << max_page_idx << endl;

	ptr += PAGEUSED + PAGESIZE;
	page_index_t t=1;
	for( ; t<root_index_idx; ++t)
	{
		assert(*(page_index_t *)ptr == t);
		assert(*((page_index_t *)ptr+1) == 0);
		ptr += PAGESIZE;
	}
	assert(*(page_index_t *)ptr == t);
	assert(*((page_index_t *)ptr+1) == 1);
	for(++t; t<max_page_idx; ++t)
	{
		ptr += PAGESIZE;
		assert(*(page_index_t *)ptr == t);
		assert(*((page_index_t *)ptr+1) == 0);
	}
	cout << filename << " is empty\n";
	munmap(file, statbuf.st_size);
}

void test_table_insert(size_t count)
{
	WDB::TableWrapper base("base", new WDB::RealCoder);
	assert(base.open(40960,20480));
	size_t begin_count = base.count();
	time_t last_time = time(NULL);
	srand(last_time);
	for(size_t i=1; i<=count; ++i)
	{
		int num = rand();
		base.insert((lcore::OctetsStream() << num), lcore::Octets(val_buf, num & 0xFFF));
		if(i % 10000 == 0)
		{
			time_t now = time(NULL);
			cout << "count " << i << ", used " << now-last_time << "s, " << ctime(&now);
			last_time = now;
			base.checkpoint();
		}
	}
	base.checkpoint();
	cout << "insert:" << base.count()-begin_count << ", start count:" << begin_count << ", end count:" << base.count() << endl;
}

struct key_browser : public WDB::IQueryKey
{
public:
	std::vector<int> keys;
	virtual bool Update(const lcore::Octets &key)
	{
		int i;
		lcore::OctetsStream os_key(key);
		os_key >> i; 
		keys.push_back(i);
		return true;
	}
};
void test_table_key_browse()
{
	cout << "start: " << time(NULL) << endl;
	WDB::KeyBrowser kb("base");
	key_browser k;
	kb.browse(k);
	cout << "there are " << k.keys.size() << " keys" << endl;
	cout << "end: " << time(NULL) << endl;

	random_shuffle(k.keys.begin(), k.keys.end());
	cout << "after shuffle: " << time(NULL) << endl;

	WDB::TableWrapper tmp_keys("tmp_keys", new WDB::RealCoder);
	tmp_keys.open(160, 80);
	lcore::OctetsStream os;
	os << k.keys;
	tmp_keys.insert(lcore::Octets("1", 1), os);
	tmp_keys.checkpoint();
	cout << "after store tmp_keys: " << time(NULL) << endl;
}

void test_table_find()
{
	std::vector<int> keys;
	{
		WDB::TableWrapper tmp_keys("tmp_keys", new WDB::RealCoder);
		assert(tmp_keys.open(16, 8));
		lcore::OctetsStream os;
		tmp_keys.find(lcore::Octets("1", 1), os);
		os >> keys;
	}
	cout << "threr are " << keys.size() << " keys\n";
	WDB::TableWrapper base("base", new WDB::RealCoder);
	assert(base.open(40960,20480));
	lcore::Octets val;
	int i=0;
	for(vector<int>::iterator it=keys.begin(),ie=keys.end(); it!=ie; ++it)
	{
		assert(base.find((lcore::OctetsStream()<<*it), val));
		assert(val.size() == (*it & 0xFFF));
		assert(memcmp(val.begin(), val_buf, val.size()) == 0);
		if(++i % 10000 == 0)
		{
			cout << i << ":" << time(NULL) << endl;
			base.checkpoint();
		}
	}
	cout << "test find end\n";
}

void test_table_del(int count = 1000000)
{
	cout << "del begin\n";
	cout << "try to del " << count << " recoreds\n";
	std::vector<int> keys;
	WDB::TableWrapper tmp_keys("tmp_keys", new WDB::RealCoder);
	assert(tmp_keys.open(16, 8));
	lcore::OctetsStream os;
	tmp_keys.find(lcore::Octets("1", 1), os);
	os >> keys;
	os.clear();
	cout << "there are " << keys.size() << " keys before del\n";
	WDB::TableWrapper base("base", new WDB::RealCoder);
	assert(base.open(40960,20480));
	lcore::Octets val;
	vector<int>::reverse_iterator it = keys.rbegin(), ie = keys.rend();
	for(int i=0; i<count && it!=ie; ++i)
	{
		base.del((lcore::OctetsStream()<<*it));
		++it;
		keys.pop_back();
		if(i % 10000 == 9999)
		{
			cout << i << ":" << time(NULL) << endl;
			base.checkpoint();
		}
	}
	base.checkpoint();
	cout << "there are " << keys.size() << " keys after del\n";
	os << keys;
	tmp_keys.insert(lcore::Octets("1", 1), os);
	tmp_keys.checkpoint();
	cout << "del end\n";
}

void test_bigkey()
{
	WDB::TableWrapper big("big", new WDB::RealCoder);
	assert(big.open(40960,20480));
	int max = sizeof(val_buf);
	for(int i=1; i<=max; ++i)
	{
		big.insert(lcore::Octets(val_buf, i), lcore::Octets(val_buf, i));
		if(i % 100 == 0) big.checkpoint();
	}
	big.checkpoint();
	for(int i=1; i<=max; ++i)
	{
		lcore::Octets val;
		assert(big.find(lcore::Octets(val_buf, i), val));
		assert(i == (int)val.size());
		assert(memcmp(val_buf, val.begin(), i) == 0);
		if(i % 100 == 0) big.checkpoint();
	}
	big.checkpoint();
	for(int i=1; i<=max; ++i)
	{
		big.del(lcore::Octets(val_buf, i));
		if(i % 100 == 0) big.checkpoint();
	}
	big.checkpoint();
	test_empty_file("big");
	cout << "OK!" << endl;
}

void test_common(size_t n)
{
	WDB::TableWrapper test("test", new WDB::RealCoder);
	assert(test.open(40960,20480));
	srand(time(NULL));
	std::vector<int> keys;
	cout << "insert begin:\n";
	//写n条记录
	for(size_t i=1; i<=n; ++i)
	{
		int num = rand();
		keys.push_back(num);
		test.insert((lcore::OctetsStream() << num), lcore::Octets(val_buf, num & 0xFF));
		if(i % 10000 == 0) test.checkpoint();
	}
	test.checkpoint();
	random_shuffle(keys.begin(), keys.end());
	cout << "readback begin:\n";
	//读回n条记录
	for(size_t i=0; i<n; )
	{
		lcore::Octets val;
		assert(test.find((lcore::OctetsStream() << keys[i]), val));
		assert(val.size() == (keys[i] & 0xFF));
		assert(memcmp(val.begin(), val_buf, val.size()) == 0);
		if(++i % 10000 == 0) test.checkpoint();
	}
	cout << "circle begin:\n";
	//执行下面的循环5n次
	for(size_t i=1; i<=5*n; ++i)
	{
		lcore::Octets val;
		assert(test.find((lcore::OctetsStream() << keys.back()), val));
		random_shuffle(keys.begin(), keys.end());
		//每循环37次随机删除一条记录
		if(i % 37 == 0)
		{
			test.del((lcore::OctetsStream() << keys.back()));
			keys.pop_back();
		}
		//每循环11次添加一条新记录并读回
		else if(i % 11 == 0)
		{
			int key = rand();
			lcore::OctetsStream os;
			os << key;
			test.insert(os, lcore::Octets(val_buf, key&0xFF));
			assert(test.find(os, val));
			assert(val.size() == (key & 0xFF));
			assert(memcmp(val.begin(), val_buf, val.size()) == 0);
			keys.push_back(key);
		}
		//每循环17次随机替换一条记录 一次用大的 一次用小的
		else if(i % 17 == 0)
		{
			switch(rand() % 3)
			{
				case 0:
					test.insert((lcore::OctetsStream() << keys.front()), val);
					break;
				case 1:
					test.insert((lcore::OctetsStream() << keys.front()), lcore::Octets(val_buf, sizeof(val_buf)));
					break;
				case 2:
					test.insert((lcore::OctetsStream() << keys.front()), lcore::Octets(val_buf, val.size()/2));
					break;
				default:
					break;
			}
		}
	}
	cout << "clear begin:\n";
	//删除所有记录 每删除一条 随机查找10条
	while(!keys.empty())
	{
		test.del((lcore::OctetsStream() << keys.back()));
		keys.pop_back();
		random_shuffle(keys.begin(), keys.end());
		for(int j=0; j<std::min(10,(int)keys.size()); ++j)
		{
			lcore::Octets val;
			assert(test.find((lcore::OctetsStream() << keys[j]), val));
		}
	}
	test.checkpoint();
	test_empty_file("test");
	cout << "OK!\n";
}

int main(int argc, char **argv)
{
	if(argc == 1)
	{
		cout << argv[0] << " [alone|backup|cursor|browse]|[through]|[insert count]|[tmpkey|find]|[del count]|[bigkey]|[common count]" << endl;
		return 0;
	}

	lcore::Conf::load("game.conf");

	if(argc == 2 && strcmp(argv[1], "alone") == 0)
	{
		//在"./data/user"中插入一些数据并遍历key值
		test_dbenv();//插入一些数据
		test_standalone();//遍历keys
	}
	else if(argc == 2 && strcmp(argv[1], "backup") == 0)
	{
		//可以以这样的模式运行:
		//通过io线程对db进行插入删除查找操作, io线程退出的时候调用StorageEnv::checkpoint();StorageEnv::Close();
		//backup线程定时checkpoint
		test_wdb_backup();//备份线程
	}
	else if(argc == 2 && strcmp(argv[1], "cursor") == 0)
	{
		//在"./dbhome/data/base"中插入并遍历一些数据
		test_wdb_insert();
		test_wdb_cursor();
	}
	else if(argc == 2 && strcmp(argv[1], "browse") == 0)
	{
		test_tab_browse("dbhome/data/base", true);
	}

	for(int *p = (int *)val_buf, *e = (int *)(val_buf + sizeof(val_buf)); p!=e; ++p) *p = rand();
	if(argc == 2 && strcmp(argv[1], "through") == 0)
	{
		//在"./dbhome/data/test"中插入删除大量数据
		for(int i=0; i<8; ++i) test_wdb_through();
		test_wdb_del();
		test_empty_file("dbhome/data/test");
	}
	else if(argc == 3 && strcmp(argv[1], "insert") == 0)
	{
		//在"./base"中插入大量数据
		int c = atoi(argv[2]);
		test_table_insert(c);
	}
	else if(argc == 2 && strcmp(argv[1], "tmpkey") == 0)
	{
		//将"./base"中的key存储到"./tmp_keys"中
		test_table_key_browse();
	}
	else if(argc == 2 && strcmp(argv[1], "find") == 0)
	{
		test_table_find();
	}
	else if(argc == 3 && strcmp(argv[1], "del") == 0)
	{
		int c = atoi(argv[2]);
		test_table_del(c);
	}
	else if(argc == 2 && strcmp(argv[1], "bigkey") == 0)
	{
		test_bigkey();
	}
	else if(argc == 3 && strcmp(argv[1], "common") == 0)
	{
		//apue上提供的测试方法, c不要太大, 10000条就要跑半分钟
		int c = atoi(argv[2]);
		test_common(c);
	}
	return 0;
}
