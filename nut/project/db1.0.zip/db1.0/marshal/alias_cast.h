#ifndef _L_ALIAS_CAST_H
#define _L_ALIAS_CAST_H

namespace {
template <typename U, typename V>
union TypeAlias
{
	U _u;
	V _v;
	TypeAlias(V v) : _v(v) { }
	operator U() const { return _u; }
};
}

template <typename U, typename V>
inline U alias_cast(V v)
{
	return TypeAlias<U, V>(v);
}

#endif
