#include <map>
#include <ctime>
#include <vector>
#include "auxiliary.h"

class FG_Client;
class delay_session
{
    friend class FG_Client;
    std::map<int,time_t> _sessions;
    time_t _timeout;
public:
    enum {
        SESSION_DELAY = 0,
        SESSION_NEW = 1,
        SESSION_TIMEOUT = 2,
    };
    delay_session(time_t timeout = 1):_timeout(timeout){}
    int can_do(int id, time_t now=Timer::GetTime())
    {
        std::map<int,time_t>::iterator it = _sessions.find(id);
        if (it == _sessions.end())
        {
            _sessions.insert(std::make_pair(id,now));
            return SESSION_NEW;
        }
        if (it->second + _timeout >= now)
        {
            it->second = now;
            return SESSION_TIMEOUT;
        }
        return SESSION_DELAY;
    }
};

class playeron_session
{
    friend class FG_Client;
    struct session_node
    {
        time_t last_time;
        std::vector<int> offline_chats;
        session_node(time_t now):last_time(now){}
    };
    std::map<int,session_node> _sessions;
    time_t _timeout;
public:
    playeron_session(time_t timeout = 600):_timeout(timeout){}
    int can_do(int id, std::vector<int> &offline_chats, time_t now=Timer::GetTime())
    {
        std::map<int,session_node>::iterator it = _sessions.find(id);
        if (it == _sessions.end())
        {
            _sessions.insert(std::make_pair(id,session_node(now)));
            return ONLINE_STATE_NEW;
        }
        if (!it->second.offline_chats.empty())
        {
            offline_chats.swap(it->second.offline_chats);
        }
        if (it->second.last_time + _timeout >= now)
        {
            it->second.last_time = now;
            return ONLINE_STATE_TIMEOUT;
        }
        return ONLINE_STATE_DELAY;
    }
    void set_offline(int id, int chatid)
    {
        std::map<int,session_node>::iterator it = _sessions.find(id);
        if (it != _sessions.end())
        {
            it->second.offline_chats.push_back(chatid);
        }
    }
};

class FG_Client
{
    delay_session common_session;
    playeron_session online_session;
    std::map<std::pair<int,int>,int> invite_record;
    struct notify
    {
        int type;
        Octets chat_name;
        Octets role_name;
    };
    std::map<int,std::vector<notify> > notify_msg;
public:
    FG_Client(){}
    void set_offline(int roleid, int chatid)
    {
        online_session.set_offline(roleid, chatid);
    }
    void player_logon(int roleid)
    {
        std::vector<int> offline_chats;
        int state = online_session.can_do(roleid, offline_chats);
        if(state == ONLINE_STATE_DELAY && offline_chats.empty())
            return;
        //send to server
    }
    bool operation_ok(int roleid, time_t now=Timer::GetTime())
    {
        return common_session.can_do(roleid, now);
    }
    //called just before send invite to invitee
    void add_invite_record(int roleid, int chatid, int owner)
    {
        invite_record.insert(std::make_pair(std::make_pair(roleid,chatid),owner));
    }
    //called when invitee agree or deny or timeout
    void del_invite_record(int roleid, int chatid)
    {
        invite_record.erase(std::make_pair(roleid,chatid));
    }
    int get_invite_owner(int roleid, int chatid)
    {
        std::map<std::pair<int,int>,int>::iterator it = invite_record.find(std::make_pair(roleid,chatid));
        if(it == invite_record.end()) return -1;
        return it->second;
    }
    void add_notify_msg(int roleid, notify msg)
    {
        std::vector<notify> &msgs = notify_msg[roleid];
        if(msgs.size() > 20) msgs[0] = msg;
        else msgs.push_back(msg);
    }
    void Update()
    {
        LOG_TRACE("FG_Client:statistics:common session size=%d,online session size=%d",,common_session._sessions.size(),online_session._sessions.size());
    }
};

int main()
{
    return 0;
}
