#ifndef __FG_SERVER_H__
#define __FG_SERVER_H__

#include <stdio.h>
#include <stdarg.h>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#include "auxiliary.h"
#include "fg_eraser.h"

enum
{
    FG_DEFAULT_CAPACITY_PER_CHAT = 35,
    FG_DEFAULT_OWN_LIMIT_PER_ROLE = 3,
    FG_DEFAULT_JOIN_LIMIT_PER_ROLE = 30,

    FG_MAX_CAPACITY_PER_CHAT = 75,
    FG_MAX_OWN_LIMIT_PER_ROLE = 10,
    FG_MAX_JOIN_LIMIT_PER_ROLE = 35,

    FG_MAX_HISTORY_SIZE = 20,
    FG_HISTORY_EXPIRE_TIME = 7*24*3600,

    FG_MAX_APPLIANTS_PER_CHAT = 50,
    FG_MAX_APPLY_COUNT = 100000,

    FG_MAX_SIZE_OF_CHAT_NAME = 16,
    FG_MAX_SIZE_OF_CHAT_INTRO = 60,
    FG_MAX_SIZE_OF_TALK = 100,

    FG_NAMES_CLEAR_INTERVAL = 14,//about 4.55 hours
};

//错误提示,仅有提示文字 by FG_RErrorMsg
enum {
    FG_ERR_CANNOT_FIND_CHAT=1,//搜索时找不到群
    FG_ERR_FULL_APPLY,//申请时该群已有太多申请者
    FG_ERR_CHAT_FULL1,//申请时群已满,返回给申请者
    FG_ERR_CHAT_FULL2,//同意申请时群已满,返回给群主
    FG_ERR_HAS_IN_CHAT,//同意申请时已在群中,返回给群主
    FG_ERR_JOIN_TOO_MANY,//同意申请时申请者已加入太多群,返回给群主
    FG_ERR_EMPTY_APPLY,//获取群申请者时该群没有申请者
    FG_ERR_TOO_MANY_APPLYS,//全服申请数量达上限
    FG_ERR_CHANGE_OWNER,//更改群主时新旧群主不符合条件,返回给群主
    FG_ERR_INVITEE_NOT_ONLINE,//邀请时对方不在线
    FG_ERR_INVITEE_HAS_INVITED,//邀请时对方已被邀请
};

//广播通知,仅在线可达 by FG_RNotice and FG_RNoticeJoin
enum {
    FG_NOTICE_CHANGE_OWNER=1,
    FG_NOTICE_KICK_MEMBER,
    FG_NOTICE_DISBAND_CHAT,
    FG_NOTICE_LEAVE_CHAT,
};

//单点通知,离线亦可达 by FG_RPoint
enum {
    FG_POINT_ONE_LEAVE=1,//有人退群
    FG_POINT_BE_OWNER,//你成为了群主
    FG_POINT_BE_KIEKED,//你被踢出了群
    FG_POINT_BE_REFUSED,//申请被拒绝
    FG_POINT_BE_AGREED_SUCCEED,//申请被同意
    FG_POINT_BE_AGREED_ERR1,//申请被同意,但申请者已加入太多群
    FG_POINT_BE_AGREED_ERR2,//申请被同意,但群满了
    FG_POINT_BE_AGREED_ERR3,//申请被同意,但已在群中
    FG_POINT_APPLY_YOUR_CHAT,//有人申请你的群
};

enum {
    FG_CONFIRM_REFUSE_ALL = 0x40,
    FG_CONFIRM_AGREE_OPEN = 0x20,
    FG_CONFIRM_AGREE_ALL = 0x10,
    FG_CONFIRM_AGREE_FRIEND = 0x08,
    FG_CONFIRM_AGREE_FACTION = 0x04,
    FG_CONFIRM_AGREE_FAMILY = 0x02,
};

enum {
    FG_HISTORY_ENTER = 1,
    FG_HISTORY_LEAVE,
    FG_HISTORY_LOSE_OWNER,
    FG_HISTORY_BE_OWNER,
    FG_HISTORY_MAX,
};

typedef std::vector<int> FIntVector;

struct FG_Role : public FRole
{
    time_t last_active_time;
    FG_Role(const FRole &role, time_t now=Timer::GetTime())
        : FRole(role), last_active_time(now){}

    enum {
        NOT_CHANGED,
        ROUTE_CHANGED,
        INFO_CHANGED,
    };
    int update_roleinfo(const ChatRoleInfo &newinfo)
    {
        if(newinfo.zoneid != info.zoneid || newinfo.roleid != info.roleid)
        {
            info = newinfo;
            std::fill(dirty.begin(), dirty.end(), 1);
            return ROUTE_CHANGED;
        }
        if(newinfo.name != info.name || newinfo.level != info.level ||
                newinfo.cultivation != info.cultivation || newinfo.occupation != info.occupation)
        {
            info = newinfo;
            std::fill(dirty.begin(), dirty.end(), 1);
            return INFO_CHANGED;
        }
        return NOT_CHANGED;
    }
    void swap(int pos1, int pos2)
    {
        if(pos1 == pos2) return;
        std::swap(chats[pos1], chats[pos2]);
        std::swap(ignore[pos1], ignore[pos2]);
        std::swap(dirty[pos1], dirty[pos2]);
    }
    int get_pos(int fg_chatid)
    {
        FIntVector::iterator it = std::find(chats.begin(), chats.end(), fg_chatid);
        if(it == chats.end()) return -1;
        return std::distance(chats.begin(), it);
    }
    void mv_chat(int fg_chatid)
    {
        int pos = get_pos(fg_chatid);
        if(pos < 0) return;
        if(pos < own_count) swap(pos, --own_count);
        else swap(own_count++, pos);
    }
    void rm_chat(int fg_chatid)
    {
        int pos = get_pos(fg_chatid);
        if(pos < 0) return;
        if(pos < own_count) --own_count;
        chats.erase(chats.begin()+pos);
        ignore.erase(ignore.begin()+pos);
        dirty.erase(dirty.begin()+pos);
    }
    void own_chat(int fg_chatid)
    {
        join_chat(fg_chatid);
        swap(own_count++, chats.size()-1);
    }
    void join_chat(int fg_chatid)
    {
        chats.push_back(fg_chatid);
        ignore.push_back(0);
        dirty.push_back(0);
    }
    bool can_set_ignore(int fg_chatid, bool ignore_msg)
    {
        int pos = get_pos(fg_chatid);
        if(pos < 0) return false;
        if(ignore_msg && ignore[pos]) return false;
        if(!ignore_msg && !ignore[pos]) return false;
        return true;
    }
    void set_ignore(int fg_chatid, bool ignore_msg)
    {
        int pos = get_pos(fg_chatid);
        if(pos < 0) return;
        ignore[pos] = ignore_msg;
    }
    bool clear_dirty(int fg_chatid)
    {
        int pos = get_pos(fg_chatid);
        if(pos < 0) return false;
        if(!dirty[pos]) return false;
        dirty[pos] = 0;
        return true;
    }
    int get_own_limit()
    {
        return FG_DEFAULT_OWN_LIMIT_PER_ROLE + own_addon;
    }
    int get_join_limit()
    {
        return FG_DEFAULT_JOIN_LIMIT_PER_ROLE + join_addon;
    }
    bool can_own()
    {
        return own_count < get_own_limit();
    }
    bool can_join()
    {
        return chats.size()-own_count < get_join_limit();
    }
    void add_history(int opt, const Octets &chat_name, time_t now=Timer::GetTime())
    {
        if(opt < FG_HISTORY_ENTER || opt >= FG_HISTORY_MAX) return;
        if(history.size() >= FG_MAX_HISTORY_SIZE)
            history.erase(history.begin(), history.begin()+history.size()+1-FG_MAX_HISTORY_SIZE);
        history.push_back(ChatRoleHistory(now, opt, chat_name));
    }
    void update_active_time(time_t now=Timer::GetTime())
    {
        last_active_time = now;
    }
};

struct FG_Chat : public FChat
{
    time_t last_active_time;
    FG_Chat(const FChat &chat, time_t now=Timer::GetTime())
        : FChat(chat), last_active_time(now){}

    int get_capacity()
    {
        return FG_DEFAULT_CAPACITY_PER_CHAT + capacity_addon;
    }
    bool can_add()
    {
        return member_count < get_capacity();
    }
    void update_active_time(time_t now=Timer::GetTime())
    {
        last_active_time = now;
    }
};

struct FG_ChatRole : public FChatRole
{
    bool online;
    FG_ChatRole(const FChatRole &chatrole, bool online_=true)
        : FChatRole(chatrole), online(online_){}
};
typedef std::map<int,FG_ChatRole> FMember;
struct FG_Member
{
    FMember members;
    time_t last_active_time;
    FG_Member(const std::map<int,FChatRole> &member, time_t now=Timer::GetTime()) : last_active_time(now)
    {
        std::map<int,FChatRole>::const_iterator it = member.begin();
        for(; it != member.end(); ++it)
            members.insert(std::make_pair(it->first, FG_ChatRole(it->second)));
    }

    void update_member_info(int fg_roleid, const ChatRoleInfo &info, bool set_online)
    {
        FMember::iterator it = members.find(fg_roleid);
        if(it != members.end())
        {
            it->second.info = info;
            if(set_online) it->second.online = true;
        }
    }
    void update_member_online(int fg_roleid, bool online)
    {
        FMember::iterator it = members.find(fg_roleid);
        if(it != members.end())
        {
            it->second.online = online;
        }
    }
    void update_active_time(time_t now=Timer::GetTime())
    {
        last_active_time = now;
    }
};

class FG_Server
{
    std::map<int,FG_Role> _roles;
    std::map<int,FG_Chat> _chats;
    std::map<int,FG_Member> _members;

    std::set<int> _loading_roles;
    std::set<int> _loading_chats;
    std::set<int> _loading_members;

    FG_Eraser _role_eraser;
    FG_Eraser _chat_eraser;
    FG_Eraser _member_eraser;
public://for test memery to delete
    std::set<std::pair<Octets,int> > _names;//<chat_name,fg_chatid>
    std::map<int,std::vector<std::pair<int,ChatRoleInfo> > > _applys;//<fg_chatid,<fg_roleid,roleinfo>list>

    bool _ready;
    bool _next_id_dirty;
    int _next_roleid;
    int _next_chatid;
    int _apply_counter;

public:
    typedef std::map<int,FG_Role>::iterator role_iter;
    typedef std::map<int,FG_Chat>::iterator chat_iter;
    typedef std::map<int,FG_Member>::iterator member_iter;

private:
    int alloc_roleid()
    {
        _next_id_dirty = true;
        return _next_roleid++;
    }
    int alloc_chatid()
    {
        _next_id_dirty = true;
        return _next_chatid++;
    }
    void save_id()
    {
        if(_next_id_dirty)
        {
            _next_id_dirty = false;
            send2db();
        }
    }
    void save_role(role_iter &itr)
    {
        send2db();
    }
    void save_role(int fg_roleid)
    {
        LOG_TRACE("FG_Server::save_role:fg_roleid=%d\n",fg_roleid);
        role_iter itr = _roles.find(fg_roleid);
        if(itr != _roles.end()) save_role(itr);
    }
    void save_chat(chat_iter &itr)
    {
        send2db();
    }
    void save_chat(int fg_chatid)
    {
        LOG_TRACE("FG_Server::save_chat:fg_chatid=%d\n",fg_chatid);
        chat_iter itr = _chats.find(fg_chatid);
        if(itr != _chats.end()) save_chat(itr);
    }
    void save_member(member_iter &itr)
    {
        send2db();
    }
    void save_member(int fg_chatid)
    {
        LOG_TRACE("FG_Server::save_member:fg_chatid=%d\n",fg_chatid);
        member_iter itr = _members.find(fg_chatid);
        if(itr != _members.end()) save_member(itr);
    }

    void send2db(...){}
    void send2db(const Protocol &protocol)
    {
        //GameDBClient::GetInstance()->SendProtocol(protocol);
    }
    void send2client(int zoneid, ...){}
    void send2client(int zoneid, const Protocol &protocol)
    {
        //CentralDeliveryServerMan::GetInstance()->DispatchProtocol(zoneid, protocol);
    }

    void err_msg(int zoneid, int roleid, int err_type)
    {
        send2client(zoneid, FG_RErrorMsg(roleid, err_type));
    }
    void point_msg(int zoneid, int roleid, int type, const Octets &chat_name, const Octets &role_name=Octets())
    {
        send2client(zoneid, FG_RPoint(roleid, type, chat_name, role_name));
    }
    void notice_msg(int fg_chatid, int type, int param=0)
    {
        FG_RNotice notice(type, fg_chatid, param);
        BroadcastNotice(fg_chatid, notice);
    }

    bool update_roleinfo(int fg_roleid, ChatRoleInfo &info, int state, FIntVector &offline_chats, bool from_db);
    bool update_roleinfo_aux1(int fg_roleid, FIntVector &chats, ChatRoleInfo &info);
    bool update_roleinfo_aux2(int fg_roleid, FIntVector &chats);
    void dispose_and_send_chatlist(int fg_roleid, std::map<int,FChatElement> &chat_list);

public:
    FG_Server():_role_eraser(),_chat_eraser(),_member_eraser(),_ready(false),_next_id_dirty(false),
    _next_roleid(1024),_next_chatid(1024),_apply_counter(0){}

    void OnDBConnect()
    {
        send2db();//when timeout resend
    }
    void SetNextId(int next_roleid, int next_chatid)
    {
        LOG_TRACE("FG_Server:SetNextId:ready=%d,roleid=%d,chatid=%d",(int)_ready,next_roleid,next_chatid);
        if(!_ready)
        {
            if(next_roleid) _next_roleid = next_roleid;
            if(next_chatid) _next_chatid = next_chatid;
            _ready = true;
        }
    }
    role_iter OnLoadRole(int fg_roleid, FRole &role);
    chat_iter OnLoadChat(int fg_roleid, FChat &chat);
    member_iter OnLoadMember(int fg_chatid, std::map<int,FChatRole> &member);
    void LoadRoleTimeout(int fg_roleid){}
    void LoadChatTimeout(int fg_chatid)
    {
        _loading_chats.erase(fg_chatid);
    }
    void LoadMemberTimeout(int fg_chatid){}
    virtual void Update();

public:
    void BroadcastNotice(int fg_chatid, FG_RNotice &notice, int step=0);
    void SetRoleOffline(int fg_roleid, int fg_chatid);
    void GetChatList(int fg_roleid, std::map<int,FChatElement> &chat_list, FIntVector &loading_chats, FIntVector &to_load_chats);
    void GetChatList(int fg_roleid, std::map<int,FChatElement> &chat_list, FIntVector &loading_chats);
    //called by LeaveChat
    void TellOnwerOneLeave(int fg_roleid, Octets &chat_name, Octets &leave_name, int step=0);
    //called by Apply
    void AutoConfirm(int chat_owner, int fg_chatid, int app_oroleid, char confirm, int step=0);
    //called by AgreeApply
    void JoinIntoChat(int fg_roleid, int fg_chatid, int owner_zoneid, int owner_roleid, int step=0);

public:
    void OnPlayerOn(int fg_roleid, ChatRoleInfo &info, int state, FIntVector &offline_chats, bool from_db=false);
    void GetChatList(int fg_roleid, int step=0);
    void SetChatName(int fg_roleid, int fg_chatid, Octets &chat_name, int step=0);
    void SetChatConfirm(int fg_roleid, int fg_chatid, int zoneid, int roleid, char confirm, int step=0);
    void SetChatCansearch(int fg_roleid, int fg_chatid, int zoneid, int roleid, bool can_search, int step=0);
    void IgnoreMsg(int fg_roleid, int fg_chatid, bool ignore, int step=0);
    void GetRoleHistory(int fg_roleid, int step=0);

    void GetChatIntro(int fg_roleid, int fg_chatid, int step=0);
    void SetChatIntro(int fg_roleid, int fg_chatid, Octets &intro, int step=0);
    void GetChatMembers(int fg_roleid, int fg_chatid, int step=0);
    void UpdateChatMembers(int fg_roleid, int fg_chatid, int step=0);

    void CreateChat(int fg_roleid, ChatRoleInfo &info, Octets &chat_name, int step=0);
    void ChangeOnwer(int fg_roleid, int fg_chatid, int trans_to, int step=0);
    void KickMember(int fg_roleid, int fg_chatid, int kick_roleid, int step=0);
    void DisbandChat(int fg_roleid, int fg_chatid, int step=0);
    void LeaveChat(int fg_roleid, int fg_chatid, int step=0);

    void SearchById(int zoneid, int roleid, int fg_chatid, int step=0);
    void SearchByName(int zoneid, int roleid, Octets &chat_name);
    void Apply(int fg_roleid, int fg_chatid, ChatRoleInfo &info, int step=0);
    void GetApplicants(int fg_roleid, int fg_chatid, int zoneid, int roleid, int step=0);
    void AgreeApply(int fg_roleid, int fg_chatid, int zoneid, int roleid, int applicant, bool agree, int step=0);

    void ActiveChatName(int fg_chatid, int step=0);
    void Talk(int fg_roleid, int fg_chatid, char vip, Octets &msg, int step=0);

    void AddChatCapacity(int fg_roleid, int fg_chatid, int add_capacity, int zoneid, int roleid, int step=0);
    void AddOwnLimit(int fg_roleid, int add, int step=0);
    void AddJoinLimit(int fg_roleid, int add, int step=0);

    void Invite(int fg_roleid, int fg_chatid, int zoneid, int roleid, int invitee_oroleid, int step=0);
    void AgreeInvite(int fg_roleid, int fg_chatid, ChatRoleInfo &info, int owner_oroleid, int step=0);
};

#endif
