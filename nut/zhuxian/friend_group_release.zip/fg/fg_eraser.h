#ifndef __FG_ERASER_H__
#define __FG_ERASER_H__
struct FG_Eraser
{
    int threshold;
    int left;
    int cross_per_update;
    const int TIMEOUT;
    int timeout;
    int cursor;
    int count;
    int max_drop;

    FG_Eraser(int max_size=100000, int left_size=80000, int step=500, int erase_time=24*3600)
        : threshold(max_size), left(left_size), cross_per_update(step),
          TIMEOUT(erase_time), timeout(erase_time), cursor(-1), count(0){}

    template <typename MAP>
    void Update(MAP &target, time_t now=Timer::GetTime())
    {
        if(cursor < 0)
        {
            if(target.size() < threshold) return;
            max_drop = target.size() - left;
            if(max_drop <= 0) return;
            cursor = 0;
        }
        typename MAP::iterator it = target.lower_bound(cursor);
        for(int i=0; i<cross_per_update && it!=target.end(); ++i)
        {
            if(now - it->second.last_active_time > timeout)
            {
                target.erase(it++);
                if(++count >= max_drop)
                {
                    timeout = TIMEOUT;
                    cursor = -1;
                    count = 0;
                    return;
                }
            }
            else ++it;
        }
        if(it != target.end())
        {
            cursor = it->first;
        }
        else
        {
            //after a loop, still over threshold
            if(target.size() > threshold) timeout >>= 1;
            cursor = -1;
            count = 0;
        }
    }
};
#endif
