#include "fg_server.h"

void test_role_memory(FG_Server &server, int number)
{
    const int chat_per_role = 45;
    const int max_history_size = 20;
    ChatRoleInfo info;
    FRole role(info);
    role.info.name = "1234567890123456";
    role.chats.assign(chat_per_role,1);
    role.ignore.assign(chat_per_role,1);
    role.dirty.assign(chat_per_role,1);
    ChatRoleHistory history(0,0,"");
    history.object = "1234567890123456";
    role.history.assign(max_history_size,history);
    for(int i=0;i<number;++i)
    {
        role.info.name.begin();
        for(int j=0;j<max_history_size;++j)
        {
            role.history[j].object.begin();
        }
        server.OnLoadRole(i, role);
    }
}
void test_chat_memory(FG_Server &server, int number)
{
    const int max_history_size = 20;
    FChat chat(Octets("1234567890123456"),1);
    chat.intro= "123456789012345678901234567890123456789012345678901234567890";
    ChatRoleHistory history(0,0,"");
    history.object = "1234567890123456";
    chat.history.assign(max_history_size,history);
    for(int i=0;i<number;++i)
    {
        chat.chat_name.begin();
        chat.intro.begin();
        for(int j=0;j<max_history_size;++j)
        {
            chat.history[j].object.begin();
        }
        server.OnLoadChat(i, chat);
    }
}
void test_member_memory(FG_Server &server, int number)
{
    const int role_per_chat = 75;
    ChatRoleInfo info;
    FChatRole chatrole(info);
    std::map<int,FChatRole> member;
    for(int i=0;i<role_per_chat;++i)
    {
        member[i] = chatrole;
    }
    for(int i=0;i<number;++i)
    {
        server.OnLoadMember(i, member);
    }

    Octets name("1234567890123456");
    for(int i=0;i<role_per_chat*number;++i)
    {
        Octets *p = new Octets(name);
        p->begin();
    }
}
void test_other_memory(FG_Server &server, int name_num, int apply_num)
{
    Octets name("1234567890123456");
    for(int i=0;i<name_num;++i)
    {
        name.begin();
        server._names.insert(std::make_pair(name,i));
    }

    const int applys_per_chat = 2;
    ChatRoleInfo info;
    info.name="1234567890123456";
    for(int i=0;i<apply_num;++i)
    {
        for(int j=0;j<applys_per_chat;++j)
        {
            info.name.begin();
            server._applys[i].push_back(std::make_pair(j,info));
        }
    }
}

int main(int argc, char**argv)
{
    if(argc < 3) return -1;
    FG_Server server;
    if(strcmp(argv[1],"role") == 0)
    {
        puts("test role memory");
        int number = atoi(argv[2]);
        test_role_memory(server, number);
    }
    else if(strcmp(argv[1],"chat") == 0)
    {
        puts("test chat memory");
        int number = atoi(argv[2]);
        test_chat_memory(server, number);
    }
    else if(strcmp(argv[1],"member") == 0)
    {
        puts("test member memory");
        int number = atoi(argv[2]);
        test_member_memory(server, number);
    }
    else if(strcmp(argv[1],"other") == 0)
    {
        puts("test member memory");
        int name_num = atoi(argv[2]);
        int apply_num = atoi(argv[3]);
        test_other_memory(server, name_num, apply_num);
    }
    else if(strcmp(argv[1],"all") == 0)
    {
        if(argc != 7) return -1;
        puts("test all memory");
        int number1 = atoi(argv[2]);
        int number2 = atoi(argv[3]);
        int number3 = atoi(argv[4]);
        int number4 = atoi(argv[5]);
        int number5 = atoi(argv[6]);
        test_role_memory(server, number1);
        test_chat_memory(server, number2);
        test_member_memory(server, number3);
        test_other_memory(server, number4, number5);
    }
    puts("end");
    for(;;)
    {
        server.Update();
        sleep(1);
    }
    return 0;
}
