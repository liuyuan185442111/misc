#ifndef __AUXILIARY__
#define __AUXILIARY__

enum {
    ONLINE_STATE_NEW,
    ONLINE_STATE_TIMEOUT,
    ONLINE_STATE_DELAY,
};
enum {
    AGREE_INVITE_RE_STATE_NULL=0,
    AGREE_INVITE_RE_STATE_DENY=1,
    AGREE_INVITE_RE_STATE_TIMEOUT=2,
    AGREE_INVITE_RE_STATE_SUCCEED=3,
    AGREE_INVITE_RE_STATE_CHAT_FULL=4,
    AGREE_INVITE_RE_STATE_JOIN_FULL=5,
    AGREE_INVITE_RE_STATE_HAS_IN=6,
};

#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>
#include <string>
#include <vector>
#include <map>
void LOG_TRACE(const char *format,...);
#define LOG_INFO 0
#define LOG_RECHARGE 0
namespace Log
{
    void log(int, const char *format, ...);
    void vlogvital(int, const char *format, va_list ap);
}
struct Timer
{
    static time_t GetTime();
};
struct Thread
{
    struct Runnable
    {
        virtual void Run()=0;
    };
    struct HouseKeeper
    {
        static void AddTimerTask(Thread::Runnable*,time_t);
    };
};
typedef std::string Octets;
#include "rpcdata.h"
#endif
