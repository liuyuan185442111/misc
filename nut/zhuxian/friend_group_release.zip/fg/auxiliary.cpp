#include "auxiliary.h"
void LOG_TRACE(const char *format,...)
{
    size_t len = strlen(format);
    if(format[len] == '\n') 
    {
        va_list ap;
        va_start(ap,format);
        vprintf(format,ap);
        va_end(ap);
    }
    else
    {
        char buf[len+2];
        strcpy(buf, format);
        buf[len] = '\n';
        buf[len+1] = '\0';
        format = buf;
        va_list ap;
        va_start(ap,format);
        vprintf(format,ap);
        va_end(ap);
    }
}
namespace Log
{
    void log(int, const char *format, ...){}
    void vlogvital(int, const char *format, va_list ap){}
}
time_t Timer::GetTime()
{
    return time(NULL);
}
void Thread::HouseKeeper::AddTimerTask(Thread::Runnable*,time_t)
{
}
