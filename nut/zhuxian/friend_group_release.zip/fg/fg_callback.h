#ifndef __FG_HOOK_H__
#define __FG_HOOK_H__

class LoadChats_GetChatList
{
    FG_Server *_server;
    int _fg_roleid;
    std::map<int,FChatElement> &_chat_list;
    FIntVector &_loading_chats;
    FIntVector &_to_load_chats;
public:
    LoadChats_GetChatList(FG_Server *server,int fg_roleid,std::map<int,FChatElement> &chat_list,FIntVector &loading_chats,FIntVector &to_load_chats)
        :_server(server),_fg_roleid(fg_roleid),_chat_list(chat_list),_loading_chats(loading_chats),_to_load_chats(to_load_chats){}
    void Process(std::map<int,FChat> &chats)
    {
        for(std::map<int,FChat>::iterator it=chats.begin(); it!=chats.end(); ++it)
            _server->OnLoadChat(it->first, it->second);
        _server->GetChatList(_fg_roleid, _chat_list, _loading_chats, _to_load_chats);
    }
    void Timeout()
    {
        for(FIntVector::iterator it=_to_load_chats.begin(); it!=_to_load_chats.end(); ++it)
        {
            _server->LoadChatTimeout(*it);
        }
    }
};
class WaitChats_GetChatList:public Thread::Runnable
{
    FG_Server *_server;
    int _fg_roleid;
    std::map<int,FChatElement> &_chat_list;
    FIntVector &_loading_chats;
public:
    WaitChats_GetChatList(FG_Server *server,int fg_roleid,std::map<int,FChatElement> &chat_list,FIntVector &loading_chats)
        :_server(server),_fg_roleid(fg_roleid),_chat_list(chat_list),_loading_chats(loading_chats){}
    void Run()
    {
        _server->GetChatList(_fg_roleid, _chat_list, _loading_chats);
        delete this;
    }
};

struct LoadRoleInfo
{
    FG_Server *_server;
    LoadRoleInfo(FG_Server *server):_server(server){}
    virtual void Process(int fg_roleid, FRole &role)=0;
    virtual void Timeout(int fg_roleid)
    {
        _server->LoadRoleTimeout(fg_roleid);
    }
    virtual ~LoadRoleInfo()=0;
};
LoadRoleInfo::~LoadRoleInfo(){}

struct LoadChatInfo
{
    FG_Server *_server;
    LoadChatInfo(FG_Server *server):_server(server){}
    virtual void Process(int fg_chatid, FChat &chat)=0;
    virtual void Timeout(int fg_chatid)
    {
        _server->LoadChatTimeout(fg_chatid);
    }
    virtual ~LoadChatInfo()=0;
};
LoadChatInfo::~LoadChatInfo(){}

struct LoadChatMember
{
    FG_Server *_server;
    LoadChatMember(FG_Server *server):_server(server){}
    virtual void Process(int fg_chatid, std::map<int,FChatRole> &member)=0;
    virtual void Timeout(int fg_chatid)
    {
        _server->LoadMemberTimeout(fg_chatid);
    }
    virtual ~LoadChatMember()=0;
};
LoadChatMember::~LoadChatMember(){}

class LoadRoleUpdate_OnPlayerOn:public LoadRoleInfo
{
    ChatRoleInfo &_info;
    int _state;
    FIntVector &_offline_chats;
public:
    LoadRoleUpdate_OnPlayerOn(FG_Server *server,ChatRoleInfo &info,int state,FIntVector &offline_chats)
        :LoadRoleInfo(server),_info(info),_state(state),_offline_chats(offline_chats){}
    void Process(int fg_roleid, FRole &role)
    {
        _server->OnLoadRole(fg_roleid, role);
        _server->OnPlayerOn(fg_roleid, _info, _state, _offline_chats, true);
    }
};

class LoadRole_GetChatList:public LoadRoleInfo
{
public:
    LoadRole_GetChatList(FG_Server *server):LoadRoleInfo(server){}
    void Process(int fg_roleid, FRole &role)
    {
        _server->OnLoadRole(fg_roleid, role);
        _server->GetChatList(fg_roleid, 10);
    }
};

class LoadRole_GetChatIntro:public LoadRoleInfo
{
    int _fg_chatid;
public:
    LoadRole_GetChatIntro(FG_Server *server,int fg_chatid)
        :LoadRoleInfo(server),_fg_chatid(fg_chatid){}
    void Process(int fg_roleid, FRole &role)
    {
        _server->OnLoadRole(fg_roleid, role);
        _server->GetChatIntro(fg_roleid, _fg_chatid, 10);
    }
};
class LoadChat_GetChatIntro:public LoadChatInfo
{
    int _fg_roleid;
public:
    LoadChat_GetChatIntro(FG_Server *server,int fg_roleid)
        :LoadChatInfo(server),_fg_roleid(fg_roleid){}
     void Process(int fg_chatid, FChat &chat)
     {
         _server->OnLoadChat(fg_chatid, chat);
         _server->GetChatIntro(_fg_roleid, fg_chatid, 20);
     }
};

class LoadRole_GetChatMembers:public LoadRoleInfo
{
    int _fg_chatid;
public:
    LoadRole_GetChatMembers(FG_Server *server,int fg_chatid)
        :LoadRoleInfo(server),_fg_chatid(fg_chatid){}
    void Process(int fg_roleid, FRole &role)
    {
        _server->OnLoadRole(fg_roleid, role);
        _server->GetChatMembers(fg_roleid, _fg_chatid, 10);
    }
};
class LoadMember_GetChatMembers:public LoadChatMember
{
    int _fg_roleid;
public:
    LoadMember_GetChatMembers(FG_Server *server,int fg_roleid)
        :LoadChatMember(server),_fg_roleid(fg_roleid){}
    void Process(int fg_chatid, std::map<int,FChatRole> &member)
    {
        _server->OnLoadMember(fg_chatid, member);
        _server->GetChatMembers(_fg_roleid, fg_chatid, 30);
    }
};

class LoadRole_UpdateChatMembers:public LoadRoleInfo
{
    int _fg_chatid;
public:
    LoadRole_UpdateChatMembers(FG_Server *server,int fg_chatid)
        :LoadRoleInfo(server),_fg_chatid(fg_chatid){}
    void Process(int fg_roleid, FRole &role)
    {
        _server->OnLoadRole(fg_roleid, role);
        _server->UpdateChatMembers(fg_roleid, _fg_chatid, 10);
    }
};
class LoadMember_UpdateChatMembers:public LoadChatMember
{
    int _fg_roleid;
public:
    LoadMember_UpdateChatMembers(FG_Server *server,int fg_roleid)
        :LoadChatMember(server),_fg_roleid(fg_roleid){}
    void Process(int fg_chatid, std::map<int,FChatRole> &member)
    {
        _server->OnLoadMember(fg_chatid, member);
        _server->UpdateChatMembers(_fg_roleid, fg_chatid, 30);
    }
};

class LoadRole_CreateChat:public LoadRoleInfo
{
    ChatRoleInfo &_info;
    Octets &_chat_name;
public:
    LoadRole_CreateChat(FG_Server *server,ChatRoleInfo &info,Octets &chat_name)
        :LoadRoleInfo(server),_info(info),_chat_name(chat_name){}
    void Process(int fg_roleid, FRole &role)
    {
        _server->OnLoadRole(fg_roleid, role);
        _server->CreateChat(fg_roleid, _info, _chat_name, 10);
    }
};

class LoadRole_SetChatName:public LoadRoleInfo
{
    int _fg_chatid;
    Octets &_chat_name;
public:
    LoadRole_SetChatName(FG_Server *server,int fg_chatid,Octets &chat_name)
        :LoadRoleInfo(server),_fg_chatid(fg_chatid),_chat_name(chat_name){}
    void Process(int fg_roleid, FRole &role)
    {
        _server->OnLoadRole(fg_roleid, role);
        _server->SetChatName(fg_roleid, _fg_chatid, _chat_name, 10);
    }
};
class LoadChat_SetChatName:public LoadChatInfo
{
    int _fg_roleid;
    Octets &_chat_name;
public:
    LoadChat_SetChatName(FG_Server *server,int fg_roleid,Octets &chat_name)
        :LoadChatInfo(server),_fg_roleid(fg_roleid),_chat_name(chat_name){}
     void Process(int fg_chatid, FChat &chat)
     {
         _server->OnLoadChat(fg_chatid, chat);
         _server->SetChatName(_fg_roleid, fg_chatid, _chat_name, 20);
     }
};

class LoadRole_SetChatIntro:public LoadRoleInfo
{
    int _fg_chatid;
    Octets &_intro;
public:
    LoadRole_SetChatIntro(FG_Server *server,int fg_chatid,Octets &intro)
        :LoadRoleInfo(server),_fg_chatid(fg_chatid),_intro(intro){}
    void Process(int fg_roleid, FRole &role)
    {
        _server->OnLoadRole(fg_roleid, role);
        _server->SetChatIntro(fg_roleid, _fg_chatid, _intro, 10);
    }
};
class LoadChat_SetChatIntro:public LoadChatInfo
{
    int _fg_roleid;
    Octets &_intro;
public:
    LoadChat_SetChatIntro(FG_Server *server,int fg_roleid,Octets &intro)
        :LoadChatInfo(server),_fg_roleid(fg_roleid),_intro(intro){}
     void Process(int fg_chatid, FChat &chat)
     {
         _server->OnLoadChat(fg_chatid, chat);
         _server->SetChatIntro(_fg_roleid, fg_chatid, _intro, 20);
     }
};

class LoadChat_SetChatConfirm:public LoadChatInfo
{
    int _fg_roleid;
    int _zoneid;
    int _roleid;
    char _confirm;
public:
    LoadChat_SetChatConfirm(FG_Server *server,int fg_roleid,int zoneid,int roleid,char confirm)
        :LoadChatInfo(server),_fg_roleid(fg_roleid),_zoneid(zoneid),_roleid(roleid),_confirm(confirm){}
     void Process(int fg_chatid, FChat &chat)
     {
         _server->OnLoadChat(fg_chatid, chat);
         _server->SetChatConfirm(_fg_roleid, fg_chatid, _zoneid, _roleid, _confirm, 20);
     }
};

class LoadChat_SetChatCansearch:public LoadChatInfo
{
    int _fg_roleid;
    int _zoneid;
    int _roleid;
    char _can_search;
public:
    LoadChat_SetChatCansearch(FG_Server *server,int fg_roleid,int zoneid,int roleid,char can_search)
        :LoadChatInfo(server),_fg_roleid(fg_roleid),_zoneid(zoneid),_roleid(roleid),_can_search(can_search){}
     void Process(int fg_chatid, FChat &chat)
     {
         _server->OnLoadChat(fg_chatid, chat);
         _server->SetChatCansearch(_fg_roleid, fg_chatid, _zoneid, _roleid, _can_search, 20);
     }
};

class LoadRole_ChangeOnwer:public LoadRoleInfo
{
    int _fg_chatid;
    int _trans_to;
public:
    LoadRole_ChangeOnwer(FG_Server *server,int fg_chatid,int trans_to)
        :LoadRoleInfo(server),_fg_chatid(fg_chatid),_trans_to(trans_to){}
    void Process(int fg_roleid, FRole &role)
    {
        _server->OnLoadRole(fg_roleid, role);
        _server->ChangeOnwer(fg_roleid, _fg_chatid, _trans_to, 10);
    }
};
class LoadChat_ChangeOnwer:public LoadChatInfo
{
    int _fg_roleid;
    int _trans_to;
public:
    LoadChat_ChangeOnwer(FG_Server *server,int fg_roleid,int trans_to)
        :LoadChatInfo(server),_fg_roleid(fg_roleid),_trans_to(trans_to){}
     void Process(int fg_chatid, FChat &chat)
     {
         _server->OnLoadChat(fg_chatid, chat);
         _server->ChangeOnwer(_fg_roleid, fg_chatid, _trans_to, 20);
     }
};
class LoadRole_ChangeOnwer2:public LoadRoleInfo
{
    int _fg_roleid;
    int _fg_chatid;
public:
    LoadRole_ChangeOnwer2(FG_Server *server,int fg_roleid,int fg_chatid)
        :LoadRoleInfo(server),_fg_roleid(fg_roleid),_fg_chatid(fg_chatid){}
    void Process(int fg_roleid, FRole &role)
    {
        _server->OnLoadRole(fg_roleid, role);
        _server->ChangeOnwer(_fg_roleid, _fg_chatid, fg_roleid, 25);
    }
};

class LoadChat_KickMember:public LoadChatInfo
{
    int _fg_roleid;
    int _kick_roleid;
public:
    LoadChat_KickMember(FG_Server *server,int fg_roleid,int kick_roleid)
        :LoadChatInfo(server),_fg_roleid(fg_roleid),_kick_roleid(kick_roleid){}
     void Process(int fg_chatid, FChat &chat)
     {
         _server->OnLoadChat(fg_chatid, chat);
         _server->KickMember(_fg_roleid, fg_chatid, _kick_roleid, 20);
     }
};
class LoadMember_KickMember:public LoadChatMember
{
    int _fg_roleid;
    int _kick_roleid;
public:
    LoadMember_KickMember(FG_Server *server,int fg_roleid,int kick_roleid)
        :LoadChatMember(server),_fg_roleid(fg_roleid),_kick_roleid(kick_roleid){}
    void Process(int fg_chatid, std::map<int,FChatRole> &member)
    {
        _server->OnLoadMember(fg_chatid, member);
        _server->KickMember(_fg_roleid, fg_chatid, _kick_roleid, 30);
    }
};
class LoadRole_KickMember:public LoadRoleInfo
{
    int _fg_roleid;
    int _fg_chatid;
public:
    LoadRole_KickMember(FG_Server *server,int fg_roleid,int fg_chatid)
        :LoadRoleInfo(server),_fg_roleid(fg_roleid),_fg_chatid(fg_chatid){}
    void Process(int fg_roleid, FRole &role)
    {
        _server->OnLoadRole(fg_roleid, role);
        _server->KickMember(_fg_roleid, _fg_chatid, fg_roleid, 35);
    }
};

class LoadChat_DisbandChat:public LoadChatInfo
{
    int _fg_roleid;
public:
    LoadChat_DisbandChat(FG_Server *server,int fg_roleid)
        :LoadChatInfo(server),_fg_roleid(fg_roleid){}
     void Process(int fg_chatid, FChat &chat)
     {
         _server->OnLoadChat(fg_chatid, chat);
         _server->DisbandChat(_fg_roleid, fg_chatid, 20);
     }
};
class LoadMember_DisbandChat:public LoadChatMember
{
    int _fg_roleid;
public:
    LoadMember_DisbandChat(FG_Server *server,int fg_roleid)
        :LoadChatMember(server),_fg_roleid(fg_roleid){}
    void Process(int fg_chatid, std::map<int,FChatRole> &member)
    {
        _server->OnLoadMember(fg_chatid, member);
        _server->KickMember(_fg_roleid, fg_chatid, 30);
    }
};

class LoadRole_LeaveChat:public LoadRoleInfo
{
    int _fg_chatid;
public:
    LoadRole_LeaveChat(FG_Server *server,int fg_chatid)
        :LoadRoleInfo(server),_fg_chatid(fg_chatid){}
    void Process(int fg_roleid, FRole &role)
    {
        _server->OnLoadRole(fg_roleid, role);
        _server->LeaveChat(fg_roleid, _fg_chatid, 10);
    }
};
class LoadChat_LeaveChat:public LoadChatInfo
{
    int _fg_roleid;
public:
    LoadChat_LeaveChat(FG_Server *server,int fg_roleid)
        :LoadChatInfo(server),_fg_roleid(fg_roleid){}
     void Process(int fg_chatid, FChat &chat)
     {
         _server->OnLoadChat(fg_chatid, chat);
         _server->LeaveChat(_fg_roleid, fg_chatid, 20);
     }
};
class LoadMember_LeaveChat:public LoadChatMember
{
    int _fg_roleid;
public:
    LoadMember_LeaveChat(FG_Server *server,int fg_roleid)
        :LoadChatMember(server),_fg_roleid(fg_roleid){}
    void Process(int fg_chatid, std::map<int,FChatRole> &member)
    {
        _server->OnLoadMember(fg_chatid, member);
        _server->LeaveChat(_fg_roleid, fg_chatid, 30);
    }
};

class LoadRole_TellOnwerOneLeave:public LoadRoleInfo
{
    Octets &_chat_name;
    Octets &_leave_name;
public:
    LoadRole_TellOnwerOneLeave(FG_Server *server,Octets &chat_name,Octets &leave_name)
        :LoadRoleInfo(server),_chat_name(chat_name),_leave_name(leave_name){}
    void Process(int fg_roleid, FRole &role)
    {
        _server->OnLoadRole(fg_roleid, role);
        _server->TellOnwerOneLeave(fg_roleid, _chat_name, _leave_name, 10);
    }
};

class LoadChat_Search:public LoadChatInfo
{
    int _zoneid;
    int _roleid;
public:
    LoadChat_Search(FG_Server *server,int zoneid,int roleid)
        :LoadChatInfo(server),_zoneid(zoneid),_roleid(roleid){}
     void Process(int fg_chatid, FChat &chat)
     {
         _server->OnLoadChat(fg_chatid, chat);
         _server->SearchById(_zoneid, _roleid, fg_chatid, 20);
     }
};
class LoadRole_Search:public LoadRoleInfo
{
    int _zoneid;
    int _roleid;
    int _fg_chatid;
public:
    LoadRole_Search(FG_Server *server,int zoneid,int roleid,int fg_chatid)
        :LoadRoleInfo(server),_zoneid(zoneid),_roleid(roleid),_fg_chatid(fg_chatid){}
    void Process(int fg_roleid, FRole &role)
    {
        _server->OnLoadRole(fg_roleid, role);
        _server->SearchById(_zoneid, _roleid, _fg_chatid, 25);
    }
};

class LoadRole_Apply:public LoadRoleInfo
{
    int _fg_chatid;
    ChatRoleInfo &_info;
public:
    LoadRole_Apply(FG_Server *server,int fg_chatid,ChatRoleInfo &info)
        :LoadRoleInfo(server),_fg_chatid(fg_chatid),_info(info){}
    void Process(int fg_roleid, FRole &role)
    {
        _server->OnLoadRole(fg_roleid, role);
        _server->Apply(fg_roleid, _fg_chatid, _info, 10);
    }
};
class LoadChat_Apply:public LoadChatInfo
{
    int _fg_roleid;
    ChatRoleInfo &_info;
public:
    LoadChat_Apply(FG_Server *server,int fg_roleid,ChatRoleInfo &info)
        :LoadChatInfo(server),_fg_roleid(fg_roleid),_info(info){}
     void Process(int fg_chatid, FChat &chat)
     {
         _server->OnLoadChat(fg_chatid, chat);
         _server->Apply(_fg_roleid, fg_chatid, _info, 20);
     }
};

class LoadRole_AutoConfirm:public LoadRoleInfo
{
    int _fg_chatid;
    int _app_oroleid;
    int _confirm;
public:
    LoadRole_AutoConfirm(FG_Server *server,int fg_chatid,int app_oroleid,int confirm)
        :LoadRoleInfo(server),_fg_chatid(fg_chatid),_app_oroleid(app_oroleid),_confirm(confirm){}
    void Process(int fg_roleid, FRole &role)
    {
        _server->OnLoadRole(fg_roleid, role);
        _server->AutoConfirm(fg_roleid, _fg_chatid, _app_oroleid, _confirm, 10);
    }
};

class LoadChat_GetApplicants:public LoadChatInfo
{
    int _fg_roleid;
    int _zoneid;
    int _roleid;
public:
    LoadChat_GetApplicants(FG_Server *server,int fg_roleid,int zoneid,int roleid)
        :LoadChatInfo(server),_fg_roleid(fg_roleid),_zoneid(zoneid),_roleid(roleid){}
     void Process(int fg_chatid, FChat &chat)
     {
         _server->OnLoadChat(fg_chatid, chat);
         _server->GetApplicants(_fg_roleid, fg_chatid, _zoneid, _roleid, 20);
     }
};

class LoadChat_AgreeApply:public LoadChatInfo
{
    int _fg_roleid;
    int _zoneid;
    int _roleid;
    int _applicant;
    bool _agree;
public:
    LoadChat_AgreeApply(FG_Server *server,int fg_roleid,int zoneid,int roleid,int applicant,bool agree)
        :LoadChatInfo(server),_fg_roleid(fg_roleid),_zoneid(zoneid),_roleid(roleid),_applicant(applicant),_agree(agree){}
     void Process(int fg_chatid, FChat &chat)
     {
         _server->OnLoadChat(fg_chatid, chat);
         _server->AgreeApply(_fg_roleid, fg_chatid, _zoneid, _roleid, _applicant, _agree, 20);
     }
};

class LoadRole_JoinIntoChat:public LoadRoleInfo
{
    int _fg_chatid;
    int _owner_zoneid;
    int _owner_roleid;
public:
    LoadRole_JoinIntoChat(FG_Server *server,int fg_chatid,int owner_zoneid,int owner_roleid)
        :LoadRoleInfo(server),_fg_chatid(fg_chatid),_owner_zoneid(owner_zoneid),_owner_roleid(owner_roleid){}
    void Process(int fg_roleid, FRole &role)
    {
        _server->OnLoadRole(fg_roleid, role);
        _server->JoinIntoChat(fg_roleid, _fg_chatid, _owner_zoneid, _owner_roleid, 10);
    }
};
class LoadChat_JoinIntoChat:public LoadChatInfo
{
    int _fg_roleid;
    int _owner_zoneid;
    int _owner_roleid;
public:
    LoadChat_JoinIntoChat(FG_Server *server,int fg_roleid,int owner_zoneid,int owner_roleid)
        :LoadChatInfo(server),_fg_roleid(fg_roleid),_owner_zoneid(owner_zoneid),_owner_roleid(owner_roleid){}
     void Process(int fg_chatid, FChat &chat)
     {
         _server->OnLoadChat(fg_chatid, chat);
         _server->JoinIntoChat(_fg_roleid, fg_chatid, _owner_zoneid, _owner_roleid, 20);
     }
};
class LoadMember_JoinIntoChat:public LoadChatMember
{
    int _fg_roleid;
    int _owner_zoneid;
    int _owner_roleid;
public:
    LoadMember_JoinIntoChat(FG_Server *server,int fg_roleid,int owner_zoneid,int owner_roleid)
        :LoadChatMember(server),_fg_roleid(fg_roleid),_owner_zoneid(owner_zoneid),_owner_roleid(owner_roleid){}
    void Process(int fg_chatid, std::map<int,FChatRole> &member)
    {
        _server->OnLoadMember(fg_chatid, member);
        _server->JoinIntoChat(_fg_roleid, fg_chatid, _owner_zoneid, _owner_roleid, 30);
    }
};

class LoadMember_BroadcastNotice:public LoadChatMember
{
    FG_RNotice &_notice;
public:
    LoadMember_BroadcastNotice(FG_Server *server,FG_RNotice &notice)
        :LoadChatMember(server),_notice(notice){}
    void Process(int fg_chatid, std::map<int,FChatRole> &member)
    {
        _server->OnLoadMember(fg_chatid, member);
        _server->BroadcastNotice(fg_chatid, _notice, 30);
    }
};

class LoadChat_ActiveChatName:public LoadChatInfo
{
public:
    LoadChat_ActiveChatName(FG_Server *server):LoadChatInfo(server){}
     void Process(int fg_chatid, FChat &chat)
     {
         _server->OnLoadChat(fg_chatid, chat);
         _server->ActiveChatName(fg_chatid, 20);
     }
};

class LoadMember_Talk:public LoadChatMember
{
    int _fg_roleid;
    char _vip;
    Octets &_msg;
public:
    LoadMember_Talk(FG_Server *server,int fg_roleid,char vip,Octets &msg)
        :LoadChatMember(server),_fg_roleid(fg_roleid),_vip(vip),_msg(msg){}
    void Process(int fg_chatid, std::map<int,FChatRole> &member)
    {
        _server->OnLoadMember(fg_chatid, member);
        _server->Talk(_fg_roleid, fg_chatid, _vip, _msg, 30);
    }
};

class LoadRole_IgnoreMsg:public LoadRoleInfo
{
    int _fg_chatid;
    bool _ignore;
public:
    LoadRole_IgnoreMsg(FG_Server *server,int fg_chatid,int ignore)
        :LoadRoleInfo(server),_fg_chatid(fg_chatid),_ignore(ignore){}
    void Process(int fg_roleid, FRole &role)
    {
        _server->OnLoadRole(fg_roleid, role);
        _server->IgnoreMsg(fg_roleid, _fg_chatid, _ignore, 10);
    }
};
class LoadMember_IgnoreMsg:public LoadChatMember
{
    int _fg_roleid;
    bool _ignore;
public:
    LoadMember_IgnoreMsg(FG_Server *server,int fg_roleid,bool ignore)
        :LoadChatMember(server),_fg_roleid(fg_roleid),_ignore(ignore){}
    void Process(int fg_chatid, std::map<int,FChatRole> &member)
    {
        _server->OnLoadMember(fg_chatid, member);
        _server->IgnoreMsg(_fg_roleid, fg_chatid, _ignore, 30);
    }
};

class LoadChat_AddChatCapacity:public LoadChatInfo
{
    int _fg_roleid;
    int _add_capacity;
    int _zoneid;
    int _roleid;
public:
    LoadChat_AddChatCapacity(FG_Server *server,int fg_roleid,int add_capacity,int zoneid,int roleid)
        :LoadChatInfo(server),_fg_roleid(fg_roleid),_add_capacity(add_capacity),_zoneid(zoneid),_roleid(roleid){}
     void Process(int fg_chatid, FChat &chat)
     {
         _server->OnLoadChat(fg_chatid, chat);
         _server->AddChatCapacity(_fg_roleid, fg_chatid, _add_capacity, _zoneid, _roleid, 20);
     }
};

class LoadRole_AddOwnLimit:public LoadRoleInfo
{
    int _add;
public:
    LoadRole_AddOwnLimit(FG_Server *server,int add)
        :LoadRoleInfo(server),_add(add){}
    void Process(int fg_roleid, FRole &role)
    {
        _server->OnLoadRole(fg_roleid, role);
        _server->AddOwnLimit(fg_roleid, _add, 10);
    }
};

class LoadRole_AddJoinLimit:public LoadRoleInfo
{
    int _add;
public:
    LoadRole_AddJoinLimit(FG_Server *server,int add)
        :LoadRoleInfo(server),_add(add){}
    void Process(int fg_roleid, FRole &role)
    {
        _server->OnLoadRole(fg_roleid, role);
        _server->AddJoinLimit(fg_roleid, _add, 10);
    }
};

class LoadRole_Invite:public LoadRoleInfo
{
    int _fg_chatid;
    int _zoneid;
    int _invitee_oroleid;
public:
    LoadRole_Invite(FG_Server *server,int fg_chatid,int zoneid,int invitee_oroleid)
        :LoadRoleInfo(server),_fg_chatid(fg_chatid),_zoneid(zoneid),_invitee_oroleid(invitee_oroleid){}
    void Process(int fg_roleid, FRole &role)
    {
        _server->OnLoadRole(fg_roleid, role);
        _server->Invite(fg_roleid, _fg_chatid, _zoneid, _invitee_oroleid, 10);
    }
};

class LoadRole_AgreeInvite:public LoadRoleInfo
{
    int _fg_chatid;
    ChatRoleInfo &_info;
    int _owner_oroleid;
public:
    LoadRole_AgreeInvite(FG_Server *server,int fg_chatid,ChatRoleInfo &info,int owner_oroleid)
        :LoadRoleInfo(server),_fg_chatid(fg_chatid),_info(info),_owner_oroleid(owner_oroleid){}
    void Process(int fg_roleid, FRole &role)
    {
        _server->OnLoadRole(fg_roleid, role);
        _server->AgreeInvite(fg_roleid, _fg_chatid, _info, _owner_oroleid, 10);
    }
};
class LoadChat_AgreeInvite:public LoadChatInfo
{
    int _fg_roleid;
    ChatRoleInfo &_info;
    int _owner_oroleid;
public:
    LoadChat_AgreeInvite(FG_Server *server,int fg_roleid,ChatRoleInfo &info,int owner_oroleid)
        :LoadChatInfo(server),_fg_roleid(fg_roleid),_info(info),_owner_oroleid(owner_oroleid){}
     void Process(int fg_chatid, FChat &chat)
     {
         _server->OnLoadChat(fg_chatid, chat);
        _server->AgreeInvite(_fg_roleid, fg_chatid, _info, _owner_oroleid, 20);
     }
};
class LoadMember_AgreeToJoin:public LoadChatMember
{
    int _fg_roleid;
    ChatRoleInfo &_info;
    int _owner_roleid;
public:
    LoadMember_AgreeToJoin(FG_Server *server,int fg_roleid,ChatRoleInfo &info,int owner_roleid)
        :LoadChatMember(server),_fg_roleid(fg_roleid),_info(info),_owner_roleid(owner_roleid){}
    void Process(int fg_chatid, std::map<int,FChatRole> &member)
    {
        _server->OnLoadMember(fg_chatid, member);
        _server->AgreeInvite(_fg_roleid, fg_chatid, _info, _owner_roleid, 30);
    }
};

class LoadRole_GetHistory:public LoadRoleInfo
{
public:
    LoadRole_GetHistory(FG_Server *server)
        :LoadRoleInfo(server){}
    void Process(int fg_roleid, FRole &role)
    {
        _server->OnLoadRole(fg_roleid, role);
        _server->GetRoleHistory(fg_roleid, 10);
    }
};

#endif
