#include "fg_server.h"
#include "fg_callback.h"

#define FG_DEBUG
#ifdef FG_DEBUG
static void debuglog(const char *format,...)
{
    va_list ap;
    va_start(ap,format);
    Log::vlogvital(LOG_RECHARGE,format,ap);
    va_end(ap);
}
#else
#define debuglog(...)
#endif

#define FIND_ROLE role_iter it1=_roles.find(fg_roleid);\
    if(it1==_roles.end()&&step>=10)return;if(it1==_roles.end())
#define FIND_CHAT chat_iter it2=_chats.find(fg_chatid);\
    if(it2==_chats.end()&&step>=20)return;if(it2==_chats.end())
#define FIND_MEMBER member_iter it3=_members.find(fg_chatid);\
    if(it3==_members.end()&&step>=30)return;if(it3==_members.end()) 
#define ACTIVE_ROLE else if(step<10) it1->second.update_active_time
#define ACTIVE_CHAT else if(step<20) it2->second.update_active_time
#define ACTIVE_MEMBER else if(step<30) it3->second.update_active_time

static bool not_expired(ChatRoleHistory &history)
{
    return Timer::GetTime() - history.time < FG_HISTORY_EXPIRE_TIME;
}
FG_Server::role_iter FG_Server::OnLoadRole(int fg_roleid, FRole &role)
{
    debuglog("OnLoadRole:fg_roleid=%d\n,fg_roleid");
    role.history.erase(role.history.begin(), std::find_if(role.history.begin(), role.history.end(), not_expired));
    return _roles.insert(std::make_pair(fg_roleid,role)).first;
}
FG_Server::chat_iter FG_Server::OnLoadChat(int fg_chatid, FChat &chat)
{
    debuglog("OnLoadChat:fg_chatid=%d\n,fg_chatid");
    _loading_chats.erase(fg_chatid);
    return _chats.insert(std::make_pair(fg_chatid,chat)).first;
}
FG_Server::member_iter FG_Server::OnLoadMember(int fg_chatid, std::map<int,FChatRole> &member)
{
    debuglog("OnLoadMember:fg_chatid=%d\n",fg_chatid);
    return _members.insert(std::make_pair(fg_chatid,member)).first;
}

bool FG_Server::update_roleinfo_aux1(int fg_roleid, FIntVector &chats, ChatRoleInfo &info)
{
    for(FIntVector::iterator it2=chats.begin(); it2!=chats.end(); ++it2)
    {
        member_iter it3 = _members.find(*it2);
        if(it3 != _members.end())
        {
            it3->second.update_member_info(fg_roleid, info, true);
        }
    }
}
bool FG_Server::update_roleinfo_aux2(int fg_roleid, FIntVector &chats)
{
    for(FIntVector::iterator it2=chats.begin(); it2!=chats.end(); ++it2)
    {
        member_iter it3 = _members.find(*it2);
        if(it3 != _members.end())
        {
            it3->second.update_member_online(fg_roleid, true);
        }
    }
}
bool FG_Server::update_roleinfo(int fg_roleid, ChatRoleInfo &info, int state, FIntVector &offline_chats, bool from_db)
{
    role_iter it1 = _roles.find(fg_roleid);
    if(it1 == _roles.end()) return false;
    FG_Role &role = it1->second;
    role.update_active_time();

    if(state == ONLINE_STATE_NEW)
    {
        int ret = role.update_roleinfo(info);
        if(ret == FG_Role::ROUTE_CHANGED)
        {
            update_roleinfo_aux1(fg_roleid, role.chats, info);
            if(!from_db)
            {
                send2db();//FG_DBRoleRouteChanged
            }
        }
        else if(ret == FG_Role::INFO_CHANGED)
        {
            update_roleinfo_aux1(fg_roleid, role.chats, info);
        }
        else if(ret == FG_Role::NOT_CHANGED)
        {
            update_roleinfo_aux2(fg_roleid, role.chats);
        }
    }
    if(!offline_chats.empty())
    {
        if(state == ONLINE_STATE_TIMEOUT)
        {
            int ret = role.update_roleinfo(info);
            if(ret == FG_Role::INFO_CHANGED)
            {
                update_roleinfo_aux1(fg_roleid, role.chats, info);
                //update_roleinfo_aux2(fg_roleid, offline_chats);
            }
            else if(ret == FG_Role::NOT_CHANGED)
            {
                update_roleinfo_aux2(fg_roleid, offline_chats);
            }
        }
        else if(state == ONLINE_STATE_DELAY)
        {
            update_roleinfo_aux2(fg_roleid, offline_chats);
        }
    }
    return true;
}

void FG_Server::dispose_and_send_chatlist(int fg_roleid, std::map<int,FChatElement> &chat_list)
{
    role_iter it1 = _roles.find(fg_roleid);
    if(it1 == _roles.end()) return;

    bool save_flag = false;
    std::map<int,FChatElement>::iterator it2 = chat_list.begin();
    for(; it2 != chat_list.end(); ++it2)
    {
        if(it2->second.is_delete)
        {
            it1->second.rm_chat(it2->first);
            save_flag = true;
        }
    }
    if(save_flag) save_role(fg_roleid);

    FG_RChatList re;
    it1->second.info.roleid;
    fg_roleid;
    it1->second.get_own_limit();
    it1->second.get_join_limit();
    chat_list;
    send2client(it1->second.info.zoneid, re);
}

//state为ONLINE_STATE_NEW表示原服启动后该玩家首次登陆,route如有变化发生在此时
//offline_chats为原服维护的检测到的玩家处于离线状态的群
void FG_Server::OnPlayerOn(int fg_roleid, ChatRoleInfo &info, int state, FIntVector &offline_chats, bool from_db)
{
    debuglog("OnPlayerOn:fg_roleid=%d,state=%d,from_db=%d",fg_roleid,state,(int)from_db);
    if(!update_roleinfo(fg_roleid, info, state, offline_chats, from_db) && !from_db)
    {
        //请求加载role数据并让db去检查role有无更新,如有更新即时保存(如果route修改则需同时修改其所有群)
        LoadRoleUpdate_OnPlayerOn load(this,info,state,offline_chats);
        send2db();//FG_DBLoadRoleUpdate
    }
}

void FG_Server::GetChatList(int fg_roleid, int step)
{
    debuglog("GetChatList:fg_roleid=%d,step=%d",fg_roleid,step);
    FIND_ROLE {
        LoadRole_GetChatList load(this);
        send2db();//FG_DBLoadRole
        return;
    }
    ACTIVE_ROLE();
    FG_Role &role = it1->second;
    std::map<int,FChatElement> chat_list;
    FIntVector loading_chats;
    FIntVector to_load_chats;
    FIntVector::iterator it2 = role.chats.begin();
    for(int count=0; it2!=role.chats.end(); ++it2,++count)
    {
        FChatElement element(count<role.own_count, role.ignore[count]);
        chat_iter it3 = _chats.find(*it2);
        if(it3 == _chats.end())
        {
            if(_loading_chats.find(*it2) == _loading_chats.end())
            {
                to_load_chats.push_back(*it2);
                _loading_chats.insert(*it2);
            }
            else
            {
                loading_chats.push_back(*it2);
            }
        }
        else
        {
            element.is_delete = it3->second.is_delete;
            element.chat_name = it3->second.chat_name;
            if(element.is_owner)
            {
                element.confirm = it3->second.confirm;
                element.can_search = it3->second.can_search;
                element.capacity_addon = it3->second.capacity_addon;
            }
        }
        chat_list.insert(std::make_pair(*it2,element));
    }
    //需要从db读取,返回时loading_chats中的应已就位
    if(!to_load_chats.empty())
    {
        LoadChats_GetChatList load(this,fg_roleid,chat_list,loading_chats,to_load_chats);
        send2db();//FG_DBLoadChats
        return;
    }
    //如果需要的全都在loading中,过段时间再来看
    if(loading_chats.empty())
    {
        dispose_and_send_chatlist(fg_roleid, chat_list);
    }
    else
    {
        Thread::HouseKeeper::AddTimerTask(new WaitChats_GetChatList(this,fg_roleid,chat_list,loading_chats),2);
    }
}

#define GetChatListMacro \
        chat_iter it2 = _chats.find(*it);\
        if(it2 != _chats.end()){\
            FChatElement &element = chat_list[*it];\
            element.is_delete = it2->second.is_delete;\
            element.chat_name = it2->second.chat_name;\
            if(element.is_owner){\
                element.confirm = it2->second.confirm;\
                element.can_search = it2->second.can_search;\
                element.capacity_addon = it2->second.capacity_addon;}}
void FG_Server::GetChatList(int fg_roleid, std::map<int,FChatElement> &chat_list, FIntVector &loading_chats, FIntVector &to_load_chats)
{
    debuglog("GetChatList2:fg_roleid=%d",fg_roleid);
    if(_roles.find(fg_roleid) == _roles.end()) return;
    FIntVector::iterator it = loading_chats.begin();
    for(; it != loading_chats.end(); ++it)
    {
        GetChatListMacro
    }
    for(it = to_load_chats.begin(); it != to_load_chats.end(); ++it)
    {
        GetChatListMacro
    }
    dispose_and_send_chatlist(fg_roleid, chat_list);
}
void FG_Server::GetChatList(int fg_roleid, std::map<int,FChatElement> &chat_list, FIntVector &loading_chats)
{
    debuglog("GetChatList3:fg_roleid=%d",fg_roleid);
    if(_roles.find(fg_roleid) == _roles.end()) return;
    FIntVector::iterator it = loading_chats.begin();
    for(; it != loading_chats.end(); ++it)
    {
        GetChatListMacro
    }
    dispose_and_send_chatlist(fg_roleid, chat_list);
}
#undef GetChatListMacro

void FG_Server::GetChatMembers(int fg_roleid, int fg_chatid, int step)
{
    debuglog("GetChatMembers:fg_roleid=%d,fg_chatid=%d,step=%d",fg_roleid,fg_chatid,step);
    FIND_ROLE {
        LoadRole_GetChatMembers load(this,fg_chatid);
        send2db();//FG_DBLoadRole
        return;
    }
    ACTIVE_ROLE();
    FIND_MEMBER {
        LoadMember_GetChatMembers load(this,fg_roleid);
        send2db();//FG_DBLoadMember
        return;
    }
    ACTIVE_MEMBER();

    FG_RChatMembers re;
    it1->second.info.roleid;
    fg_chatid;
    FMember &members = it3->second.members;
    for(FMember::iterator it8=members.begin(); it8!=members.end(); ++it8)
        re.members[it8->first] = it8->second.info;
    send2client(it1->second.info.zoneid, re);
}

void FG_Server::UpdateChatMembers(int fg_roleid, int fg_chatid, int step)
{
    debuglog("UpdateChatMembers:fg_roleid=%d,fg_chatid=%d,step=%d",fg_roleid,fg_chatid,step);
    FIND_ROLE {
        LoadRole_UpdateChatMembers load(this,fg_chatid);
        send2db();//FG_DBLoadRole
        return;
    }
    ACTIVE_ROLE();
    FIND_MEMBER {
        LoadMember_UpdateChatMembers load(this,fg_roleid);
        send2db();//FG_DBLoadMember
        return;
    }
    ACTIVE_MEMBER();

    bool save_flag = true;
    FMember::iterator it6 = it3->second.members.begin();
    for(; it6 != it3->second.members.end(); ++it6)
    {
        role_iter it7 = _roles.find(it6->first);
        if(it7 == _roles.end()) continue;
        if(!it7->second.clear_dirty(fg_chatid)) continue;
        save_role(it6->first);
        it3->second.update_member_info(it6->first, it7->second.info, false);
        save_flag = true;
    }
    if(save_flag) save_member(fg_chatid);

    //GetChatMembers(fg_roleid, fg_chatid, 30);
    FG_RChatMembers re;
    it1->second.info.roleid;
    fg_chatid;
    FMember &members = it3->second.members;
    for(FMember::iterator it8=members.begin(); it8!=members.end(); ++it8)
        re.members[it8->first] = it8->second.info;
    send2client(it1->second.info.zoneid, re);
}

void FG_Server::GetChatIntro(int fg_roleid, int fg_chatid, int step)
{
    debuglog("GetChatIntro:fg_roleid=%d,fg_chatid=%d,step=%d",fg_roleid,fg_chatid,step);
    FIND_ROLE {
        LoadRole_GetChatIntro load(this,fg_chatid);
        send2db();//FG_DBLoadRole
        return;
    }
    ACTIVE_ROLE();
    if(step <= 10 && it1->second.get_pos(fg_chatid) < 0) return;
    FIND_CHAT {
        _loading_chats.insert(fg_chatid);
        LoadChat_GetChatIntro load(this,fg_roleid);
        send2db();//FG_DBLoadChat
        return;
    }
    ACTIVE_CHAT();

    FG_RChatIntro re;
    it1->second.info.roleid;
    fg_chatid;
    it2->second.intro;
    send2client(it1->second.info.zoneid, re);
}

void FG_Server::SetChatConfirm(int fg_roleid, int fg_chatid, int zoneid, int roleid, char confirm, int step)
{
    debuglog("SetChatConfirm:fg_roleid=%d,fg_chatid=%d,zoneid=%d,roleid=%d,confirm=%0x,step=%d",fg_roleid,fg_chatid,zoneid,roleid,(int)confirm,step);
    FIND_CHAT {
        _loading_chats.insert(fg_chatid);
        LoadChat_SetChatConfirm load(this,fg_roleid,zoneid,roleid,confirm);
        send2db();//FG_DBLoadChat
        return;
    }
    ACTIVE_CHAT();
    if(it2->second.owner != fg_roleid) return;

    it2->second.confirm = confirm;
    save_chat(fg_chatid);
}

void FG_Server::SetChatCansearch(int fg_roleid, int fg_chatid, int zoneid, int roleid, bool can_search, int step)
{
    debuglog("SetChatCansearch:fg_roleid=%d,fg_chatid=%d,zoneid=%d,roleid=%d,can_search=%d,step=%d",fg_roleid,fg_chatid,zoneid,roleid,(int)can_search,step);
    FIND_CHAT {
        _loading_chats.insert(fg_chatid);
        LoadChat_SetChatCansearch load(this,fg_roleid,zoneid,roleid,can_search);
        send2db();//FG_DBLoadChat
        return;
    }
    ACTIVE_CHAT();
    if(it2->second.owner != fg_roleid) return;

    it2->second.can_search = can_search;
    save_chat(fg_chatid);
}

void FG_Server::ChangeOnwer(int fg_roleid, int fg_chatid, int trans_to, int step)
{
    debuglog("ChangeOnwer:fg_roleid=%d,fg_chatid=%d,trans_to=%d,step=%d",fg_roleid,fg_chatid,trans_to,step);
    FIND_ROLE {
        LoadRole_ChangeOnwer load(this,fg_chatid,trans_to);
        send2db();//FG_DBLoadRole
        return;
    }
    ACTIVE_ROLE();
    FIND_CHAT {
        _loading_chats.insert(fg_chatid);
        LoadChat_ChangeOnwer load(this,fg_roleid,trans_to);
        send2db();//FG_DBLoadChat
        return;
    }
    ACTIVE_CHAT();
    if(it2->second.owner != fg_roleid) return;
    role_iter it6 = _roles.find(trans_to);
    if(it6 == _roles.end())
    {
        if(step < 25)
        {
            LoadRole_ChangeOnwer2 load(this,fg_roleid,fg_chatid);
            send2db();//FG_DBLoadRole
        }
        return;
    }
    if(step < 25) it6->second.update_active_time();
    if(it6->second.get_pos(fg_chatid) < 0) return;

    if(it1->second.can_join() && it6->second.can_own())
    {
        it1->second.mv_chat(fg_chatid);
        it6->second.mv_chat(fg_chatid);
        it2->second.owner = trans_to;
        save_role(fg_roleid);
        save_role(trans_to);
        save_chat(fg_chatid);
        LOG_TRACE("FG_Server::ChangeOnwer:fg_roleid=%d,fg_chatid=%d,trans=%d",fg_roleid,fg_chatid,trans_to);

        notice_msg(fg_chatid, FG_NOTICE_CHANGE_OWNER, trans_to);
        point_msg(it6->second.info.zoneid, it6->second.info.roleid, FG_POINT_BE_OWNER, it2->second.chat_name);
    }
    else
    {
        err_msg(it1->second.info.zoneid, it1->second.info.roleid, FG_ERR_CHANGE_OWNER);
    }
}

void FG_Server::IgnoreMsg(int fg_roleid, int fg_chatid, bool ignore, int step)
{
    debuglog("IgnoreMsg:fg_roleid=%d,fg_chatid=%d,ignore=%d,step=%d",fg_roleid,fg_chatid,(int)ignore,step);
    FIND_ROLE {
        LoadRole_IgnoreMsg load(this,fg_chatid,ignore);
        send2db();//FG_DBLoadRole
        return;
    }
    ACTIVE_ROLE();
    if(step <= 10 && !it1->second.can_set_ignore(fg_chatid,ignore)) return;
    FIND_MEMBER {
        LoadMember_IgnoreMsg load(this,fg_roleid,ignore);
        send2db();//FG_DBLoadMember
        return;
    }
    ACTIVE_MEMBER();

    FMember::iterator it6 = it3->second.members.find(fg_roleid);
    if(it6 == it3->second.members.end()) return;
    it1->second.set_ignore(fg_chatid, ignore);
    it6->second.ignore_msg = ignore;
    save_role(fg_roleid);
    save_member(fg_chatid);
}

void FG_Server::ActiveChatName(int fg_chatid, int step)
{
    debuglog("ActiveChatName:fg_chatid=%d,step=%d",fg_chatid,step);
    FIND_CHAT {
        _loading_chats.insert(fg_chatid);
        LoadChat_ActiveChatName load(this);
        send2db();//FG_DBLoadChat
        return;
    }
    ACTIVE_CHAT();

    _names.insert(std::make_pair(it2->second.chat_name,fg_chatid));
}

void FG_Server::Talk(int fg_roleid, int fg_chatid, char vip, Octets &msg, int step)
{
    debuglog("Talk:fg_roleid=%d,fg_chatid=%d,vip=%d,step=%d",fg_roleid,fg_chatid,(int)vip,step);
    if(msg.size() > FG_MAX_SIZE_OF_TALK) return;
    FIND_MEMBER {
        LoadMember_Talk load(this,fg_roleid,vip,msg);
        send2db();//FG_DBLoadMember
        return;
    }
    ACTIVE_MEMBER();

    FMember &member = it3->second.members;
    if(member.find(fg_roleid) == member.end()) return;
    for(std::map<int,FG_ChatRole>::iterator it2=member.begin(); it2!=member.end(); ++it2)
    {
        if(it2->first == fg_roleid) continue;//self
        if(!it2->second.online) continue;
        if(it2->second.ignore_msg) continue;

        FG_RTalk talk;
        it2->second.info.roleid;
        fg_chatid;
        fg_roleid;
        vip;
        msg;
        send2client(it2->second.info.zoneid, talk);
    }
}

void FG_Server::CreateChat(int fg_roleid, ChatRoleInfo &info, Octets &chat_name, int step)
{
    debuglog("CreateChat:fg_roleid=%d,step=%d",fg_roleid,step);
    if(chat_name.size() > FG_MAX_SIZE_OF_CHAT_NAME) return;
    bool save_flag = false;
    if(fg_roleid == 0)
    {
        fg_roleid = alloc_roleid();
        _roles.insert(std::make_pair(fg_roleid, FRole(info)));
        save_flag = true;

        FG_RAllocRoleid re;
        info.roleid;
        fg_roleid;
        send2client(info.zoneid, re);
    }
    FIND_ROLE {
        LoadRole_CreateChat load(this,info,chat_name);
        send2db();//FG_DBLoadRole
        return;
    }
    ACTIVE_ROLE();

    if(it1->second.can_own())
    {
        int fg_chatid = alloc_chatid();
        it1->second.own_chat(fg_chatid);
        save_flag = true;
        _chats.insert(std::make_pair(fg_chatid, FChat(chat_name,fg_roleid)));
        save_chat(fg_chatid);
        LOG_TRACE("FG_Server::CreateChat:fg_roleid=%d,fg_chatid=%d",fg_roleid,fg_chatid);
    }
    if(save_flag)
    {
        save_id();
        save_role(fg_roleid);
    }
}

void FG_Server::SetChatName(int fg_roleid, int fg_chatid, Octets &chat_name, int step)
{
    debuglog("SetChatName:fg_roleid=%d,fg_chatid=%d,step=%d",fg_roleid,fg_chatid,step);
    if(chat_name.size() > FG_MAX_SIZE_OF_CHAT_NAME) return;
    FIND_ROLE {
        LoadRole_SetChatName load(this,fg_chatid,chat_name);
        send2db();//FG_DBLoadRole
        return;
    }
    ACTIVE_ROLE();
    FIND_CHAT {
        _loading_chats.insert(fg_chatid);
        LoadChat_SetChatName load(this,fg_roleid,chat_name);
        send2db();//FG_DBLoadChat
        return;
    }
    ACTIVE_CHAT();
    if(it2->second.owner != fg_roleid) return;

    it2->second.chat_name = chat_name;
    save_chat(fg_chatid);
}

void FG_Server::SetChatIntro(int fg_roleid, int fg_chatid, Octets &intro, int step)
{
    debuglog("SetChatIntro:fg_roleid=%d,fg_chatid=%d,step=%d",fg_roleid,fg_chatid,step);
    if(intro.size() > FG_MAX_SIZE_OF_CHAT_INTRO) return;
    FIND_ROLE {
        LoadRole_SetChatIntro load(this,fg_chatid,intro);
        send2db();//FG_DBLoadRole
        return;
    }
    ACTIVE_ROLE();
    FIND_CHAT {
        _loading_chats.insert(fg_chatid);
        LoadChat_SetChatIntro load(this,fg_roleid,intro);
        send2db();//FG_DBLoadChat
        return;
    }
    ACTIVE_CHAT();
    if(it2->second.owner != fg_roleid) return;

    it2->second.intro = intro;
    save_chat(fg_chatid);
}

void FG_Server::KickMember(int fg_roleid, int fg_chatid, int kick_roleid, int step)
{
    debuglog("KickMember:fg_roleid=%d,fg_chatid=%d,kick_roleid=%d,step=%d",fg_roleid,fg_chatid,kick_roleid,step);
    FIND_CHAT {
        _loading_chats.insert(fg_chatid);
        LoadChat_KickMember load(this,fg_roleid,kick_roleid);
        send2db();//FG_DBLoadChat
        return;
    }
    ACTIVE_CHAT();
    if(it2->second.owner != fg_roleid) return;
    FIND_MEMBER {
        LoadMember_KickMember load(this,fg_roleid,kick_roleid);
        send2db();//FG_DBLoadMember
        return;
    }
    //ACTIVE_MEMBER();//BroadcastNotice will do it

    role_iter it6 = _roles.find(kick_roleid);
    if(it6 == _roles.end())
    {
        if(step < 35)
        {
            LoadRole_KickMember load(this,fg_roleid,fg_chatid);
        }
        return;
    }
    if(step < 35) it6->second.update_active_time();
    if(it6->second.get_pos(fg_chatid) < 0) return;

    --it2->second.member_count;
    it3->second.members.erase(kick_roleid);
    it6->second.rm_chat(fg_chatid);
    save_chat(fg_chatid);
    save_member(fg_chatid);
    save_role(kick_roleid);
    LOG_TRACE("FG_Server::KickMember:fg_roleid=%d,fg_chatid=%d,kick_roleid=%d",fg_roleid,fg_chatid,kick_roleid);

    notice_msg(fg_chatid, FG_NOTICE_KICK_MEMBER, kick_roleid);
    point_msg(it6->second.info.zoneid, it6->second.info.roleid, FG_POINT_BE_KIEKED, it2->second.chat_name);
}

void FG_Server::DisbandChat(int fg_roleid, int fg_chatid, int step)
{
    debuglog("DisbandChat:fg_roleid=%d,fg_chatid=%d,step=%d",fg_roleid,fg_chatid,step);
    FIND_CHAT {
        _loading_chats.insert(fg_chatid);
        LoadChat_DisbandChat load(this,fg_roleid);
        send2db();//FG_DBLoadChat
        return;
    }
    ACTIVE_CHAT();
    if(it2->second.owner != fg_roleid) return;
    if(it2->second.is_delete) return;
    FIND_MEMBER {
        LoadMember_DisbandChat load(this,fg_roleid);
        send2db();//FG_DBLoadMember
        return;
    }
    //ACTIVE_MEMBER();//BroadcastNotice will do it

    it2->second.is_delete = true;
    save_chat(fg_chatid);
    if(0)
    {
        FMember &member = it3->second.members;
        for(FMember::iterator it6 = member.begin(); it6 != member.end(); ++it6)
        {
            role_iter it7 = _roles.find(it6->first);
            if(it7 != _roles.end())
            {
                //不必立即保存,下次获取list时再更新即可
                //不过可能会造成在线玩家以后上线再提示一次
                it7->second.rm_chat(fg_chatid);
            }
        }
    }
    notice_msg(fg_chatid, FG_NOTICE_DISBAND_CHAT);
    LOG_TRACE("FG_Server::DisbandChat:fg_roleid=%d,fg_chatid",fg_roleid,fg_chatid);
}

void FG_Server::LeaveChat(int fg_roleid, int fg_chatid, int step)
{
    debuglog("LeaveChat:fg_roleid=%d,fg_chatid=%d,step=%d",fg_roleid,fg_chatid,step);
    FIND_ROLE {
        LoadRole_LeaveChat load(this,fg_chatid);
        send2db();//FG_DBLoadRole
        return;
    }
    ACTIVE_ROLE();
    if(step <= 10 && it1->second.get_pos(fg_chatid) < 0) return;
    FIND_CHAT {
        _loading_chats.insert(fg_chatid);
        LoadChat_LeaveChat load(this,fg_roleid);
        send2db();//FG_DBLoadChat
        return;
    }
    ACTIVE_CHAT();
    if(it2->second.owner == fg_roleid) return;
    FIND_MEMBER {
        LoadMember_LeaveChat load(this,fg_roleid);
        send2db();//FG_DBLoadMember
        return;
    }
    //ACTIVE_MEMBER();//BroadcastNotice will do it

    it1->second.rm_chat(fg_chatid);
    --it2->second.member_count;
    it3->second.members.erase(fg_roleid);
    save_role(fg_roleid);
    save_chat(fg_chatid);
    save_member(fg_chatid);
    LOG_TRACE("FG_Server::LeaveChat:fg_roleid=%d,fg_chatid=%d",fg_roleid,fg_chatid);

    TellOnwerOneLeave(it2->second.owner, it2->second.chat_name, it1->second.info.name);
    notice_msg(fg_chatid, FG_NOTICE_LEAVE_CHAT, fg_roleid);
}

void FG_Server::TellOnwerOneLeave(int fg_roleid, Octets &chat_name, Octets &leave_name, int step)
{
    debuglog("TellOnwerOneLeave:fg_roleid=%d,step=%d",fg_roleid,step);
    FIND_ROLE {
        LoadRole_TellOnwerOneLeave load(this,chat_name,leave_name);
        send2db();//FG_DBLoadRole
        return;
    }
    ACTIVE_ROLE();

    point_msg(it1->second.info.zoneid, it1->second.info.roleid, FG_POINT_ONE_LEAVE, chat_name, leave_name);
}

void FG_Server::SearchById(int zoneid, int roleid, int fg_chatid, int step)
{
    debuglog("SearchById:zoneid=%d,roleid=%d,fg_chatid=%d,step=%d",zoneid,roleid,fg_chatid,step);
    FIND_CHAT {
        _loading_chats.insert(fg_chatid);
        LoadChat_Search load(this,zoneid,roleid);
        send2db();//FG_DBLoadChat
        return;
    }
    ACTIVE_CHAT();
    if(step <=20 && !it2->second.can_search || it2->second.confirm&FG_CONFIRM_REFUSE_ALL
            || _names.find(std::make_pair(it2->second.chat_name,it2->first)) == _names.end())
    {
        err_msg(zoneid, roleid, FG_ERR_CANNOT_FIND_CHAT);
        return;
    }

    role_iter it1 = _roles.find(it2->second.owner);
    if(it1 == _roles.end())
    {
        if(step < 25)
        {
            LoadRole_Search load(this,zoneid,roleid,fg_chatid);
            send2db();//FG_DBLoadRole
        }
        return;
    }
    if(step < 25) it1->second.update_active_time();

    FG_RSearchResult re;
    roleid;
    fg_chatid;
    it2->second.chat_name;
    it2->second.intro;
    it2->second.member_count;
    it1->second.info.zoneid;
    it1->second.info.name;
    send2client(zoneid, re);
}

void FG_Server::SearchByName(int zoneid, int roleid, Octets &chat_name)
{
    debuglog("SearchByName:zoneid=%d,roleid=%d",zoneid,roleid);
    std::set<std::pair<Octets,int> >::iterator left = _names.upper_bound(std::make_pair(chat_name,0));
    std::set<std::pair<Octets,int> >::iterator right = _names.upper_bound(std::make_pair(chat_name,1<<30));
    if(left == right)
    {
        err_msg(zoneid, roleid, FG_ERR_CANNOT_FIND_CHAT);
        return;
    }

    FG_RSearchResults re;
    for(std::set<std::pair<Octets,int> >::iterator it=left; it!=right; ++it)
    {
        chat_iter it2 = _chats.find(it->second);
        if(it2 == _chats.end()) continue;
        if(!it2->second.can_search) continue;
        if(it2->second.confirm & FG_CONFIRM_REFUSE_ALL) continue;
        if(it2->second.chat_name != chat_name) continue;

        FSearchResult element;
        element.fg_chatid = it2->first;
        element.intro = it2->second.intro;
        element.member_count = it2->second.member_count;
        element.owner_id = it2->second.owner;
        re.result.push_back(element);
    }
    roleid;
    chat_name;
    send2client(zoneid, re);
}

void FG_Server::Apply(int fg_roleid, int fg_chatid, ChatRoleInfo &info, int step)
{
    debuglog("Apply:fg_roleid=%d,fg_chatid=%d,step=%d",fg_roleid,fg_chatid,step);
    if(_apply_counter > FG_MAX_APPLY_COUNT)
    {
        err_msg(info.zoneid, info.roleid, FG_ERR_TOO_MANY_APPLYS);
        return;
    }
    if(fg_roleid == 0)
    {
        fg_roleid = alloc_roleid();
        _roles.insert(std::make_pair(fg_roleid, FRole(info)));
        save_id();
        save_role(fg_roleid);

        FG_RAllocRoleid re;
        info.roleid;
        fg_roleid;
        send2client(info.zoneid, re);
    }
    FIND_ROLE {
        LoadRole_Apply load(this,fg_chatid,info);
        send2db();//FG_DBLoadRole
        return;
    }
    ACTIVE_ROLE();
    if(step <= 10 && !it1->second.can_join() || it1->second.get_pos(fg_chatid) >= 0) return;
    FIND_CHAT {
        _loading_chats.insert(fg_chatid);
        LoadChat_Apply load(this,fg_roleid,info);
        send2db();//FG_DBLoadChat
        return;
    }
    ACTIVE_CHAT();
    if(!it2->second.can_add())
    {
        err_msg(info.zoneid, info.roleid, FG_ERR_CHAT_FULL1);
        return;
    }
    if(it2->second.confirm & FG_CONFIRM_REFUSE_ALL)
    {
        point_msg(info.zoneid, info.roleid, FG_POINT_BE_REFUSED, it2->second.chat_name);
        return;
    }
    std::vector<std::pair<int,ChatRoleInfo> > &apply_list = _applys[fg_chatid];
    if(apply_list.size() >= FG_MAX_APPLIANTS_PER_CHAT)
    {
        err_msg(info.zoneid, info.roleid, FG_ERR_FULL_APPLY);
        return;
    }
    for(int i=apply_list.size()-1; i>=0; --i)
    {
        //不用fg_roleid是为了防止fg_roleid为0的玩家快速申请多次
        if(info.zoneid == apply_list[i].second.zoneid && info.roleid == apply_list[i].second.roleid) return;//已申请
    }
    apply_list.push_back(std::make_pair(fg_roleid,info));
    ++_apply_counter;
    if(it2->second.confirm & FG_CONFIRM_AGREE_OPEN && it2->second.confirm & 0x1F)
    {
        AutoConfirm(it2->second.owner, fg_chatid, info.roleid, it2->second.confirm);
    }
}

void FG_Server::AutoConfirm(int fg_roleid, int fg_chatid, int app_oroleid, char confirm, int step)
{
    debuglog("AutoConfirm:fg_roleid=%d,fg_chatid=%d,app_oroleid=%d,confirm=%d,step=%d",fg_roleid,fg_chatid,app_oroleid,(int)confirm,step);
    FIND_ROLE {
        LoadRole_AutoConfirm load(this,fg_chatid,app_oroleid,confirm);
        send2db();//FG_DBLoadRole
        return;
    }
    ACTIVE_ROLE();

    FG_RAutoConfirm auto_confirm;
    it1->second.info.roleid;
    fg_chatid;
    app_oroleid;
    confirm;
    send2client(it1->second.info.zoneid, auto_confirm);
}

void FG_Server::GetApplicants(int fg_roleid, int fg_chatid, int zoneid, int roleid, int step)
{
    debuglog("GetApplicants:fg_roleid=%d,fg_chatid=%d,zoneid=%d,roleid=%d,step=%d",fg_roleid,fg_chatid,zoneid,roleid,step);
    FIND_CHAT {
        _loading_chats.insert(fg_chatid);
        LoadChat_GetApplicants load(this,fg_roleid,zoneid,roleid);
        send2db();//FG_DBLoadChat
        return;
    }
    ACTIVE_CHAT();
    if(it2->second.owner != fg_roleid) return;

    std::map<int,std::vector<std::pair<int,ChatRoleInfo> > >::iterator it = _applys.find(fg_chatid);
    if(it == _applys.end())
    {
        err_msg(zoneid, roleid, FG_ERR_EMPTY_APPLY);
        return;
    }

    FG_RApplicants re;
    roleid;
    fg_chatid;
    re.applicants = it->second;
    send2client(zoneid, re);
}

void FG_Server::AgreeApply(int fg_roleid, int fg_chatid, int zoneid, int roleid, int applicant, bool agree, int step)
{
    debuglog("AgreeApply:fg_roleid=%d,fg_chatid=%d,zoneid=%d,roleid=%d,applicant=%d,agree=%d,step=%d",fg_roleid,fg_chatid,zoneid,roleid,applicant,(int)agree,step);
    FIND_CHAT {
        _loading_chats.insert(fg_chatid);
        LoadChat_AgreeApply load(this,fg_roleid,zoneid,roleid,applicant,agree);
        send2db();//FG_DBLoadChat
        return;
    }
    ACTIVE_CHAT();
    if(it2->second.owner != fg_roleid) return;

    std::map<int,std::vector<std::pair<int,ChatRoleInfo> > >::iterator it6 = _applys.find(fg_chatid);
    if(it6 == _applys.end()) return;
    std::vector<std::pair<int,ChatRoleInfo> >::iterator it7 = it6->second.begin();
    for(; it7 != it6->second.end(); ++it7)
    {
        if(it7->first == applicant)
        {
            if(agree)
            {
                JoinIntoChat(applicant, fg_chatid, zoneid, roleid);
            }
            else
            {
                point_msg(it7->second.zoneid, it7->second.roleid, FG_POINT_BE_REFUSED, it2->second.chat_name);
            }
            it6->second.erase(it7);
            --_apply_counter;
            break;
        }
    }
}

void FG_Server::JoinIntoChat(int fg_roleid, int fg_chatid, int owner_zoneid, int owner_roleid, int step)
{
    debuglog("JoinIntoChat:fg_roleid=%d,fg_chatid=%d,owner_zoneid=%d,owner_roleid=%d,step=%d",fg_roleid,fg_chatid,owner_zoneid,owner_roleid,step);
    FIND_ROLE {
        LoadRole_JoinIntoChat load(this,fg_chatid,owner_zoneid,owner_roleid);
        send2db();//FG_DBLoadRole
        return;
    }
    ACTIVE_ROLE();
    FIND_CHAT {
        _loading_chats.insert(fg_chatid);
        LoadChat_JoinIntoChat load(this,fg_roleid,owner_zoneid,owner_roleid);
        send2db();//FG_DBLoadChat
        return;
    }
    //ACTIVE_CHAT();//已在AgreeApply中更新过了

    if(step <= 20)
    {
        if(it1->second.get_pos(fg_chatid) >= 0)
        {
            err_msg(owner_zoneid, owner_roleid, FG_ERR_HAS_IN_CHAT);
            point_msg(it1->second.info.zoneid, it1->second.info.roleid, FG_POINT_BE_AGREED_ERR3, it2->second.chat_name);
            return;
        }
        if(!it1->second.can_join())
        {
            err_msg(owner_zoneid, owner_roleid, FG_ERR_JOIN_TOO_MANY);
            point_msg(it1->second.info.zoneid, it1->second.info.roleid, FG_POINT_BE_AGREED_ERR1, it2->second.chat_name);
            return;
        }
        if(!it2->second.can_add())
        {
            err_msg(owner_zoneid, owner_zoneid, FG_ERR_CHAT_FULL2);
            point_msg(it1->second.info.zoneid, it1->second.info.roleid, FG_POINT_BE_AGREED_ERR2, it2->second.chat_name);
            return;
        }
    }

    FIND_MEMBER {
        LoadMember_JoinIntoChat load(this,fg_roleid,owner_zoneid,owner_roleid);
        send2db();//FG_DBLoadMember
        return;
    }
    ACTIVE_MEMBER();

    it1->second.join_chat(fg_chatid);
    ++it2->second.member_count;
    it3->second.members.insert(std::make_pair(fg_roleid,FG_ChatRole(it1->second.info)));
    save_role(fg_roleid);
    save_chat(fg_chatid);
    save_member(fg_chatid);
    LOG_TRACE("FG_Server::JoinIntoChat:fg_roleid=%d,fg_chatid=%d,owner_zoneid=%d,owner_roleid=%d",fg_roleid,fg_chatid,owner_roleid,owner_roleid);

    point_msg(it1->second.info.zoneid, it1->second.info.roleid, FG_POINT_BE_AGREED_SUCCEED, it2->second.chat_name);

    FG_RJoinChat join_chat;
    it1->second.info.roleid;
    fg_chatid;
    it2->second.chat_name;
    it2->second.intro;
    send2client(it1->second.info.zoneid, join_chat);

    FG_RNoticeJoin notice_join;
    fg_chatid;
    fg_roleid;
    it1->second.info;
    FMember &members = it3->second.members;
    for(FMember::iterator it=members.begin(); it!=members.end(); ++it)
    {
        if(it->second.info.roleid == it1->second.info.roleid) continue;
        if(!it->second.online) continue;
        notice_join.roleid = it->second.info.roleid;
        send2client(it->second.info.zoneid, notice_join);
    }
}

void FG_Server::BroadcastNotice(int fg_chatid, FG_RNotice &notice, int step)
{
    debuglog("BroadcastNotice:fg_chatid=%d,type=%d,step=%d",fg_chatid,notice.type,step);
    FIND_MEMBER {
        LoadMember_BroadcastNotice load(this,notice);
        send2db();//FG_DBLoadMember
        return;
    }
    ACTIVE_MEMBER();

    notice.fg_chatid = fg_chatid;
    FMember &members = it3->second.members;
    for(FMember::iterator it=members.begin(); it!=members.end(); ++it)
    {
        if(!it->second.online) continue;
        notice.roleid = it->second.info.roleid;
        send2client(it->second.info.zoneid, notice);
    }
}

void FG_Server::AddOwnLimit(int fg_roleid, int add, int step)
{
    debuglog("AddOwnLimit:fg_roleid=%d,add=%d,step=%d",fg_roleid,add,step);
    FIND_ROLE {
        LoadRole_AddOwnLimit load(this,add);
        send2db();//FG_DBLoadRole
        return;
    }
    ACTIVE_ROLE();
    if(it1->second.get_own_limit() + add > FG_MAX_OWN_LIMIT_PER_ROLE) return;

    it1->second.own_addon += add;
    save_role(fg_roleid);
    Log::log(LOG_INFO,"FG_Server::AddOwnLimit:fg_roleid=%d,add=%d",fg_roleid,add);

    FG_RChatLimit limit;
    it1->second.info.roleid;
    it1->second.get_own_limit();
    it1->second.get_join_limit();
    send2client(it1->second.info.zoneid, limit);
}

void FG_Server::AddJoinLimit(int fg_roleid, int add, int step)
{
    debuglog("AddJoinLimit:fg_roleid=%d,add=%d,step=%d",fg_roleid,add,step);
    FIND_ROLE {
        LoadRole_AddJoinLimit load(this,add);
        send2db();//FG_DBLoadRole
        return;
    }
    ACTIVE_ROLE();
    if(it1->second.get_join_limit() + add > FG_MAX_JOIN_LIMIT_PER_ROLE) return;

    it1->second.own_addon += add;
    save_role(fg_roleid);
    Log::log(LOG_INFO,"FG_Server::AddJoinLimit:fg_roleid=%d,add=%d",fg_roleid,add);

    FG_RChatLimit limit;
    it1->second.info.roleid;
    it1->second.get_own_limit();
    it1->second.get_join_limit();
    send2client(it1->second.info.zoneid, limit);
}

void FG_Server::AddChatCapacity(int fg_roleid, int fg_chatid, int add_capacity, int zoneid, int roleid, int step)
{
    debuglog("AddChatCapacity:fg_roleid=%d,fg_chatid=%d,add_capacity=%d,zoneid=%d,roleid=%d,step=%d",fg_roleid,fg_chatid,add_capacity,zoneid,roleid,step);
    FIND_CHAT {
        _loading_chats.insert(fg_chatid);
        LoadChat_AddChatCapacity load(this,fg_roleid,add_capacity,zoneid,roleid);
        send2db();//FG_DBLoadChat
        return;
    }
    ACTIVE_CHAT();
    if(it2->second.owner != fg_roleid) return;

    if(it2->second.get_capacity() + add_capacity > FG_MAX_CAPACITY_PER_CHAT) return;
    it2->second.capacity_addon += add_capacity;
    save_chat(fg_chatid);
    Log::log(LOG_INFO,"FG_Server::AddChatCapacity:fg_roleid=%d,zoneid=%d,roleid=%d,fg_chatid=%d,add=%d",fg_roleid,zoneid,roleid,fg_chatid,add_capacity);

    FG_RChatCapacity re;
    roleid;
    fg_chatid;
    it2->second.get_capacity();
    send2client(zoneid, re);
}

void FG_Server::SetRoleOffline(int fg_roleid, int fg_chatid)
{
    debuglog("SetRoleOffline:fg_roleid=%d,fg_chatid=%d",fg_roleid,fg_chatid);
    member_iter it = _members.find(fg_chatid);
    if(it != _members.end())
        it->second.update_member_online(fg_roleid, false);
}

void FG_Server::Invite(int fg_roleid, int fg_chatid, int zoneid, int roleid, int invitee_oroleid, int step)
{
    debuglog("Invite:fg_roleid=%d,fg_chatid=%d,zoneid=%d,roleid=%d,invitee_oroleid=%d,step=%d",fg_roleid,fg_chatid,zoneid,roleid,invitee_oroleid,step);
    FIND_CHAT {
        _loading_chats.insert(fg_chatid);
        LoadRole_Invite load(this,fg_chatid,zoneid,invitee_oroleid);
        send2db();//FG_DBLoadChat
        return;
    }
    ACTIVE_CHAT();
    if(it2->second.owner != fg_roleid) return;
    if(!it2->second.can_add()) return;

    FG_InviteRe re;
    fg_chatid;
    it2->second.chat_name;
    roleid;
    invitee_oroleid;
    send2client(zoneid, re);
}

void FG_Server::AgreeInvite(int fg_roleid, int fg_chatid, ChatRoleInfo &info, int owner_oroleid, int step)
{
    debuglog("AgreeInvite:fg_roleid=%d,fg_chatid=%d,owner_oroleid=%d,step=%d",fg_roleid,fg_chatid,owner_oroleid,step);
    if(fg_roleid == 0)
    {
        fg_roleid = alloc_roleid();
        _roles.insert(std::make_pair(fg_roleid, FRole(info)));
        save_id();
        save_role(fg_roleid);

        FG_RAllocRoleid re;
        info.roleid;
        fg_roleid;
        send2client(info.zoneid, re);
    }
    FIND_ROLE {
        LoadRole_AgreeInvite load(this,fg_chatid,info,owner_oroleid);
        send2db();//FG_DBLoadRole
        return;
    }
    ACTIVE_ROLE();
    FIND_CHAT {
        _loading_chats.insert(fg_chatid);
        LoadChat_AgreeInvite load(this,fg_roleid,info,owner_oroleid);
        send2db();//FG_DBLoadChat
        return;
    }
    ACTIVE_CHAT();

    if(step <= 20)
    {
        if(it1->second.get_pos(fg_chatid) >= 0)
        {
            FG_AgreeInviteRe re;
            AGREE_INVITE_RE_STATE_HAS_IN;
            it2->second.chat_name;
            owner_oroleid;
            info.roleid;
            info.name;
            send2client(info.zoneid, re);
            return;
        }
        if(!it1->second.can_join())
        {
            FG_AgreeInviteRe re;
            AGREE_INVITE_RE_STATE_JOIN_FULL;
            it2->second.chat_name;
            owner_oroleid;
            info.roleid;
            info.name;
            send2client(info.zoneid, re);
            return;
        }
        if(!it2->second.can_add())
        {
            FG_AgreeInviteRe re;
            AGREE_INVITE_RE_STATE_CHAT_FULL;
            it2->second.chat_name;
            owner_oroleid;
            info.roleid;
            info.name;
            send2client(info.zoneid, re);
            return;
        }
    }

    FIND_MEMBER {
        LoadMember_AgreeToJoin load(this,fg_roleid,info,owner_oroleid);
        send2db();//FG_DBLoadMember
        return;
    }
    ACTIVE_MEMBER();

    it1->second.join_chat(fg_chatid);
    ++it2->second.member_count;
    it3->second.members.insert(std::make_pair(fg_roleid,FG_ChatRole(it1->second.info)));
    save_role(fg_roleid);
    save_chat(fg_chatid);
    save_member(fg_chatid);
    LOG_TRACE("FG_Server::AgreeInvite:fg_roleid=%d,fg_chatid=%d,zoneid=%d,roleid=%d,owner_roleid=%d",fg_roleid,fg_chatid,info.zoneid,info.roleid,owner_oroleid);

    FG_AgreeInviteRe re;
    AGREE_INVITE_RE_STATE_SUCCEED;
    it2->second.chat_name;
    owner_oroleid;
    info.roleid;
    info.name;
    send2client(info.zoneid, re);

    FG_RJoinChat join_chat;
    info.roleid;
    fg_chatid;
    it2->second.chat_name;
    it2->second.intro;
    send2client(info.zoneid, join_chat);
     
    FG_RNoticeJoin notice_join;
    fg_chatid;
    fg_roleid;
    it1->second.info;
    FMember &members = it3->second.members;
    for(FMember::iterator it=members.begin(); it!=members.end(); ++it)
    {
        if(it->second.info.roleid == info.roleid) continue;
        if(!it->second.online) continue;
        notice_join.roleid = it->second.info.roleid;
        send2client(it->second.info.zoneid, notice_join);
    }
}

void FG_Server::GetRoleHistory(int fg_roleid, int step)
{
    debuglog("GetRoleHistory:fg_roleid=%d,step=%d",fg_roleid,step);
    FIND_ROLE {
        LoadRole_GetHistory load(this);
        send2db();//FG_DBLoadRole
        return;
    }
    ACTIVE_ROLE();

    FG_RRoleHistory re;
    it1->second.info.roleid;
    it1->second.history;
    send2client(it1->second.info.zoneid, re);
}

void FG_Server::Update()
{
    LOG_TRACE("statistics:roleid=%d,chatid=%d,roles=%d,chats=%d,members=%d,names=%d,applys=%d",_next_roleid,_next_chatid,_roles.size(),_chats.size(),_members.size(),_names.size(),_apply_counter);

    static int last = 0;
    int now = Timer::GetTime();
    if((last^now)>>FG_NAMES_CLEAR_INTERVAL&1) _names.clear();
    if((last^now)>>2&1) LOG_TRACE("%d",now);
    last = now;

    _role_eraser.Update(_roles, now);
    _chat_eraser.Update(_roles, now);
    _member_eraser.Update(_roles, now);
}

#undef FIND_ROLE
#undef FIND_CHAT
#undef FIND_MEMBER
#undef ACTIVE_ROLE
#undef ACTIVE_CHAT
#undef ACTIVE_MEMBER
