struct ChatRoleInfo
{
    int zoneid;
    int roleid;
    Octets name;
    short level;
    char cultivation;
    char occupation;
};
struct ChatRoleHistory
{
    int time;
    int operation;
    Octets object;//role_name or chat_name
    ChatRoleHistory(int,int,const Octets&){}
};
struct FRole
{
    ChatRoleInfo info;
    short own_count;
    short own_addon;
    short join_addon;
    std::vector<int> chats;
    std::vector<char> ignore;
    std::vector<char> dirty;
    std::vector<ChatRoleHistory> history;
    FRole(ChatRoleInfo &){}
};
struct FChat
{
    Octets chat_name;
    Octets intro;
    int owner;
    short capacity_addon;
    short member_count;
    char confirm;
    bool can_search;
    bool is_delete;
    std::vector<ChatRoleHistory> history;
    FChat(const Octets&,int){}
};
struct FChatRole
{
    ChatRoleInfo info;
    bool ignore_msg;
    FChatRole(const ChatRoleInfo &,bool=false){}
    FChatRole(){}
    FChatRole(const FChatRole &){}
};

struct FChatElement
{
    bool is_owner;
    bool ignore_msg;
    bool is_delete;
    Octets chat_name;
    char confirm;
    bool can_search;
    short capacity_addon;
    FChatElement(bool is_owner_=false,bool ignore_msg_=false){}
};

struct FSearchResult
{
    int fg_chatid;
    Octets intro;
    short member_count;
    int owner_id;
};
///////////////////////////////////////////////
struct Protocol{};

struct FG_RAllocRoleid:public Protocol
{
    int roleid;
    int fg_roleid;
};

struct FG_RErrorMsg:public Protocol
{
    int roleid;
    int err_type;
    FG_RErrorMsg(int,int){}
};

struct FG_RNotice:public Protocol
{
    int roleid;
    int type;
    int fg_chatid;
    int param;
    FG_RNotice(int type_,int chatid,int param_){}
};

struct FG_RNoticeJoin:public Protocol
{
    int roleid;
    int fg_chatid;
    int fg_roleid;
    ChatRoleInfo info;
};

struct FG_RPoint:public Protocol
{
    int roleid;
    int type;
    Octets chat_name;
    Octets role_name;
    FG_RPoint(int,int,const Octets&,const Octets&){}
};

struct FG_RChatList:public Protocol
{
    int roleid;
    int fg_roleid;
    short own_limit;
    short join_limit;
    std::map<int,FChatElement> chatlist;
};

struct FG_RChatLimit:public Protocol
{
    int roleid;
    short own_limit;
    short join_limit;
};

struct FG_RChatIntro:public Protocol
{
    int roleid;
    int fg_chatid;
    Octets intro;
};

struct FG_RChatMembers:public Protocol
{
    int roleid;
    int fg_chatid;
    std::map<int,ChatRoleInfo> members;
};

struct FG_RSearchResult:public Protocol
{
    int roleid;
    int fg_chatid;
    Octets chat_name;
    Octets intro;
    short member_count;
    int owner_id;
    int owner_zoneid;
    Octets owner_name;
};

struct FG_RSearchResults:public Protocol
{
    int roleid;
    Octets chat_name;
    std::vector<FSearchResult> result;
};

struct FG_RApplicants:public Protocol
{
    int roleid;
    int fg_chatid;
    std::vector<std::pair<int,ChatRoleInfo> > applicants;
};

struct FG_RChatCapacity:public Protocol
{
    int roleid;
    int fg_chatid;
    short capacity;
};

struct FG_RRoleHistory:public Protocol
{
    int roleid;
    std::vector<ChatRoleHistory> history;
};

struct FG_RJoinChat:public Protocol
{
    int roleid;
    int fg_chatid;
    Octets chat_name;
    Octets intro;
};

struct FG_RTalk:public Protocol
{
    int roleid;
    int fg_chatid;
    int talker;
    char vip;
    Octets msg;
};

///////////////////////////////////////////////
struct FG_RAutoConfirm:public Protocol
{
    int roleid;
    int fg_chatid;
    int app_oroleid;//申请者的原服roleid
    char confirm;
};

//到link后会换协议给客户端
struct FG_InviteRe:public Protocol
{
    int fg_chatid;
    Octets chat_name;
    int owner_oroleid;//群主的原服roleid
    int invitee_oroleid;//被邀请者的原服roleid
    Octets owner_name;
    Octets invitee_name;
};

struct FG_AgreeInviteRe:public Protocol
{
    //给群主:1:被邀者拒绝 2:超时
    //给双方:3:被邀者同意且成功加入 4:被邀者同意但群已满 5:被邀者同意但加群达上限 6:被邀者同意但已在群中
    int state;
    Octets chat_name;
    int owner_oroleid;
    int invitee_oroleid;
    Octets invitee_name;
};
