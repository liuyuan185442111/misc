#ifndef L_GMATRIX_H_
#define L_GMATRIX_H_

#include "msg.h"

namespace gmatrix
{
	void HandleMessage(const MSG& msg);
}

#endif // L_GMATRIX_H_
