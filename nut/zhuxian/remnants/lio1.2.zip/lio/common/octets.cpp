#include "octets.h"
namespace GNET
{
	Octets::Rep Octets::Rep::null = { 0, 0, 1 };
}

