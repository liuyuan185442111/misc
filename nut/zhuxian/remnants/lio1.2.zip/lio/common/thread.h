#ifndef __THREAD_H
#define __THREAD_H

#include <map>

namespace GNET
{
namespace Thread
{
	class Runnable
	{
	protected:
		int m_priority;
	public:
		Runnable(int priority = 1) : m_priority(priority) { }
		virtual ~Runnable() { }
		virtual void Run() = 0;
		void SetPriority(int priority) { m_priority = priority; }
		int GetPriority() const { return m_priority; }
	};

	class Policy
	{
	protected:
		size_t m_max_task_size;
		bool   m_will_quit;
	public:
		Policy(int max_task_size = 2048) : m_max_task_size(max_task_size), m_will_quit(false) { }
		virtual ~Policy() { }
		virtual Policy *Clone() const { return new Policy(*this); }

		void SetMaxTaskSize(size_t max_task_size)
		{
			m_max_task_size = max_task_size;
		}
		void SetQuit() { m_will_quit = true; }
		bool GetQuit() { return m_will_quit; }

		virtual bool CanAddTask(Thread::Runnable *pTask, size_t tasksize, bool bForced)
		{
			if(m_will_quit)
			{
				delete pTask;
				return false;
			}
			if(tasksize < m_max_task_size || bForced )
				return true;
			return false;
		}
	};

	void SetupDaemon();
	void SetPolicy(const Policy &policy);
	void AddTask(Runnable *task, bool bForced = false);
	void Start(size_t pool_size = 3);
	size_t TaskSize();
	size_t ThreadSize();
}
}

#endif//__THREAD_H
