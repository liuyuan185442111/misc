#include <iostream>
#include <algorithm>
using namespace std;
#include "httpclient.h"
using namespace GNET;
#include "gmatrix.h"

MsgQueueList gmatrix::msglist;

class Send : public IntervalTimer::Observer
{
    virtual bool Update()
    {
        //HttpSingletonClient::GetInstance()->SendMessage("10010:796504");
        return true;
    }
};

int main(int argc, char **argv)
{
#if defined(__x86_64__)
	puts("hello __x86_64__");
#elif defined(__i386__)
	puts("hello __i386__");
#endif

    vector<string> ips;
    get_local_ip(ips);
    if(find(ips.begin(), ips.end(), "10.0.2.15") == ips.end())
    {
        puts("not allowed ip");
        //return 0;
    }

    //主线程阻塞SIGALRM,否则SIGALRM可能会唤醒sleep,导致IntervalTimer收不到SIGALRM
    sigset_t sigs;
    sigemptyset(&sigs);
    sigaddset(&sigs, SIGALRM);
    sigprocmask(SIG_BLOCK, &sigs, NULL);

    IntervalTimer::StartTimer(500000);//500ms per tick
    IntervalTimer::Attach(&gmatrix::msglist, 1);

    HttpSingletonClient::GetInstance()->Prepare("http://common.sms.wanmei.com/web/api/message/send");

    Send s;
    IntervalTimer::Attach(&s, 1);

	Thread::Pool::AddTask(PollController::Task::GetInstance());
	Thread::Pool::Run();
    while(true)
    {
        static int mask = 100000;
        char buf[10];
        sprintf(buf, "%d", ++mask);
        HttpSingletonClient::GetInstance()->SendMessage(string("10086:")+buf);
        sleep(1);

        static int type = 0;
        gmatrix::msglist.AddMsg(MSG(++type));
        sleep(1);
    }
	return 0;
}
