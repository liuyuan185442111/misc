#ifndef L_MESSAGE__H__
#define L_MESSAGE__H__

#include <stdlib.h>
#include <string.h>
#include <vector>
#include "msg.h"
#include "itimer.h"
#include "thread.h"

class MsgQueue : public GNET::Thread::Runnable
{
    typedef std::vector<MSG> MSGQUEUE;
    MSGQUEUE _queue;

public:
    size_t Size()
    {
        return _queue.size();
    }
    void Swap(MsgQueue &q)
    {
        _queue.swap(q._queue);
    }

    void AddMsg(const MSG & msg)
    {
        _queue.push_back(msg);
    }

    bool IsEmpty()
    {
        return _queue.empty();
    }

    void Send();

private:
    friend class MsgQueueList;
    void AddTask()
    {
        GNET::Thread::Pool::AddTask(this);
    }
    virtual void Run()
    {
        Send();
        delete this;
    }
};

class MsgQueueList : public GNET::IntervalTimer::Observer
{
    enum
    {
        MSG_SIZE = 256,
        LIST_SIZE = 256
    };
    MsgQueue * 		_list[LIST_SIZE];//for延时消息
    MsgQueue 		_cur_queue;
    int 	   		_offset;
    GNET::Thread::Mutex 	_lock_list;//for _list and _offset
    GNET::Thread::Mutex 	_lock_cur;//for _cur_queue

    MsgQueue * GetQueue(int target)
    {
        if(_list[target] == NULL)
            _list[target] = new MsgQueue();
        return _list[target];
    }

    inline void _SEND_CUR_QUEUE()
    {
        MsgQueue * pQueue = new MsgQueue;
        _cur_queue.Swap(*pQueue);
        pQueue->AddTask();
    }
public:
    MsgQueueList() : _offset(0)
    {
        for(int i=0; i<LIST_SIZE; ++i)
            _list[i] = NULL;
    }
    ~MsgQueueList()
    {
        for(int i=0; i<LIST_SIZE; ++i)
        {
            if(_list[i] == NULL) continue;
            delete _list[i];
        }
    }

    virtual bool Update()
    {
        _lock_cur.Lock();
        if(!_cur_queue.IsEmpty())
            _SEND_CUR_QUEUE();
        _lock_cur.UNLock();

        GNET::Thread::Mutex::Scoped keeper(_lock_list);
        if(_list[_offset])
        {
            _list[_offset]->AddTask();
            _list[_offset] = NULL;
        }
        _offset++;
        if(_offset >= LIST_SIZE) _offset = 0;
        return true;
    }
    void AddMsg(const MSG & msg)
    {
        GNET::Thread::Mutex::Scoped keeper(_lock_list);
        _cur_queue.AddMsg(msg);
        if(_cur_queue.Size() < MSG_SIZE) return;
        _lock_cur.Lock();
        _SEND_CUR_QUEUE();
        _lock_cur.UNLock();
    }

    void SendCurQueue()
    {
        _lock_cur.Lock();
        if(_cur_queue.IsEmpty()) return;
        MsgQueue queue;
        queue.Swap(_cur_queue);
        _lock_cur.UNLock();
        queue.Send();
    }

    //延迟latency个tick后发消息
    void AddMsg(const MSG & msg, size_t latency)
    {
        GNET::Thread::Mutex::Scoped keeper(_lock_list);
        int target = _offset + latency;
        if(target >= LIST_SIZE) target %= LIST_SIZE;
        GetQueue(target)->AddMsg(msg);
    }
};

#endif // L_MESSAGE__H__
