#include "httpclient.h"
#include <stdarg.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <net/if.h>

namespace GNET {
HttpSingletonClient HttpSingletonClient::instance;
void LOG_TRACE(const char *format, ...)
{
	va_list args;
	va_start(args, format);
	vfprintf(stdout,format,args);
	va_end(args);
	puts("");
}
bool get_local_ip(std::vector<std::string> &ips)
{
    int sockfd;
    if((sockfd = socket(AF_INET,SOCK_DGRAM,0)) < 0)
        return false;
    ips.clear();
    struct ifconf ifconf;
    char buf[512];
    ifconf.ifc_len = sizeof(buf);
    ifconf.ifc_buf = buf;
    ioctl(sockfd, SIOCGIFCONF, &ifconf); //获取所有接口信息

    //一个一个的获取IP地址
    struct ifreq *req = (struct ifreq*)ifconf.ifc_buf;
    for(int i = (ifconf.ifc_len/sizeof(struct ifreq)); i>0; --i)
    {
        if(req->ifr_flags == AF_INET) //for ipv4
		{
            //printf("name=[%s]\n", req->ifr_name);
            //printf("local_addr=[%s]\n", inet_ntoa(((struct sockaddr_in*)&(req->ifr_addr))->sin_addr));
			ips.push_back(inet_ntoa(((struct sockaddr_in*)&(req->ifr_addr))->sin_addr));
            ++req;
        }
    }
    return !ips.empty();
}
}
