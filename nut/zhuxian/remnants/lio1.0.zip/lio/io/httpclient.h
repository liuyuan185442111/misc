#ifndef __HTTPCLIENT_H
#define __HTTPCLIENT_H

#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <vector>
#include <string>
#include <map>
#include <sstream>
#include "marshal.h"
#include "pollio.h"

namespace GNET {

void LOG_TRACE(const char *format, ...);
bool get_local_ip(std::vector<std::string> &ips);

class HttpClientSession;
struct HttpClientManager
{
	virtual void OnOpen(int sid, HttpClientSession *) = 0;
	virtual void OnClose(int sid) { }
    virtual void OnFailed(int sid) { }
	virtual void Dispatch(int sid, OctetsStream &is) { is.clear(); }
};

class HttpClientIO;
class HttpClientSession
{
	friend class HttpClientIO;
	HttpClientManager *manager;
	PollIO *assoc_io;
	Thread::Mutex locker;
	bool sending;
	bool closing;
	Octets ibuffer;
	Octets obuffer;
	std::deque<Octets> os;
	OctetsStream is;
	int sid;
	int nextsid() { static int session_id = 0; return ++session_id; }
	HttpClientSession(const HttpClientSession &rhs) : manager(rhs.manager),assoc_io(rhs.assoc_io),
        locker("HttpClientSession",true),sending(rhs.sending),closing(rhs.closing),sid(rhs.sid)
	{
		ibuffer.reserve(rhs.ibuffer.capacity());
		obuffer.reserve(rhs.obuffer.capacity());
	}
public:
	HttpClientSession(HttpClientManager *m) : manager(m),assoc_io(NULL),locker("HttpClientSession",true),
		sending(false),closing(false),ibuffer(8192),obuffer(8192),sid(nextsid()) { }
	HttpClientSession *Clone() const { return new HttpClientSession(*this); }

	void OnOpen(PollIO *io)
	{
		assoc_io = io;
		manager->OnOpen(sid, this);
	}
	void OnClose()
	{
		manager->OnClose(sid);
		delete this;
	}
    void OnFailed()
    {
        manager->OnFailed(sid);
		delete this;
    }

	void SendReady()
	{
		if(sending) return;
		sending = true;
		assoc_io->PermitSend();
	}
	void SendFinish()
	{
		sending = false;
		assoc_io->ForbidSend();
	}
	void Close()
	{
		Thread::Mutex::Scoped l(locker);
		if(closing) return;
		closing = true;
		assoc_io->PermitSend();
	}

	Octets& GetOBuffer()
	{
		return obuffer;
	}
	Octets& GetIBuffer()
	{
		return ibuffer;
	}
	void Send(Octets &ps)
	{
		Thread::Mutex::Scoped l(locker);
		if(ps.size())
		{
			os.push_back(ps);
			SendReady();
		}
	}

	void BeforeSend()
	{
		for(;!os.empty() ; os.pop_front())
		{
			obuffer.insert(obuffer.end(), os.front().begin(), os.front().end());
		}
	}
	void AfterRecv()
	{
		is.insert(is.end(), ibuffer.begin(), ibuffer.end());
		ibuffer.clear();
		manager->Dispatch(sid, is);
		assoc_io->PermitRecv();
	}
};

class HttpClientIO : public PollIO
{
	HttpClientSession *session;
	void PollIn()
	{
		int recv_bytes;
		Octets& ibuf = session->GetIBuffer();
		do
		{
			if ((recv_bytes = read(fd, ibuf.end(), ibuf.capacity() - ibuf.size())) > 0)
			{
				LOG_TRACE("PollIn session %d receive %d bytes", session->sid,recv_bytes);
				ibuf.setsize(ibuf.size() + recv_bytes);//��ȷ����len
				if(ibuf.size() == ibuf.capacity())
					ForbidRecv();
				session->AfterRecv();
				return;
			}
		} while (recv_bytes == -1 && errno == EINTR);
		if(recv_bytes != -1 || errno != EAGAIN)
		{
			Thread::Mutex::Scoped l(session->locker);
			session->BeforeSend();
			session->GetOBuffer().clear();
			if(recv_bytes == 0) session->Close();//CLOSE_ONRECV = 0x10000, //�Զ˵���close�����ر�
			else session->Close();//CLOSE_ONRESET = 0x20000, //���ӱ��Զ�reset
		}
	}
	void PollOut()
	{
		int send_bytes;
		Thread::Mutex::Scoped l(session->locker);
		session->BeforeSend();
		Octets& obuf = session->GetOBuffer();
		do
		{
			if((send_bytes = write(fd, obuf.begin(), obuf.size())) > 0)
			{
				obuf.erase(obuf.begin(), (char*)obuf.begin() + send_bytes);
				LOG_TRACE("PollOut session %d send %d bytes", session->sid,send_bytes);
				if(obuf.size() == 0)
					session->SendFinish();
				return;
			}
		} while (send_bytes == -1 && errno == EINTR);
		if(send_bytes != -1 || errno != EAGAIN)
		{
			obuf.clear();
			session->Close();//CLOSE_ONSEND = 0x30000, //����ʱ��������,����洢��errno��
		}
	}
	void PollClose()
	{
		Thread::Mutex::Scoped l(session->locker);
		if(session->closing)
		{
			Close();
		}
	}
public:
	HttpClientIO(int fd, HttpClientSession *s) : PollIO(fd), session(s)
	{
		session->OnOpen(this);
	}
	~HttpClientIO()
	{
		session->OnClose();
	}
};

class HttpConnectIO : public PollIO
{
	HttpClientSession *session;
	struct sockaddr sa;

	void PollIn() { Close(); }
	void PollOut() { Close(); }
	HttpConnectIO(int x, const struct sockaddr &addr, const HttpClientSession &s) : PollIO(x), session(s.Clone()), sa(addr)
	{
		connect(fd, &sa, sizeof(sa));
	}
	~HttpConnectIO()
	{
		int optval = -1;
		socklen_t optlen = sizeof(optval);
		int optret = getsockopt(fd, SOL_SOCKET, SO_ERROR, &optval, &optlen);
		if(optret == 0 && optval == 0)
		{
			PollController::Register(new HttpClientIO(dup(fd), session), true, false);
		}
		else
		{
			int rv = connect(fd, &sa, sizeof(sa));
			if(rv == 0 || (rv == -1 && errno == EISCONN))
			{
				PollController::Register(new HttpClientIO(dup(fd), session), true, false);
			}
			else
			{
                session->OnFailed();
			}
		}
	}

public:
	static HttpConnectIO *Open(const HttpClientSession &session, const char *ip, int port = 80)
	{
		int s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
		if(s < 0) return NULL;

		struct sockaddr addr;
		memset(&addr, 0, sizeof(addr));
		struct sockaddr_in *pad = (struct sockaddr_in *)&addr;
		pad->sin_family = AF_INET;
		pad->sin_addr.s_addr = inet_addr(ip);
		pad->sin_port = htons(port);

		int optval = 1;
		setsockopt(s, SOL_SOCKET, SO_KEEPALIVE, &optval, sizeof(optval));
		optval = 1;
		setsockopt(s, IPPROTO_TCP, TCP_NODELAY, &optval, sizeof(optval));

		return (HttpConnectIO*)PollController::Register(new HttpConnectIO(s, addr, session), true, true);
	}
};

///////////////////////////////////////////////////////////////////////////////

class HttpSingletonClient : public HttpClientManager, public Thread::Runnable
{
	static HttpSingletonClient instance;

	std::string uri;
	std::string host;
	std::string ip;
	int connecting_link;
	bool prepared;
	bool has_run;

    Thread::Mutex pool_locker;
	std::map<int, HttpClientSession*> link_pool;
	std::deque<std::string> request_pool;

	virtual void OnOpen(int sid, HttpClientSession *session)
	{
		LOG_TRACE("session %d connected", sid);
        Thread::Mutex::Scoped l(pool_locker);
		--connecting_link;
		link_pool.insert(std::make_pair(sid, session));
		TrySend();
	}
	virtual void OnClose(int sid)
	{
		LOG_TRACE("session %d close", sid);
        Thread::Mutex::Scoped l(pool_locker);
		link_pool.erase(sid);
		TrySend();
	}
    virtual void OnFailed(int sid)
    {
		LOG_TRACE("session %d failed", sid);
        Thread::Mutex::Scoped l(pool_locker);
		--connecting_link;
		TrySend();
    }
	virtual void Dispatch(int sid, OctetsStream &is)
	{
	    size_t s = is.size();
        char *p = new char[s+1];
        p[s] = '\0';
        is.pop_byte(p, s);
        LOG_TRACE("session %d content is:\n%s", sid,p);
        delete[] p;
		is.clear();
        Thread::Mutex::Scoped l(pool_locker);
		TrySend();
	}

	HttpConnectIO *Open()
	{
		HttpConnectIO *dummy = HttpConnectIO::Open(HttpClientSession(&instance), ip.c_str());
        if(dummy)
        {
            Thread::Mutex::Scoped l(pool_locker);
            ++connecting_link;
        }
        return dummy;
	}
	bool Encode(std::string &code, const std::string &message)
    {
        size_t delimiter = message.find(':');
        if(delimiter == std::string::npos || delimiter == 0 || delimiter == message.size()-1) return false;
        std::string phone(message, 0, delimiter);
        std::string mask(message, delimiter+1);

        char buf[24];
        sprintf(buf, "%d", (int)time(NULL));
        std::map<std::string, std::string> param;
        param.insert(std::make_pair("appId","5"));
        param.insert(std::make_pair("clientId","meijie_zx3_fill"));
        param.insert(std::make_pair("mobile",phone));
        param.insert(std::make_pair("content",mask));
        param.insert(std::make_pair("timestamp",buf));
        std::string sign;
        std::map<std::string, std::string>::iterator it = param.begin();
        for(; it != param.end(); ++it)
        {
            sign += (it->second + ",");
        }
        sign.replace(sign.end()-1, sign.end(), "3a0f0390f92743a797d7ae5ea71cf981");
        LOG_TRACE("sign: %s", sign.c_str());

        char md5char[5+32] = "sign=";
        static const char hex[] = "0123456789abcdef";
        unsigned char digest[16];
        //md5_digest(digest, sign.c_str(), sign.size());
        for (size_t i = 0; i < sizeof(digest); ++i)
        {
            md5char[5+i+i] = hex[(digest[i] >> 4) & 0x0f];
            md5char[5+i+i+1] = hex[digest[i] & 0x0f];
        }

        for(it = param.begin(); it != param.end(); ++it)
        {
            code += (it->first + "=" + it->second + "&");
        }
        code.append(md5char, sizeof(md5char));
        return true;
    }
	bool DoSend(HttpClientSession *link, const std::string &message)
	{
		if(link == NULL) return false;
		std::string code;
		if(!Encode(code, message)) return false;
		std::stringstream ss;
		ss << "POST " << uri << " HTTP/1.1\r\nHost: " << host << "\r\nContent-Type: application/x-www-form-urlencoded\r\nConnection: Keep-Alive\r\nContent-length: " << message.length() << "\r\n\r\n" << message;
		Octets ps(ss.str().c_str(), strlen(ss.str().c_str()));
		link->Send(ps);
		return true;
	}
	void TrySend()
	{
		if(!request_pool.empty())
		{
			if(link_pool.empty())
			{
			    if(connecting_link > 2 || Open());
			}
			else
			{
				//�������ѡȡһ������
			    DoSend(link_pool.begin()->second, request_pool.front());
				request_pool.pop_front();
			}
		}
	}
	virtual void Run()
	{
        Thread::Mutex::Scoped l(pool_locker);
		has_run = false;
		TrySend();
	}
	HttpSingletonClient() : connecting_link(0), prepared(false), has_run(false), pool_locker("HttpSingletonClient") { }
	HttpSingletonClient(const HttpSingletonClient&);
public:
	static HttpSingletonClient *GetInstance() { return &instance; }
	bool Prepare(const char *url)
	{
		if(strlen(url) < 8) return false;
		if(strncmp(url, "http://", 7) != 0) return false;
		url += 7;
		const char *c = strchr(url, '/');
		if(c == NULL)
		{
			std::string tmp(url);
			host.swap(tmp);
			uri = std::string("/");
		}
		else
		{
			std::string tmp1(url, c-url);
			host.swap(tmp1);
			std::string tmp2(c);
			uri.swap(tmp2);
		}
		LOG_TRACE("preparing enter gethostbyname");
		struct hostent *hptr = gethostbyname(host.c_str());//���ܻ������ܾ�
		LOG_TRACE("preparing leave gethostbyname");
		if(hptr && hptr->h_addrtype == AF_INET)
		{
			char str[32];
			memset(str, 0, sizeof(str));
			inet_ntop(hptr->h_addrtype, hptr->h_addr, str, sizeof(str));
			std::string tmp(str);
			ip.swap(tmp);
		}
		else
		{
			return false;
		}
		LOG_TRACE("preparing host=%s ip=%s uri=%s",host.c_str(),ip.c_str(),uri.c_str());
		prepared = true;
		return true;
	}
	//��ʽ �ֻ���:��֤��
	bool SendMessage(const std::string &message)
	{
		if(!prepared) return false;
		if(message.empty()) return false;
		LOG_TRACE("connecting=%d request_pool=%d link_pool=%d message=%s", connecting_link,request_pool.size(),link_pool.size(),message.c_str());
        pool_locker.Lock();
		if(request_pool.size() > 999)
		{
			TrySend();
			return false;
		}
		if(link_pool.empty())
		{
			if(connecting_link > 2 || Open())
			{
				request_pool.push_back(message);
				return true;
			}
			return false;
		}
		request_pool.push_back(message);
        pool_locker.UNLock();
		if(!has_run)
		{
			has_run = true;
			Thread::Pool::AddTask(this);
		}
		return true;
	}
	void Close()
	{
        Thread::Mutex::Scoped l(pool_locker);
		for(std::map<int, HttpClientSession*>::iterator it = link_pool.begin(); it != link_pool.end(); ++it)
		{
			if(it->second) it->second->Close();
		}
	}
};

}
#endif
