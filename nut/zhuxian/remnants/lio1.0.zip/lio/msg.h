#ifndef L_MSG__H__
#define L_MSG__H__

enum
{
    //一系列消息类型的定义
    MSG_TYPE_TEST,
};

struct MSG
{
    int type;
    int from;
    int target;
    int param;
    int param2;
    size_t content_length;
    char* content;
    MSG(int type_t=0, int from_t=0, int target_t=0, int param_t=0, int param2_t=0) :
        type(type_t), from(from_t), target(target_t), param(param_t), param2(param2_t),
        content_length(0), content(NULL) {}
    MSG(const MSG& msg)
    {
        memcpy(this, &msg, sizeof(msg));
        if(content_length > 0 && content)
        {
            content = new char[content_length];
            memcpy(content, msg.content, content_length);
        }
    }
    ~MSG()
    {
        if(content_length > 0 && content)
            delete[] content;
    }
    MSG &operator=(const MSG& msg)
    {
        if(&msg == this) return *this;
        memcpy(this, &msg, sizeof(msg));
        if(content_length > 0 && content)
        {
            content = new char[content_length];
            memcpy(content, msg.content, content_length);
        }
        return *this;
    }
};

#endif // L_MSG__H__
