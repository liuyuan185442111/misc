#ifndef L_GMATRIX__H__
#define L_GMATRIX__H__

#include "message.h"
#include <stdio.h>

class gmatrix
{
public:
    static MsgQueueList msglist;
    static void HandleMessage(const MSG& msg)
    {
        //根据target和type找相应object的message_handler去处理消息
        puts("消息在此被处理");
        printf("type=%d, from=%d, target=%d, param=%d\n", msg.type, msg.from, msg.target, msg.param);
    }
};

#endif // L_GMATRIX__H__
