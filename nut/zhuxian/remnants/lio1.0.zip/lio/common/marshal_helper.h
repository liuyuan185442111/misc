#ifndef _STATIC_ASSERT_H_
#define _STATIC_ASSERT_H_

#ifdef __GNUC__
#define STATIC_ASSERT_NO_WARNING __attribute__((unused))
#else
#define STATIC_ASSERT_NO_WARNING
#endif
template<bool x> struct STATIC_ASSERTION_FAILURE;
template<> struct STATIC_ASSERTION_FAILURE<true>{};
template<int x> struct static_assert_test{};
#define STATIC_ASSERT(B) typedef static_assert_test<sizeof(STATIC_ASSERTION_FAILURE<(bool)(B)>)> static_assert_typedef_##__LINE__ STATIC_ASSERT_NO_WARNING

namespace
{
template <typename U, typename V>
union TypeAliasing
{
	U u;
	V v;
	TypeAliasing(V _v) : v(_v) { }
	operator U() const { return u; }
};
}

template <typename U, typename V>
inline U aliasing_cast(V v)
{
	TypeAliasing<U, V> data(v);
	return data;
}

#endif
