#ifndef __ITIMER_H
#define __ITIMER_H

#include <signal.h>
#include <sys/time.h>
#include <map>
#include "thread.h"
#include "mutex.h"
#ifdef _REENTRANT_
#include <pthread.h>
#endif

namespace GNET
{
#ifndef _REENTRANT_
#define SuspendTimer IntervalTimer::Suspend
#define ResumeTimer  IntervalTimer::Resume
#else
#define SuspendTimer() 
#define ResumeTimer() 
#endif

//��ʱ��� ΢��
#define DEFAULT_INTERVAL 100000

class IntervalTimer : public Thread::Runnable
{
public:
	class Observer
	{
		friend class IntervalTimer;
		size_t interval;
	public:
		virtual ~Observer() {}
		virtual bool Update() = 0;//����false��ʾ����ִ��һ��
	};
private:
	class TimerTask : public Observer
	{
		Thread::Runnable *runnable;
	public: 
		TimerTask(Thread::Runnable *r) : runnable(r){}
		bool Update()
		{
			Thread::Pool::AddTask(runnable, true);
			delete this;
			return false;
		}
	};

	typedef std::multimap<int64_t, Observer*> Observers;
	static Observers observers;
	static Thread::Mutex locker;//for observers
	static bool stop;
	static bool triggered;
	static size_t interval;
	static struct timeval now;
	static int64_t tick_now;
	static struct timeval base;
	static IntervalTimer instance;
	static sigset_t mask;

	virtual void Run()
	{
#ifdef _REENTRANT_
		sigset_t sigs;
        //���������ź�
		sigfillset(&sigs);
		pthread_sigmask(SIG_BLOCK, &sigs, NULL);

		struct itimerval value;
		value.it_interval.tv_sec = interval/1000000;
		value.it_interval.tv_usec = interval%1000000;
		value.it_value.tv_sec = interval/1000000;
		value.it_value.tv_usec = interval%1000000;
		setitimer(ITIMER_REAL, &value, NULL);

		sigfillset(&sigs);
		sigdelset(&sigs, SIGALRM);
        //sigsuspend�������滻��ǰ�̵߳�������, Ȼ�����pause״̬,
        //�ȵ��������źŵ���, ִ�����Ӧ���źŴ��������󷵻�
		while(!stop)
        {
			sigsuspend(&sigs);
			Update();
		}
		setitimer(ITIMER_REAL, NULL, NULL);
#else
		if(triggered)
		{
			Update();
			triggered = false;
		}
#endif
	}

	static void AttachObserver(Observer* o)
	{
		if(!stop){
			observers.insert(Observers::value_type(tick_now + o->interval, o));
		}
	}
public:
	static void Update()
	{
		Observers::iterator it;
		bool add;
		{
			Thread::Mutex::Scoped lock(locker);
			gettimeofday(&now, NULL);
            tick_now = ((int64_t)(now.tv_sec - base.tv_sec)*1000000 + now.tv_usec - base.tv_usec)/interval;
			it = observers.begin();
		}

		while(it!=observers.end()){
			if(it->first > tick_now)
				break;
			add = it->second->Update();

			{
				Thread::Mutex::Scoped lock(locker);
				if(add)
					AttachObserver(it->second);
				observers.erase(it);
				it = observers.begin();
			}
		}
	}

	static int Resolution() { return interval; }

    //delay�ĵ�λ��tick
	static void Attach(Observer* o, size_t delay)
	{ 
		delay = delay>0?delay:1;
		o->interval = delay;
		Thread::Mutex::Scoped lock(locker);
		AttachObserver(o);
	}

    //�ӳ�ִ������
	static void Schedule(Runnable *task, size_t delay)
	{
		Attach(new TimerTask(task), delay);
	}

	static bool StartTimer(size_t usec=0) 
	{
		if(!stop) return false;
		stop = false; 
        if(usec <= 0)
            interval = DEFAULT_INTERVAL;
        else
            interval = usec;

#ifndef _REENTRANT_
		sigemptyset(&mask);
        //����SIGALRM,��IO����wait֮ǰ����ResumeTimer()�ָ�
		sigaddset(&mask, SIGALRM);
		sigprocmask(SIG_BLOCK, &mask, NULL);
		signal(SIGALRM, Handler);

		struct itimerval value;
		value.it_interval.tv_sec = interval/1000000;
		value.it_interval.tv_usec = interval%1000000;
		value.it_value.tv_sec = interval/1000000;
		value.it_value.tv_usec = interval%1000000;
		setitimer(ITIMER_REAL, &value, NULL);
#else
		signal(SIGALRM, Handler);
        Thread::Pool::AddTask(&instance, true);
#endif
		tick_now = 0;
        gettimeofday(&base, NULL);
        now = base;
		return true;
	}
	static void StopTimer()
	{ 
		stop = true; 
	}

    //�յ�SIGALRM�ź�
	static void Handler(int signum)
	{
		triggered = true;
#ifndef _REENTRANT_
        Thread::Pool::AddTask(&instance, true);
#endif
	}
    //���߳���IO��wait֮ǰResumeTimer,wait֮��SuspendTimer
    //����SIGALRM�ź�
	static void Suspend()
	{
		sigprocmask(SIG_BLOCK, &mask, NULL);
        /*ͨ����Handler����������ķ�ʽ�����и���,���ڴ˴�������
		if(triggered)
		{
			Update();
			triggered = false;
		}*/
	}
    //�ָ�SIGALRM�ź�
	static void Resume()
	{
		sigprocmask(SIG_UNBLOCK, &mask, NULL);
	}
};//end of IntervalTimer
}//end of GNET

#endif
