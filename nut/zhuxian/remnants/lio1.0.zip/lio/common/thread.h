#ifndef __THREAD_H
#define __THREAD_H

#include <signal.h>
#include <sys/types.h>
#include <unistd.h>
#include <vector>
#include <string>
#include <queue>
#include <list>
#include <map>
#include "timer.h"
#ifdef _REENTRANT_
#include "mutex.h"
#include <deque>
#endif

namespace GNET
{
namespace Thread
{
	class Runnable
	{
	protected:
		int m_priority;
	public:
		Runnable( int priority = 1 ) : m_priority(priority) { }
		virtual ~Runnable() { }
		virtual void Run() = 0;
		void SetPriority( int priority ) { m_priority = priority; }
		int GetPriority() const { return m_priority; }
	};

	class Pool
	{
		class Policy
		{
			friend class Pool;
        protected:
			size_t m_max_queuesize;
            bool   m_will_quit;
			void LoadConfig() { }
		public:
			static Policy s_policy;

			Policy() : m_max_queuesize(1048576), m_will_quit(false) { }
			virtual ~Policy() { }

			void SetMaxQueueSize( size_t max_queuesize )
			{
				m_max_queuesize = max_queuesize;
			}

			virtual std::string Identification() { return "ThreadPool"; }
			virtual bool OnAddTask(Thread::Runnable *pTask, size_t queuesize, bool bForced)
            {
                if( m_will_quit )
                {
                    delete pTask;
                    return false;
                }
                if( queuesize<m_max_queuesize || bForced )
                    return true;
                return false;
            }
            virtual void OnQuit()
            {
                m_will_quit = true;
            }
		};
	private:
        #ifdef _REENTRANT_
        typedef std::deque<Runnable*> TaskQueue;
        static SpinLock s_spinlock;//for s_tasks
        #else
		typedef std::multimap<int, Runnable*> TaskQueue;
		static Runnable *FetchTask()
		{
			Runnable *pTask = NULL;
			if (!s_tasks.empty())
			{
				TaskQueue::iterator it = s_tasks.lower_bound(1);
				if( it == s_tasks.end() )
				{
					it = s_tasks.begin();
				}
				pTask = it->second;
				s_tasks.erase( it );
			}
			return pTask;
		}
        #endif
		static TaskQueue s_tasks;
		static Policy *s_ppolicy;
        static size_t s_pool_size;//线程数量
		static void sigusr1_handler( int signum );
	public:
		static void setupdaemon( )
		{
			switch(fork())
			{
			case 0:
				break;
			case -1:
				exit(-1);
			default:
				exit(0);
			}
			setsid();
		}
		static void SetPolicy( Policy * policy )
		{
			s_ppolicy = policy;
			s_ppolicy->LoadConfig();
		}
		static void AddTask( Runnable * task, bool bForced = false )
		{
			if( (task && !s_ppolicy) || s_ppolicy->OnAddTask(task, QueueSize(), bForced) )
			{
            #ifdef _REENTRANT_
                s_spinlock.Lock();
                s_tasks.push_back(task);
                s_spinlock.UNLock();
            #else
				s_tasks.insert( std::make_pair(task->GetPriority(),task) );
            #endif
			}
		}
        //一个线程固定给IntervalTimer用
        //一个线程给阻塞的PollIO用
		static void Run(size_t pool_size = 3)
		{
        #ifndef _REENTRANT_
			signal( SIGUSR1, sigusr1_handler );
            while (true)
            {
                Runnable * pTask = FetchTask();
                if( pTask )
                {
                    try {
                        pTask->Run(); //task自己负责delete掉自己,比如在Run中delete this
                    } catch( ... ) { delete pTask; }
                }

                if( s_ppolicy && s_ppolicy->m_will_quit )
                {
                    break;
                }
            }
            for(TaskQueue::iterator it = s_tasks.begin(); it!=s_tasks.end(); ++it)
            {
                delete it->second;
            }
        #else
            if(pool_size < 3) s_pool_size = 3;
            else s_pool_size = pool_size;
            pthread_t pt;
            for(size_t i=s_pool_size; i>0; --i)
            {
                pthread_create(&pt, NULL, &Pool::RunThread, (void*)(&i));
            }
        #endif
		}
		static size_t QueueSize()
        {
        #ifdef _REENTRANT_
            SpinLock::Scoped l(s_spinlock);
        #endif
            return s_tasks.size();
        }
		static size_t ThreadSize() { return s_pool_size; }

        #ifdef _REENTRANT_
        static void *RunThread(void *index)
        {
            pthread_detach(pthread_self());
            while(true)
            {
                try
                {
                    if(s_tasks.empty())
                    {
                        while(s_tasks.empty())
                            usleep(1000);
                    }
                    Runnable *pTask = NULL;
                    s_spinlock.Lock();
                    if(!s_tasks.empty())
                    {
                        pTask = s_tasks.front();
                        s_tasks.pop_front();
                    }
                    s_spinlock.UNLock();
                    if(pTask) pTask->Run();
                }
                catch(...) {}
            }
            return NULL;
        }
        #endif
	};//end of Pool
}//end of Thread
}//end of GNET


namespace GNET
{
namespace Thread
{
	class HouseKeeper : public Timer::Observer
	{
	private:
		typedef std::multimap<int, Runnable*> TimerTaskQueue;
		TimerTaskQueue	tasks;
		Timer	timer;

		HouseKeeper() { Timer::Attach(this); }
		static HouseKeeper &GetInstance() { static HouseKeeper s_instance; return s_instance; }

		void AddTask( Runnable * pTask, int waitsecs )
		{
			tasks.insert( std::make_pair(timer.Elapse() + waitsecs, pTask) );
		}
		virtual void Update()
		{
			int nElapse = timer.Elapse();
			TimerTaskQueue::iterator it = tasks.begin();
			while(it != tasks.end())
			{
				if(it->first > nElapse)
					break;
				Thread::Pool::AddTask( (*it).second, true );
				tasks.erase( it );
				it = tasks.begin();
			}
		}
	public:
		static void AddTimerTask( Runnable * pTask, int waitsecs )
		{
			GetInstance().AddTask( pTask, waitsecs );
		}
	};
}
}

#endif
