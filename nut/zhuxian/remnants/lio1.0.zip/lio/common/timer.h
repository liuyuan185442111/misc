#ifndef __TIMER_H
#define __TIMER_H

#include <vector>
#include <functional>
#include <algorithm>
#include <time.h>
namespace GNET
{
class Timer
{
public:
	class Observer
	{
	public:
		virtual ~Observer() { }
		virtual void Update() = 0;
	};
private:
	static std::vector<Observer*>& observers() { static std::vector<Observer*> obs; return obs; }
	static time_t now;
public:
	static void Attach(Observer *o) { observers().push_back(o); }
	static void Detach(Observer *o) { observers().erase(std::remove(observers().begin(), observers().end(), o), observers().end()); }
	//重点在于要在某个地方持续调用Update
    //只有在单线程状态下才会在PollController::Poll之后调用
	static void Update()
	{
		time_t cur_time = time(NULL);
		if(cur_time > now)
		{
			now = cur_time;
			std::for_each(observers().begin(), observers().end(), std::mem_fun(&Observer::Update));
		}
	}
	static time_t GetTime() { return now; }
private:
	time_t start;
public:
	Timer() : start(now) { }
	int Elapse() const { return now - start; }
	void Reset()
	{
		start = now;
	}
};
}
#endif
