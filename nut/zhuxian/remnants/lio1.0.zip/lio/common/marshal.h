#ifndef __MARSHAL_H
#define __MARSHAL_H

#include "octets.h"
#include "byteorder.h"
#include "marshal_helper.h"
#include <exception>
#include <string>
#include <vector>
#include <list>
#include <deque>
#include <map>

namespace GNET
{

class OctetsStream;
struct Marshal
{
	virtual OctetsStream& marshal(OctetsStream &) const = 0;
	virtual const OctetsStream& unmarshal(const OctetsStream &) = 0;
	virtual ~Marshal() { }
};

template <typename T>
inline T& remove_const(const T &t) { return const_cast<T&>(t); }

template <typename Container>
class STLContainer;
template <typename Container>
inline STLContainer<Container> MarshalContainer(const Container &c)
{
	return STLContainer<Container>(remove_const(c));
}

class OctetsStream
{
	class Exception : public std::exception
	{
        std::string msg;
    public:
		Exception(const std::string &arg) throw() : msg(arg){}
        virtual ~Exception() throw() { }
        virtual const char* what() throw() { return msg.c_str(); }
	};
	enum Transaction { Begin, Commit, Rollback };

    enum { MAXSPARE = 16384};
    Octets data;
    mutable size_t pos;//指示data当前的位置
    mutable size_t tranpos;
    template<typename T> OctetsStream& push_byte(T t)
    {
        data.insert(data.end(), &t, sizeof(t));
        return *this;
    }
    template<typename T> void pop_byte(T &t) const
    {
        if (pos + sizeof(t) > data.size()) throw Exception("pop_byte");
        t = *(T *)( (char*)data.begin() + pos );
        pos += sizeof(t);
    }
    unsigned char pop_byte_8() const
    {
        unsigned char c;
        pop_byte(c);
        return c;
    }
    unsigned short pop_byte_16() const
    {
        unsigned short s;
        pop_byte(s);
        return byteorder_16(s);
    }
    unsigned int pop_byte_32() const
    {
        unsigned int i;
        pop_byte(i);
        return byteorder_32(i);
    }
    unsigned long long pop_byte_64() const
    {
        unsigned long long ll;
        pop_byte(ll);
        return byteorder_64(ll);
    }

    friend class CompactUINT;
    friend class CompactSINT;

    //x的值一般比较小, 如一律使用4字节来存储会造成浪费
    //0:1个字节, 1:2个字节, 11:4个字节, 1110:1+4个字节
    OctetsStream& compact_uint32(unsigned int x)
    {
        if (x < 0x80) return push_byte((unsigned char)x);
        else if (x < 0x4000) return push_byte(byteorder_16(x|0x8000));
        else if (x < 0x20000000) return push_byte(byteorder_32(x|0xc0000000));
        push_byte((unsigned char)0xe0);
        return push_byte(byteorder_32(x));
    }
    //x>=0,00:1,100:2,1100:4,1110:1+4
    //x<0 ,01:1,101:2,1101:4,1111:1+4
    OctetsStream& compact_sint32(int x)
    {
        if (x >= 0)
        {
            if (x < 0x40) return push_byte((unsigned char)x);
            else if (x < 0x2000) return push_byte(byteorder_16(x|0x8000));
            else if (x < 0x10000000) return push_byte(byteorder_32(x|0xc0000000));
            push_byte((unsigned char)0xe0);
            return push_byte(byteorder_32(x));
        }
        if (-x > 0)
        {
            x = -x;
            if (x < 0x40) return push_byte((unsigned char)x|0x40);
            else if (x < 0x2000) return push_byte(byteorder_16(x|0xa000));
            else if (x < 0x10000000) return push_byte(byteorder_32(x|0xd0000000));
            push_byte((unsigned char)0xf0);
            return push_byte(byteorder_32(x));
        }
        push_byte((unsigned char)0xf0);
        return push_byte(byteorder_32(x));
    }
    const OctetsStream& uncompact_uint32(const unsigned int &x) const
    {
        switch ( *((unsigned char *)data.begin()+pos) & 0xe0)
        {
            case 0xe0://1110
                pop_byte_8();
                remove_const(x) = pop_byte_32();
                return *this;
            case 0xc0://1100
                remove_const(x) = pop_byte_32() & ~0xc0000000;
                return *this;
            case 0xa0://1010
            case 0x80://1000
                remove_const(x) = pop_byte_16() & ~0x8000;
                return *this;
        }
        remove_const(x) = pop_byte_8();
        return *this;
    }
    const OctetsStream& uncompact_sint32(const int &x) const
    {
        switch ( *((unsigned char *)data.begin()+pos) & 0xf0)
        {
            case 0xf0:
                pop_byte_8();
                remove_const(x) = 0 - pop_byte_32();
                return *this;
            case 0xe0:
                pop_byte_8();
                remove_const(x) = pop_byte_32();
                return *this;
            case 0xd0:
                remove_const(x) = 0 - (pop_byte_32() & ~0xd0000000);
                return *this;
            case 0xc0:
                remove_const(x) = pop_byte_32() & ~0xc0000000;
                return *this;
            case 0xb0:
            case 0xa0:
                remove_const(x) = -(pop_byte_16() & ~0xa000);
                return *this;
            case 0x90:
            case 0x80:
                remove_const(x) = pop_byte_16() & ~0x8000;
                return *this;
            case 0x70:
            case 0x60:
            case 0x50:
            case 0x40:
                remove_const(x) = -(pop_byte_8() & ~0x40);
                return *this;
        }
        remove_const(x) = pop_byte_8();
        return *this;
    }
    public:
    OctetsStream() : pos(0) {}
    OctetsStream(const Octets &o) : data(o), pos(0) {}
    OctetsStream(const OctetsStream &os) : data(os.data), pos(0) {}

    OctetsStream& operator = (const OctetsStream &os) 
    {
        if (&os != this)
        {
            pos  = os.pos;
            data = os.data;
        }
        return *this;
    }

    bool operator == (const OctetsStream &os) const { return data == os.data; }
    bool operator != (const OctetsStream &os) const { return data != os.data; }
    size_t size() const { return data.size(); }
    void swap (OctetsStream &os) { data.swap(os.data); }
    operator Octets& () { return data; }
    operator const Octets& () const { return data; }

    void *begin() { return data.begin(); }
    void *end()   { return data.end(); }
    const void *begin() const { return data.begin(); }
    const void *end()   const { return data.end();   }
    void insert(void *pos, const void *x, size_t len) { data.insert(pos, x, len); }
    void insert(void *pos, const void *x, const void *y) { data.insert(pos, x, y); }
    void erase(void *x, void *y) { data.erase(x, y); }
    void clear() { data.clear(); pos = 0; }
    bool eos() const { return pos == data.size(); }

    OctetsStream& operator << (char x)               { return push_byte(x); }
    OctetsStream& operator << (unsigned char x)      { return push_byte(x); }
    OctetsStream& operator << (bool x)               { return push_byte(static_cast<char>(x)); }
    OctetsStream& operator << (short x)              { return push_byte(byteorder_16(x)); }
    OctetsStream& operator << (unsigned short x)     { return push_byte(byteorder_16(x)); }
    OctetsStream& operator << (int x)                { return push_byte(byteorder_32(x)); }
    OctetsStream& operator << (unsigned int x)       { return push_byte(byteorder_32(x)); }
    OctetsStream& operator << (int64_t x)            { return push_byte(byteorder_64(x)); }
    OctetsStream& operator << (float x)              { return push_byte(byteorder_32(aliasing_cast<int>(x))); }
    OctetsStream& operator << (double x)             { return push_byte(byteorder_64(aliasing_cast<unsigned long long>(x))); }
    OctetsStream& operator << (const Marshal &x)     { return x.marshal(*this); }
    OctetsStream& operator << (const Octets &x)  
    {
        compact_uint32(static_cast<unsigned int>(x.size()));
        data.insert(data.end(), x.begin(), x.end());
        return *this;
    }
    template<typename T>
        OctetsStream& operator << (const std::basic_string<T> &x)
        {
            STATIC_ASSERT(sizeof(T) == 1); //需要在服务器处理utf16,utf32时,开放其他sizeof
            unsigned int bytes = x.length()*sizeof(T);
            compact_uint32(bytes);
            insert(end(), (void*)x.c_str(), bytes);
            return *this;
        }
    OctetsStream& push_byte(const char *x, size_t len)
    {
        data.insert(data.end(), x, len);
        return *this;
    }
    template<typename T1, typename T2>
        OctetsStream& operator << (const std::pair<T1, T2> &x)
        {
            return *this << x.first << x.second;
        }
    template<typename T>
        OctetsStream& operator << (const std::vector<T> &x) 
        {
            return *this << (MarshalContainer(x));
        }
    template<typename T>
        OctetsStream& operator << (const std::list<T> &x) 
        {
            return *this << (MarshalContainer(x));
        }
    template<typename T>
        OctetsStream& operator << (const std::deque<T> &x) 
        {
            return *this << (MarshalContainer(x));
        }
    template<typename T1, typename T2>
        OctetsStream& operator << (const std::map<T1, T2> &x) 
        {
            return *this << (MarshalContainer(x));
        }

    const OctetsStream& operator >> (Transaction trans) const
    {
        switch (trans)
        {
            case Begin:
                tranpos = pos;
                break;
            case Rollback:
                pos = tranpos;
                break;
            case Commit:
                if (pos >= MAXSPARE)
                {
                    remove_const(*this).data.erase((char*)data.begin(), (char*)data.begin()+pos);	
                    pos = 0;
                }
        }
        return *this;
    }
    const OctetsStream& operator >> (const char &x) const
    {
        remove_const(x) = pop_byte_8();
        return *this;
    }
    const OctetsStream& operator >> (const unsigned char &x) const
    {
        remove_const(x) = pop_byte_8();
        return *this;
    }
    const OctetsStream& operator >> (const bool &x) const
    {
        remove_const(x) = pop_byte_8() != 0;
        return *this;
    }
    const OctetsStream& operator >> (const short &x) const
    {
        remove_const(x) = pop_byte_16();
        return *this;
    }
    const OctetsStream& operator >> (const unsigned short &x) const
    {
        remove_const(x) = pop_byte_16();
        return *this;
    }
    const OctetsStream& operator >> (const int &x) const
    {
        remove_const(x) = pop_byte_32();
        return *this;
    }
    const OctetsStream& operator >> (const unsigned int &x) const
    {
        remove_const(x) = pop_byte_32();
        return *this;
    }
    const OctetsStream& operator >> (const int64_t &x) const
    {
        remove_const(x) = pop_byte_64();
        return *this;
    }
    const OctetsStream& operator >> (const float &x) const
    {
        unsigned long l = pop_byte_32();
        remove_const(x) = aliasing_cast<float>(l);
        return *this;
    }
    const OctetsStream& operator >> (const double &x) const
    {
        unsigned long long ll = pop_byte_64();
        remove_const(x) = aliasing_cast<double>(ll);
        return *this;
    }
    const OctetsStream& operator >> (const Marshal &x) const
    {
        return remove_const(x).unmarshal(*this);
    }
    const OctetsStream& operator >> (const Octets &x) const
    {
        unsigned int len;
        uncompact_uint32(len);
        if (len > data.size() - pos) throw Exception("invalid length");
        remove_const(x).replace((char*)data.begin()+pos, len);
        pos += len;
        return *this;
    }
    template<typename T>
        const OctetsStream& operator >> (const std::basic_string<T> &x) const
        {
            STATIC_ASSERT(sizeof(T) == 1); //需要在服务器处理utf16,utf32时,开放其他sizeof
            unsigned int bytes;
            uncompact_uint32(bytes);
            if (bytes % sizeof(T)) throw Exception("invalid length");
            if (bytes > data.size() - pos) throw Exception("invalid length");
            remove_const(x).assign((T*)((char*)data.begin()+pos), bytes/sizeof(T));
            pos += bytes;
            return *this;
        }
    void pop_byte(char *x, size_t len) const
    {
        if (pos + len > data.size()) throw Exception("invalid length");
        memcpy(x, (char*)data.begin()+pos, len);
        pos += len;
    }
    template<typename T1, typename T2>
        const OctetsStream& operator >> (const std::pair<T1, T2> &x) const
        {
            return *this >> remove_const(x.first) >> remove_const(x.second);
        }
    template<typename T>
        const OctetsStream& operator >> (const std::vector<T> &x) const
        {
            return *this >> (MarshalContainer(x));			
        }
    template<typename T>
        const OctetsStream& operator >> (const std::deque<T> &x) const
        {
            return *this >> (MarshalContainer(x));			
        }
    template<typename T>
        const OctetsStream& operator >> (const std::list<T> &x) const
        {
            return *this >> (MarshalContainer(x));			
        }
    template<typename T1, typename T2>
        const OctetsStream& operator >> (const std::map<T1, T2> &x) const
        {
            return *this >> (MarshalContainer(x));			
        }
};

class CompactUINT : public Marshal
{
	unsigned int *pi;
public:
	explicit CompactUINT(const unsigned int &i): pi(&remove_const(i)) { }
	OctetsStream& marshal(OctetsStream &os) const
	{
		return os.compact_uint32(*pi);
	}
	const OctetsStream& unmarshal(const OctetsStream &os)
	{
		return os.uncompact_uint32(*pi);
	}
};

class CompactSINT : public Marshal
{
	int *pi;
public:
	explicit CompactSINT(const int &i): pi(&remove_const(i)) { }
	OctetsStream& marshal(OctetsStream &os) const
	{
		return os.compact_sint32(*pi);
	}
	const OctetsStream& unmarshal(const OctetsStream &os)
	{
		return os.uncompact_sint32(*pi);
	}
};

template <typename Container>
class STLContainer : public Marshal
{
	Container *pc;
public:
	explicit STLContainer(Container &c) : pc(&c) { }
	OctetsStream& marshal(OctetsStream &os) const
	{
		os << CompactUINT(pc->size());
		for (typename Container::const_iterator i = pc->begin(), e = pc->end(); i != e; ++i)
			os << *i;
		return os;
	}
	const OctetsStream& unmarshal(const OctetsStream &os)
	{
		pc->clear();
		unsigned int size;
		for (os >> CompactUINT(size); size > 0; --size)
		{
			typename Container::value_type tmp;
			os >> tmp;
			pc->insert(pc->end(), tmp);
		}
		return os;
	}
};

}//end of GNET

#endif//end of __MARSHAL_H
