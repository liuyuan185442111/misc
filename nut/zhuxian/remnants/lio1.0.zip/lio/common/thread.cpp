#include "thread.h"

namespace GNET
{
Thread::Pool::Policy	Thread::Pool::Policy::s_policy;
Thread::Pool::TaskQueue	Thread::Pool::s_tasks;
Thread::Pool::Policy*	Thread::Pool::s_ppolicy = &(Thread::Pool::Policy::s_policy);
size_t                  Thread::Pool::s_pool_size = 1;
#ifdef _REENTRANT_
Thread::SpinLock        Thread::Pool::s_spinlock("Thread::Pool::s_spinlock");
#endif

void Thread::Pool::sigusr1_handler( int signum )
{
	if( SIGUSR1 == signum )
	{
		s_ppolicy->OnQuit();
	}
}

}
