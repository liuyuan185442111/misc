svn co http://10.68.12.20/repos/zskill/trunk/gen
svn co http://10.68.12.20/repos/zskill/trunk/header
svn co http://10.68.12.20/repos/zskill/trunk/skill
cd gen
ant