cd gen
svn up
cd ../header
svn up
cd ../skill
svn up
cd ..
